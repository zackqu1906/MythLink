# Clef 测试样例

样例独立于测试程序。直接增删 JSON 数组中的对象即可；不用改 Python。

## 手动＋编辑路由的 DeepSeek 中文标签实验

`llm_edit_routing_natural_cases.json` 配合 `tools/check_llm_edit_router.py`，只测试用户已手动选择编辑后的任务路由。
模型直接输出“修改、润色”这样的中文类别，不要求 JSON，也不再次分类听写／编辑。
分类器沿用当前 `router_prompts.py` 的六类定义、选择／排除条件和组合规则，
沿用原文末 400 字符与 OCR 末 360 字符的路由输入范围；正文生成直接复用自动编辑的原有提示词和处理器。
生成使用模型实际选出的任务，预期标签和生成约束不发送给模型。

默认运行 126 条既有编辑回归样例、24 条新合成样例及 6 条无有效需求边界样例。
新样例附带 24 次实际路由后的生成。`无可执行编辑` 会阻止生成；非法类别、重复类别、
额外解释以及空原文下的修改任务均报错，不静默改判听写、不通过关键词覆盖模型结果。
此实验没有接入应用的模式选择、手势或输入法写回，也不能代表真实 ASR/OCR 的接受率。

```sh
.runtime/venv/bin/python tools/check_llm_edit_router.py \
  --validate-only --output /tmp/route-validation.json
.runtime/venv/bin/python tools/check_llm_edit_router.py \
  --output docs/reports/my-natural-label-routing.json
```

`--fresh-only` 跳过旧回归集，`--case ID` 可重复筛选，`--repeat N` 用于重复稳定性测量。
工具读取应用已保存的火山 DeepSeek 配置，不修改设置；请求串行、关闭深度思考、无自动重试。
HTML/JSON/JSONL 保存原始请求正文、响应、token 用量和每阶段耗时，不保存鉴权请求头。
路由耗时计到完整中文标签收到并通过校验；总耗时还包含正文生成，不包含 ASR、采集 OCR 或写回。
P50/P95 使用 nearest-rank；服务端缓存命中见响应的 `usage.input_tokens_details.cached_tokens`。
正文的自动约束检查与语义复核分别记录，不能以接口成功代替质量通过。
退出码 0 仅表示请求／解析成功，类别是否正确、生成是否合格要看报告；重复输出路径不会覆盖旧实验。

## 现有自动分类样例

- `automatic_voice_routing_cases.json`：原有 32 条，含总体意图和任务集合。
- `clef_primary_validation_cases.json`：新增 24 条边界样例，已补充六类任务预期，和原样例均用于开发。
- `clef_primary_unseen_cases.json`：后加的 12 条措辞变化。首次盲测为 11/12，随后用失败例完善同义表达规则；因此它们也已参与调优，不能算最终版本的独立测试集。
- `clef_joint_holdout_cases.json`：原联合方案的 24 条合成留出样例；本次合并已复用，作为回归集，不再视作新独立测试集。
- `clef_hierarchical_baseline_v3.json`：旧两级提示词及原始 32 条标签冻结快照，仅供对照，不是可编辑样例。
- `clef_joint_eight_baseline_v2.json`：合并前八类 C 方案的提示词与样例快照，保留旧标签。
- `clef_organize_boundary_cases.json`：12 条内容整理边界样例，含纯格式不删信息、摘要、撤销精简、组合操作等。
- `clef_six_task_boundary_cases.json`：新六类边界的 26 条样例，含整句替换、量词纠错、原话插入、扩缩写、格式、创作及组合；19 条带预设生成约束。v10 首测后已查看错误并用于 v11/v12 修正，因此最终版中也属于开发回归集。
- `clef_correction_boundary_cases.json`：24 条直接纠错正反样例，覆盖中外文名称、拼读噪声、整句及数量更新，以及转述、照录、撤销、无原文、无对应旧内容和原文已正确等边界。均为构造或脱敏样例，已参与提示词调优；不包含真实交互和真实 OCR。
- `clef_cases.template.json`：复制这个文件建立自己的样例集。

每条必须显式包含以下字段，空输入也要写出：

| 字段 | 含义 |
|---|---|
| `id` | 唯一编号，任意非空字符串，不能重复 |
| `utterance` | 当前口述，即 ASR 后的文字，1–2000 字符 |
| `target` | 输入框中可编辑的原文；没有则为 `""` |
| `context.messages` | 已经过滤的 OCR 参考文字数组；没有则为 `[]` |
| `context.messages[].speaker` | `self` 自己、`other` 对方、`unknown` 无法确定 |
| `context.messages[].text` | 该条 OCR 参考文字 |
| `expected.task` | 总体意图：`dictation` 听写，或 `edit` 编辑 |
| `expected.tasks` | 联合评测时编辑样例必须填写；听写用 `[]` |

`context` 可以保留应用名、来源等额外元数据；分类器只读取 `messages`。
**`expected` 只给测试程序评分，从不发送给模型。** 联合分类使用口述、原文、OCR 上文；
后续文本模型接收完整口述、完整原文、`context`，以及分类器实际产出的 `edit_plan`。
不要把预期编辑计划写成模型输入，否则会绕过真实分类。

2026-11-04 用户确认 `joint-holdout-ordinary-answer`（原文“我带一份过去。”，口述“没问题，我带两份过去”）是对本人此前输入的重述纠错，预期已从听写修正为 `edit + modify`。历史报告与冻结快照仍保留当时标签；新对照须按同一修正标签重评分，不能把改标签计为提示词提升。`annotation_note` 仅记录标注依据，不发送给模型。

分类器按主项目规则只读取原文末 400 字符、最后 4 条 OCR 拼接后的末 360 字符。
这些文件模拟的是 OCR 后的文本，不会运行截图或语音识别；没有图片输入。
为了模拟真实采集，OCR 内容应是过滤后的可见文字（采集器最多 16 条／2400 字符）。

编辑任务：`modify` 修改、`insert` 插入、`polish` 润色（扩写／缩写／摘要）、
`format` 格式整理、`translate` 翻译、`compose` 按目标创作。
旧 `precise_edit` → `modify`，`verbatim_insert` → `insert`，`expand` → `polish`。
旧 `organize` 不能统一改成某一个字段，必须按口述区分：精简／摘要归 `polish`，重排／列表／表格归 `format`，两者同时要求时同时标记。
释字拼写和直接重述都标记 `modify`；用户已逐字给出整句替换正文也属于修改，不按改动字数判创作。
旧标签和 `hints` 在当前活动样例中会被拒绝；冻结快照仅供历史对照。
复现旧一级时，`expected` 可以只写 `task`；当前联合评测必须有任务预期。

在项目根目录运行：

```sh
cp tools/data/clef_cases.template.json tools/data/my_clef_cases.json
.runtime/venv/bin/python tools/check_clef_router.py --cases tools/data/my_clef_cases.json --validate-only
.runtime/venv/bin/python tools/check_clef_router.py --cases tools/data/my_clef_cases.json --case my-edit-01 --dump-request
bash scripts/clef-remote.sh check --cases tools/data/my_clef_cases.json --output .runtime/clef/my-joint-results.json
bash scripts/clef-remote.sh pipeline --cases tools/data/my_clef_cases.json --output .runtime/clef/my-pipeline-results.json
# 对照 A 旧两级、B 一级补定义、C 联合；--development 可重复，--holdout 指定留出样例
bash scripts/clef-remote.sh compare --output .runtime/clef/my-comparison.json
```

`check` 每条一次请求，HTML 和 JSON 展示总体意图两个概率及六个任务各自 apply/skip 概率，包括听写和矛盾结果。总体听写优先、不明确时回退听写；冲突记录标黄，仍展示原始 apply/skip 与全部概率。
`pipeline` 真实调用分类及已配置文本模型，不向其他应用写回或发送消息。
`primary` 保留为冻结旧 v3 一级的复现命令，不能用它评估当前应用。
`expected` 不传给模型。对照工具按总体意图和六个任务计算完整匹配。旧 precise_edit/verbatim_insert/expand/condense/structure 可按明确映射计分，原始概率不变；旧 organize 不能从一个分数拆出 polish 和 format。比较旧 v9 时，对涉及旧 organize 的样例不做自动完整任务重评分，其余可比样例才使用同一口径。旧 hint 仅展示、不计分；不能把不同分类口径的准确率直接相减。
分类程序退出码 0 表示最终处理全部匹配（仍可能包含标黄回退），2 表示最终处理不符，1 表示调用或接口校验失败；参数格式错误也为 2。原始模型分类正确率单独计分，不把回退效果算作模型提升。
概率未经校准；合成样例不能验证真实麦克风、OCR 和输入法写回。

可选的生成检查字段（只用于评分，绝不传给模型）：

- `expected.modified_text`：要求生成正文与此字符串完全一致。
- `expected.preserve_text`：要求保留的关键文字列表，逐项检查是否存在。

不填写这些字段时不评分生成文本，不能把“未检查”算成质量通过。完整流程命令会在 JSON/HTML 中报告检查结果，检查失败退出码为 2。

## 独立的编辑生成样例

`automatic_edit_order_cases.json` 给 `tools/check_automatic_edit_generation.py` 使用，
与上面的分类样例格式不同：它有意直接提供 `edit_plan.tasks`，以隔离测试组合编辑生成。
该程序不调用 Clef，不能据此报告分类准确率或概率。
48 条开发样例覆盖六类、15 种两类组合、相反步骤顺序、三类串联、撤销和错误候选守卫。
这里的 15 种组合只是测试覆盖；生成提示词没有逐对规则。
`automatic_edit_generalization_cases.json` 是 v8 冻结后首次测试的 12 条新措辞，
覆盖同类多步、位置变化、时间边界、原话和局部撤销；结果未用于继续改本轮提示词。

每条填写 `id`、`utterance`、`target`、`context.messages`、`edit_plan.tasks`、`expected`、`review_points`。
`expected` 支持 `modified_text` 精确全文、`contains` 保留片段、`contains_ci` 不分大小写的片段、
`excludes` 禁止片段、`max_chars` 最大长度。`review_points` 说明需语义复核的重点。
这两项只用于评分，不进入模型请求。无 OCR 写 `{"messages": []}`；无原文只能用允许空源的插入／创作计划。
防误触发样例可以故意指定错误候选，需明确写在复核要点中。

```sh
.runtime/venv/bin/python tools/check_automatic_edit_generation.py \
  --cases tools/data/automatic_edit_order_cases.json \
  --output .runtime/clef/my-edit-generation.json
```

`--validate-only` 不发请求；`--case ID` 可重复以筛选样例。
退出码 0 仅表示全部调用成功，1 表示调用出错；正文约束与逐条语义复核分别看报告。
修改样例会改变文件 SHA256，报告保留当次全部输入、预期及文件摘要；不要覆盖旧报告冒充同一轮结果。

## 原 130 条的真实路由与生成联测

原 v19 报告的同批 130 条保存在 `docs/reports/clef-six-tasks-cases-2026-11-04.json`。
使用该分类样例格式跑完整流程：

```sh
bash scripts/clef-remote.sh pipeline \
  --cases docs/reports/clef-six-tasks-cases-2026-11-04.json \
  --output .runtime/clef/my-full-pipeline.json
```

每条先由 Clef 真实联合判断，再将实际路由交给正文模型；预期标签只评分，不能覆盖实际计划。
听写也运行正文整理。HTML 分别展示最终路由错误、编辑生成问题、听写整理问题及原始标黄选择。
详细记录保存两端实际请求／响应、所有分类概率、分阶段及总延迟、token 和可编辑的逐条复核结论。
`generation_review` 默认 pending，必须对照输入输出复核后填 pass／fail，不能把接口成功或未配置文字约束计成质量通过。
JSONL 保存运行时原始记录，后续复核写回 JSON 并用 `tools.clef_pipeline_report.write_pipeline_report` 重建 HTML。
生成前校验拦截且没有正文 HTTP 请求时，复核状态用 `blocked`，不要把 Worker 回退的口述当成生成结果。

`clef_fidelity_cases.json` 是 v9 提示词冻结后编写的 12 条正反边界样例，用同一 `pipeline` 命令指定 `--cases` 运行。
它重点检查：用户明确补充的新原因／功能／承诺应被采用、允许用户改变旧日期或条件、建议和虚构仍可创作、
OCR 中对方的要求不能覆盖用户决定，以及照录引导语处于正文内部时应保留。
这批是合成小样例，首次结果不会用来修改本轮冻结的提示词，也不能代表独立真实使用准确率。

`clef_ocr_context_cases.json` 是 16 条模拟已过滤 OCR 的首轮样例，覆盖空框回复老板、按只读参考纠正产品名／软件名／人名、
修改与润色组合、多个名称的对应、歧义不猜、明确保留原名、OCR 夹带指令及用户口述优先。
每例有 `utterance`、`target`、`context.messages` 和 `expected`；`review_focus` 只描述复核重点，不传给模型。
这些样例不启动微信、不截图、不调用 OCR、不发送消息，只验证下游模型是否正确利用已经取得的只读文字。
空原文的 `modify` 仍不可用；明确根据 OCR 写新稿可走 `compose`，不能把 OCR 当可修改的原文。

```sh
bash scripts/clef-remote.sh pipeline \
  --cases tools/data/clef_ocr_context_cases.json \
  --output .runtime/clef/my-ocr-pipeline.json
bash scripts/clef-remote.sh pipeline \
  --cases tools/data/clef_fidelity_cases.json \
  --output .runtime/clef/my-fidelity-pipeline.json
```

2026-11-05 的 v19 路由＋v9 生成首轮：OCR 最终路由 14/16，正文通过 13、边界问题 1、未生成 2；
忠实性最终路由与冻结标签匹配 8/12，正文通过 9/12。其中两条标签存在“内容更新＋润色／创作”解释空间，报告保留原始分数并单独注明。
这些结果没有用于继续修改本轮提示词。后续若据此调优，需将它们视为开发回归集。
[汇总及前后对照](../../docs/reports/automatic-edit-v9-summary-2026-11-05.html)、
[OCR 全概率明细](../../docs/reports/clef-v19-generation-v9-ocr-2026-11-05.html)、
[信息忠实性明细](../../docs/reports/clef-v19-generation-v9-fidelity-2026-11-05.html)。

## 手动编辑：单次 DeepSeek 请求分类与生成

`tools/check_llm_single_pass_edit.py` 复用六类定义和现有编辑模块，在一个请求中返回
`分类：修改、润色` 与 `正文：` 后的完整结果，不输出 JSON。输入只含口述、原文和只读 OCR 参考，
预期类别不进入请求。此脚本是测试原型，不接设置项、手势、实时 OCR 或输入法写回。

```sh
.runtime/venv/bin/python tools/check_llm_single_pass_edit.py \
  --output .runtime/clef/single-pass-experiment.json
```

`--validate-only` 只检查样例和提示词；`--case ID` 可筛选样例。每条只允许一次 HTTP 请求，无重试。
完整运行使用同批 150 条编辑样例及 6 条无任务边界样例，全部生成正文。
JSON/JSONL 保留当次原始结果，退出码 1 可能是返回格式或类别错误，应检查逐条记录。

`tools/review_llm_single_pass_edit.py` 在已有响应上离线复核，兼容正文与“正文：”位于同一行，
仍拒绝未知类别，不改模型文字、不重新请求模型。复核清单必须覆盖全部样例；正文通过数来自逐条语义评语。
原始严格格式评分与兼容解析评分同时保留，不能把换行兼容算作模型判断提升。

```sh
.runtime/venv/bin/python tools/review_llm_single_pass_edit.py \
  --raw docs/reports/llm-edit-single-pass-full-2026-11-09.json \
  --reviews docs/reports/llm-edit-single-pass-semantic-reviews-2026-11-09.json \
  --output docs/reports/llm-edit-single-pass-reviewed-2026-11-09.json \
  --summary docs/reports/llm-edit-single-pass-summary-2026-11-09.html
```

[单次请求汇总与流程代码](../../docs/reports/llm-edit-single-pass-summary-2026-11-09.html) ·
[全部逐条结果](../../docs/reports/llm-edit-single-pass-reviewed-2026-11-09.html)
