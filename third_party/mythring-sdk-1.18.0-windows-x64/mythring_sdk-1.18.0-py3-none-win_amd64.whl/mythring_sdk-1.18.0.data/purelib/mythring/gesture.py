"""Firmware gesture control with explicit acknowledged and legacy profiles."""

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from enum import IntEnum
import struct

from mythring.errors import UnsupportedFeatureError

__all__ = [
    "GestureClient", "GestureMode", "WearingHand", "SwipeDirection",
    "GestureControlResult", "HandConfiguration", "SwipeDirectionConfiguration",
    "GestureException", "GestureReply", "accepts_gesture_reply", "parse_gesture_reply",
]


class GestureMode(IntEnum):
    NORMAL = 0
    OFF = 1
    LOW_POWER = 7


class WearingHand(IntEnum):
    RIGHT = 0
    LEFT = 1


class SwipeDirection(IntEnum):
    FORWARD = 0
    REVERSED = 1


@dataclass(frozen=True)
class GestureControlResult:
    mode: GestureMode
    status: int | None = 0
    acknowledged: bool = True


@dataclass(frozen=True)
class HandConfiguration:
    hand: WearingHand
    status: int = 0


@dataclass(frozen=True)
class SwipeDirectionConfiguration:
    direction: SwipeDirection
    status: int = 0


GestureResponse = GestureControlResult | HandConfiguration | SwipeDirectionConfiguration


class GestureException(Exception):
    def __init__(
        self, reason: str, device_code: int | None = None,
        response: GestureResponse | None = None,
    ) -> None:
        super().__init__(reason)
        self.reason = reason
        self.device_code = device_code
        self.response = response


@dataclass(frozen=True)
class GestureReply:
    command: int
    operation: int
    result: GestureResponse


def accepts_gesture_reply(packet: bytes) -> bool:
    return len(packet) >= 2 and (
        packet[:2] == b"\x26\x08" or packet[0] in (0x38, 0x39) and packet[1] == 0x80
    )


def parse_gesture_reply(packet: bytes) -> GestureReply | None:
    if not accepts_gesture_reply(packet):
        return None
    command = packet[0]
    if len(packet) != (5 if command == 0x26 else 6):
        return None
    operation = packet[2]
    status = struct.unpack_from("<h", packet, 3)[0]
    try:
        if command == 0x26:
            result: GestureResponse = GestureControlResult(GestureMode(operation), status)
        else:
            if operation not in (0, 1):
                return None
            if command == 0x38:
                result = HandConfiguration(WearingHand(packet[5]), status)
            else:
                result = SwipeDirectionConfiguration(SwipeDirection(packet[5]), status)
    except ValueError:
        return None
    return GestureReply(command, operation, result)


@dataclass
class _Pending:
    result: asyncio.Future[GestureResponse]
    accepting_ack: bool = False


class GestureClient:
    """Use from one asyncio event loop, including ``accept`` notifications.

    Distinct command/operation pairs may run concurrently. Duplicate pairs
    raise ``busy``. The wire format has no transaction IDs: an ACK arriving
    late for an operation can satisfy a later call for the same operation.
    """

    def __init__(
        self, send: Callable[[bytes, int], Awaitable[None]], *,
        prepare: Callable[[bytes], Awaitable[None]] | None = None,
        timeout: float = 3.0,
    ) -> None:
        if timeout <= 0:
            raise ValueError("timeout must be positive")
        self._send = send
        self._prepare = prepare
        self._timeout = timeout
        self._generation: int | None = None
        self._acknowledged = True
        self._pending: dict[tuple[int, int], _Pending] = {}

    def connected(self, generation: int, *, acknowledged: bool = True) -> None:
        """Select ACK behavior from the device profile, never from a timeout."""
        self._generation = generation
        self._acknowledged = acknowledged
        self._reset()

    def disconnected(self) -> None:
        self._generation = None
        self._reset()

    def _reset(self) -> None:
        pending, self._pending = self._pending, {}
        for call in pending.values():
            if not call.result.done():
                call.result.set_exception(GestureException("disconnected"))

    def accept(self, packet: bytes) -> bool:
        if not accepts_gesture_reply(packet):
            return False
        reply = parse_gesture_reply(packet)
        if reply is not None:
            pending = self._pending.get((reply.command, reply.operation))
            if pending is not None and pending.accepting_ack and not pending.result.done():
                pending.result.set_result(reply.result)
        return True

    async def set_mode(self, mode: GestureMode) -> GestureControlResult:
        return await self._request(bytes((0x26, GestureMode(mode))))  # type: ignore[return-value]

    async def read_hand(self) -> HandConfiguration:
        return await self._request(b"\x38\x00")  # type: ignore[return-value]

    async def set_hand(self, hand: WearingHand) -> HandConfiguration:
        return await self._request(bytes((0x38, 1, WearingHand(hand))))  # type: ignore[return-value]

    async def read_swipe_direction(self) -> SwipeDirectionConfiguration:
        return await self._request(b"\x39\x00")  # type: ignore[return-value]

    async def set_swipe_direction(self, direction: SwipeDirection) -> SwipeDirectionConfiguration:
        return await self._request(bytes((0x39, 1, SwipeDirection(direction))))  # type: ignore[return-value]

    async def _request(self, packet: bytes) -> GestureResponse:
        epoch = self._generation
        if epoch is None:
            raise GestureException("disconnected")
        acknowledged = self._acknowledged
        if not acknowledged and packet not in (b"\x26\x00", b"\x26\x01"):
            raise GestureException("unsupported")
        key = (packet[0], packet[1])
        if key in self._pending:
            raise GestureException("busy")
        call = _Pending(asyncio.get_running_loop().create_future())
        self._pending[key] = call
        sending = False

        async def exchange() -> GestureResponse:
            nonlocal sending
            if self._prepare is not None:
                await self._prepare(packet)
            if self._generation != epoch:
                raise GestureException("disconnected")
            call.accepting_ack = acknowledged
            sending = True
            await self._send(packet, epoch)
            if not acknowledged:
                return GestureControlResult(GestureMode(packet[1]), status=None, acknowledged=False)
            return await call.result

        try:
            reply = await asyncio.wait_for(exchange(), self._timeout)
            if self._generation != epoch:
                raise GestureException("disconnected")
            if reply.status is not None and reply.status != 0:
                raise GestureException("device_error", reply.status, reply)
            return reply
        except asyncio.TimeoutError as error:
            raise GestureException("timeout" if sending else "not_ready") from error
        except GestureException:
            raise
        except UnsupportedFeatureError as error:
            raise GestureException("unsupported") from error
        except Exception as error:
            raise GestureException("send_failed" if sending else "not_ready") from error
        finally:
            if self._pending.get(key) is call:
                del self._pending[key]
            if not call.result.done():
                call.result.cancel()
            elif not call.result.cancelled():
                call.result.exception()
