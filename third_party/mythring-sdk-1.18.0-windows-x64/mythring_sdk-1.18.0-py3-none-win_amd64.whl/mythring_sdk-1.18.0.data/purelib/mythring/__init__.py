"""Unified Ringo/R1 SDK: identity, gestures, touchpad, audio and firmware targets."""
from mythring.client import DiscoveredRing, Ring, scan
from mythring.errors import NotConnectedError, ProtocolError, RequestTimeoutError, RingError, UnsupportedFeatureError
from mythring.gesture import GestureException, GestureMode, SwipeDirection, WearingHand
from mythring.health import HealthError, HealthFeature, HealthMonitoringSettings
from mythring.hid import HidError, HidGesture, HidKey, HidMapping
from mythring.models import Battery, DeviceInfo, InfoComponent, GestureEvent, ImuToken, LinkState, RingStatus

__version__ = "1.18.0"
SOURCE_SDK_VERSION = "1.15.1-touchpad"

__all__ = [
    "Ring", "scan", "DiscoveredRing", "LinkState", "RingStatus", "DeviceInfo", "InfoComponent",
    "Battery", "ImuToken", "GestureEvent", "GestureMode", "WearingHand", "SwipeDirection",
    "GestureException", "HidGesture", "HidKey", "HidMapping", "HidError", "HealthError",
    "HealthFeature", "HealthMonitoringSettings", "RingError", "NotConnectedError",
    "ProtocolError", "RequestTimeoutError", "UnsupportedFeatureError", "SOURCE_SDK_VERSION",
]

from mythring.connection import RingManager, RingDisconnectResult, RingDisconnectOutcome, RingSystemConnectionState
from mythring.touchpad_inference import Motion, ContactUpdate, Click, TouchpadEvent, TouchpadBacklogWarning
from mythring.ota import RingOtaUpdater, update_firmware

__all__ += ["RingManager", "RingDisconnectResult", "RingDisconnectOutcome", "RingSystemConnectionState",
            "Motion", "ContactUpdate", "Click", "TouchpadEvent", "TouchpadBacklogWarning", "RingOtaUpdater", "update_firmware"]
from mythring.health_models import HealthMetric, HealthReport, HealthValue, HealthQuality, HealthDailySummary

__all__ += ["HealthMetric", "HealthReport", "HealthValue", "HealthQuality", "HealthDailySummary"]
from mythring.compatibility import FeatureSupport, CompatibilitySnapshot
from mythring.catalog import list_firmware_targets, get_firmware_target, evaluate_target, bundled_firmware_path
from mythring.audio import AudioClient, AudioFrame
from mythring.touchpad import TouchpadFailureDiagnostics

__all__ += ["FeatureSupport", "CompatibilitySnapshot", "list_firmware_targets",
            "get_firmware_target", "evaluate_target", "bundled_firmware_path", "AudioClient", "AudioFrame",
            "TouchpadFailureDiagnostics"]
