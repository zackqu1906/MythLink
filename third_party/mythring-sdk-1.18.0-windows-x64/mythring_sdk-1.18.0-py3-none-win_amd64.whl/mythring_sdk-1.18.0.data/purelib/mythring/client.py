"""Async BLE transport for R1 rings. One Ring instance owns one GATT session."""
from __future__ import annotations

import asyncio
import logging
import math
import sys
from collections.abc import Callable
from dataclasses import dataclass, field, replace
from typing import Any

from mythring._discovery import retrieve_device, system_connected_devices
from mythring.audio import AudioClient
from mythring.compatibility import CompatibilitySnapshot, FeatureSupport, compatibility_snapshot
from mythring.errors import NotConnectedError, ProtocolError, RequestTimeoutError, UnsupportedFeatureError
from mythring.gesture import GestureClient
from mythring.health import HealthClient
from mythring.hid import HidClient
from mythring.models import Battery, DeviceInfo, GestureEvent, ImuToken, LinkState, RingStatus
from mythring.protocol import (
    CLOSE_IMU, GET_BATTERY, GET_INFO, NOTIFY_CHARACTERISTIC_UUID, OPEN_IMU_TOKEN,
    SERVICE_UUID, WRITE_CHARACTERISTIC_UUID, is_supported_ble_name,
    is_ringo_audio_info, is_ringo_touchpad_info, parse_device_info, parse_packet,
)
from mythring.touchpad import TouchpadClient
from mythring.touchpad_inference import TouchpadRecognizer
from mythring.connection import ConnectedRssiReader, OwnerDisconnectClient, OWNER_UNBIND_COMMAND

_LOG = logging.getLogger(__name__)
_HID_SERVICE = "00001812-0000-1000-8000-00805f9b34fb"


def _positive(value: float, name: str) -> None:
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be positive and finite")


@dataclass(frozen=True)
class DiscoveredRing:
    address: str
    name: str
    rssi: int | None
    device: Any = field(repr=False, compare=False)
    source: str = "advertisement"


async def scan(timeout: float = 5.0) -> list[DiscoveredRing]:
    """Find advertised rings and system-connected candidates on macOS and Windows.

    Windows returns a Bluetooth address, macOS a CoreBluetooth UUID. System-connected results have
    ``source='system_connected'`` and no advertising RSSI (``rssi=None``).
    ``Ring.connect`` validates INFO before accepting a candidate as an R1.
    """
    _positive(timeout, "timeout")
    from bleak import BleakScanner
    found, connected = await asyncio.gather(
        BleakScanner.discover(timeout=timeout, return_adv=True),
        system_connected_devices(SERVICE_UUID, timeout=timeout),
    )
    result = {}
    for device, advertisement in found.values():
        name = advertisement.local_name or device.name
        if is_supported_ble_name(name):
            result[device.address.lower()] = DiscoveredRing(device.address, name, advertisement.rssi, device)
    for device in connected:
        # macOS may cache an old name; NUS discovery yields candidates, INFO confirms R1.
        result.setdefault(device.address.lower(), DiscoveredRing(
            device.address, device.name or device.address, None, device, "system_connected"))
    return sorted(result.values(), key=lambda ring: ring.rssi if ring.rssi is not None else -math.inf,
                  reverse=True)


class Ring:
    """Use on a single asyncio loop; ``connect`` returns only after INFO validation.

    Callbacks are synchronous and must return quickly. Schedule asynchronous work
    yourself with ``asyncio.create_task``. ``disconnect`` only closes this GATT
    client: it never sends the Android SDK's destructive Owner-unbind command.
    """

    def __init__(
        self, device: DiscoveredRing | Any, *, timeout: float = 30.0,
        write_timeout: float = 2.0, health_storage_path=None,
    ):
        _positive(timeout, "timeout")
        _positive(write_timeout, "write_timeout")
        self._device = device.device if isinstance(device, DiscoveredRing) else device
        self.address = device.address if hasattr(device, "address") else str(device)
        self.name = getattr(device, "name", None)
        self.timeout, self.write_timeout = timeout, write_timeout
        self.link_state = LinkState.DISCONNECTED
        self.device_info: DeviceInfo | None = None
        self.status = RingStatus()
        self._client = None
        self._write_characteristic = None
        self._write_response = True
        self._generation = 0
        self._lifecycle_lock = asyncio.Lock()
        self._write_lock = asyncio.Lock()
        self._battery_lock = asyncio.Lock()
        self._pending: dict[bytes, asyncio.Future] = {}
        self._listeners: dict[str, list[Callable]] = {}
        self._disconnected = asyncio.Event()
        self._disconnected.set()
        self._post_connect_task: asyncio.Task | None = None
        self._firmware_maintenance = None
        self._imu_active = False
        self._touchpad_lock = asyncio.Lock()
        self._rssi = ConnectedRssiReader()
        self.owner = OwnerDisconnectClient(
            self._send_gesture, generation=lambda: self._generation, ready=lambda: self.is_connected,
            on_result=lambda result: self._emit("owner_disconnect", result), write_timeout=write_timeout,
        )
        self._recognizer = TouchpadRecognizer(
            lambda event: self._emit("touchpad_event", event),
            on_error=lambda error: self.touchpad._fail(error),
            on_warning=lambda warning: self._emit("warning", warning),
        )
        self.gesture = GestureClient(self._send_gesture, prepare=self._prepare_gesture)
        self.hid = HidClient(self.send_command)
        self.health = HealthClient(self.send_command, mtu=lambda: self.mtu_size,
                                   address=self.address, storage_path=health_storage_path)
        self.touchpad = TouchpadClient(
            self.send_command,
            on_tokens=lambda tokens: self._emit("touchpad_tokens", tokens),
            on_error=self._touchpad_failed,
            on_packet=self._recognizer.submit,
            on_diagnostics=lambda snapshot: self._emit("touchpad_diagnostics", snapshot),
        )
        self.audio = AudioClient(
            self._send_audio, prepare=self._prepare_audio,
            on_frame=lambda frame: self._emit("audio_frame", frame),
        )

    @property
    def is_connected(self) -> bool:
        return self.link_state == LinkState.CONNECTED and bool(self._client and self._client.is_connected)

    @property
    def mtu_size(self) -> int:
        return self._client.mtu_size if self._client and self._client.is_connected else 23

    @property
    def protocol_profile(self) -> str | None:
        """Selected protocol family, established by INFO rather than the BLE name."""
        if self.device_info is None:
            return None
        info = self.device_info
        if is_ringo_touchpad_info(info):
            return "ringo_touchpad_v2"
        major = info.firmware_numeric_version[0]
        if info.hardware_revision == 1 or major == 1:
            return "legacy_v1"
        if info.hardware_revision == 2 and major == 2:
            return "r1_v2"
        return "unknown"

    @property
    def capabilities(self) -> dict[str, bool]:
        """Implemented device operations; an absent key is not a support claim.

        Legacy component presence does not establish support for new protocols.
        Raw2 and health still perform their own negotiation on current hardware.
        """
        info = self.device_info
        if info is None:
            return {}
        current = self.protocol_profile == "r1_v2"
        legacy = self.protocol_profile == "legacy_v1"
        ringo = self.protocol_profile == "ringo_touchpad_v2"
        imu_present = any(row.id == 1 and row.present for row in info.components)
        return {
            "battery": True, "rssi": True,
            "gesture": current or ((legacy or ringo) and info.swipe_available),
            "gesture_low_power": current, "gesture_config": current,
            "imu": current or (legacy and imu_present),
            "touchpad": current or ringo, "touchpad_raw": current or ringo, "health": current,
            "hid": current, "ota": current, "owner_unbind": current,
            "audio": is_ringo_audio_info(info),
        }

    @property
    def compatibility(self) -> CompatibilitySnapshot:
        """Immutable INFO-based support snapshot; does not probe or start features."""
        return compatibility_snapshot(self.device_info, self.protocol_profile, self.capabilities)

    def feature_support(self, feature: str) -> FeatureSupport:
        """Explain support separately from connection, sensor and model readiness."""
        return self.compatibility.feature_support(feature)

    def _require_feature(self, feature: str) -> None:
        if not self.is_connected:
            raise NotConnectedError("Ring is not connected")
        if self.capabilities.get(feature) is False:
            raise UnsupportedFeatureError(feature, self.protocol_profile)

    def on(self, event: str, callback: Callable) -> Callable[[], None]:
        """Subscribe; returns an idempotent unsubscribe function.

        Events: link_state, status, gesture, imu_token, touchpad_tokens, raw_packet,
        touchpad_event, touchpad_diagnostics, audio_frame, owner_disconnect, warning,
        error. Callbacks receive one value, never the Ring instance.
        """
        if event not in {"link_state", "status", "gesture", "imu_token", "touchpad_tokens", "touchpad_event", "touchpad_diagnostics", "audio_frame", "owner_disconnect", "raw_packet", "warning", "error"}:
            raise ValueError(f"Unknown event: {event}")
        callbacks = self._listeners.setdefault(event, [])
        callbacks.append(callback)

        def unsubscribe():
            if callback in callbacks:
                callbacks.remove(callback)
        return unsubscribe

    def _emit(self, event: str, value: Any) -> None:
        for callback in tuple(self._listeners.get(event, ())):
            try:
                callback(value)
            except Exception:
                _LOG.exception("Ring %s callback failed", event)

    def _set_state(self, state: LinkState) -> None:
        if state != self.link_state:
            self.link_state = state
            self._emit("link_state", state)

    async def __aenter__(self) -> Ring:
        await self.connect()
        return self

    async def __aexit__(self, *_exc) -> None:
        await self.disconnect()

    async def connect(self) -> None:
        """Connect, subscribe to NUS, and validate R1 INFO; clean up on failure."""
        from bleak import BleakClient
        async with self._lifecycle_lock:
            if self._firmware_maintenance:
                raise ProtocolError("Firmware maintenance owns this ring")
            if self.is_connected:
                return
            if self._client is not None:
                await self._close(self._generation, self._client)
            self._generation += 1
            generation = self._generation
            self._disconnected.clear()
            self._set_state(LinkState.CONNECTING)
            try:
                device = self._device
                if isinstance(device, str):
                    device = await retrieve_device(device, timeout=self.timeout) or device
                client = BleakClient(
                    device, timeout=self.timeout,
                    winrt={"use_cached_services": False},
                    disconnected_callback=lambda sender: self._lost(generation, sender),
                )
            except BaseException:
                self._lost(generation, None)
                raise
            self._client = client

            async def initialize():
                await client.connect()
                if generation != self._generation:
                    raise NotConnectedError("Connection changed during discovery")
                if client.services.get_service(SERVICE_UUID) is None:
                    raise ProtocolError("Required R1 NUS service is missing")
                write = client.services.get_characteristic(WRITE_CHARACTERISTIC_UUID)
                notify = client.services.get_characteristic(NOTIFY_CHARACTERISTIC_UUID)
                if write is None or notify is None:
                    raise ProtocolError("Required R1 NUS characteristics are missing")
                if "write" not in write.properties and "write-without-response" not in write.properties:
                    raise ProtocolError("NUS RX characteristic is not writable")
                self._write_characteristic = write
                self._write_response = "write" in write.properties
                await client.start_notify(notify, lambda _sender, data: self._notification(generation, bytes(data)))
                packet = await self._request(GET_INFO, b"\x2a\x02", min(5.0, self.timeout), generation, initializing=True)
                info = parse_device_info(packet)
                if info is None:
                    raise ProtocolError("Invalid R1 INFO identity/version")
                if generation != self._generation or not client.is_connected:
                    raise NotConnectedError("Connection changed during initialization")
                self.device_info = info
                self.status = RingStatus(software_version=info.firmware_version)
                self.touchpad.disconnected()
                self._imu_active = False
                self.audio.connected(supported=self.capabilities["audio"], profile=self.protocol_profile)
                self.gesture.connected(generation, acknowledged=self.protocol_profile == "r1_v2")
                hid_profile = self.capabilities["hid"]
                hid_visible = hid_profile and client.services.get_service(_HID_SERVICE) is not None
                # WinRT hides OS-owned HIDS. Firmware mapping commands use NUS.
                probe_hid = hid_profile and sys.platform == "win32" and not hid_visible
                self.hid.connected(hid_visible or probe_hid, probe_before_save=probe_hid)
                self.health.connection_opened()
                self._set_state(LinkState.CONNECTED)
                self._emit("status", self.status)

            try:
                await asyncio.wait_for(initialize(), self.timeout)
            except BaseException:
                await self._close(generation, client)
                raise
            # Optional health status failures do not turn an initialized link into failure.
            if self.capabilities["health"]:
                self._post_connect_task = asyncio.create_task(self._refresh_health(generation))

    async def _refresh_health(self, generation: int) -> None:
        try:
            if generation == self._generation:
                await self.health.connected()
        except asyncio.CancelledError:
            raise
        except Exception as error:
            _LOG.info("Optional health initialization failed: %s", error)
            self._emit("error", error)

    def _lost(self, generation: int, client: Any, *, remote: bool = True) -> None:
        if generation != self._generation or client is not self._client:
            return
        self.owner.connection_lost(generation, remote=remote)
        self._rssi.invalidate(generation)
        self._recognizer.invalidate()
        self._generation += 1
        self._client = self._write_characteristic = None
        self.device_info = None
        self.status = RingStatus()
        task, self._post_connect_task = self._post_connect_task, None
        if task and task is not asyncio.current_task() and not task.done():
            task.cancel()
        for future in self._pending.values():
            if not future.done():
                future.set_exception(NotConnectedError("Ring disconnected"))
        self._pending.clear()
        self.gesture.disconnected()
        self.hid.disconnected()
        self.health.disconnected()
        self.touchpad.disconnected()
        self.audio.disconnected()
        self._imu_active = False
        self._disconnected.set()
        self._set_state(LinkState.DISCONNECTED)
        self._emit("status", self.status)

    async def _close(self, generation: int, client: Any) -> None:
        self._lost(generation, client, remote=False)
        if client:
            try:
                await asyncio.wait_for(client.disconnect(), 5.0)
            except Exception as error:
                _LOG.warning("BLE resource release failed: %s", error)

    async def disconnect(self) -> None:
        """Release this local GATT connection without clearing Owner binding."""
        async with self._lifecycle_lock:
            if self._client is not None:
                await self._close(self._generation, self._client)

    async def wait_disconnected(self) -> None:
        await self._disconnected.wait()

    def _notification(self, generation: int, packet: bytes) -> None:
        if generation != self._generation:
            return
        try:
            pending = self._pending.get(packet[:2])
            if pending is not None and not pending.done():
                # A corrupt battery notification must not satisfy a request.
                if packet[:2] != b"\x29\x02" or parse_packet(packet):
                    pending.set_result(packet)
            if self.link_state == LinkState.CONNECTED:
                if not (self.owner.accept(packet, generation) or self.touchpad.feed(packet) or self.gesture.accept(packet) or
                        self.hid.accept(packet) or self.health.accept(packet) or self.audio.accept(packet)):
                    for event in parse_packet(packet):
                        if isinstance(event, Battery):
                            self.status = replace(self.status, battery=event.percent)
                            self._emit("status", self.status)
                        elif isinstance(event, GestureEvent):
                            self._emit("gesture", event)
                        elif isinstance(event, ImuToken):
                            self._emit("imu_token", event)
        except Exception as error:
            self._emit("error", error)
        self._emit("raw_packet", packet)

    async def _write(self, packet: bytes, generation: int, *, initializing: bool = False) -> None:
        async with self._write_lock:
            if self._firmware_maintenance:
                raise ProtocolError("Firmware maintenance owns this ring")
            if self.owner.is_unbinding and packet != OWNER_UNBIND_COMMAND:
                raise ProtocolError("Owner unbind is in progress")
            if (getattr(self, "_firmware_update_owner", None) is not None and
                    packet[:2] in (b"\x20\x00", b"\x21\x00", b"\x24\x00", b"\x28\x00", b"\x3c\x00")):
                raise ProtocolError("Firmware update preparation blocks sensor starts")
            client = self._client
            if (generation != self._generation or not client or not client.is_connected or
                    (self.link_state != LinkState.CONNECTED and not initializing)):
                raise NotConnectedError("R1 data channel is not ready or has changed")
            if self._write_characteristic is None:
                raise NotConnectedError("NUS notifications are not initialized")
            if self.device_info is not None:
                feature = {0x20: "audio", 0x3A: "health", 0x3C: "touchpad", 0x37: "owner_unbind",
                           0x38: "gesture_config", 0x39: "gesture_config"}.get(packet[0])
                if packet[:2] in (b"\x30\x03", b"\x30\x04"):
                    feature = "hid"
                elif packet[:2] == b"\x26\x07":
                    feature = "gesture_low_power"
                if feature and self.capabilities.get(feature) is False:
                    raise UnsupportedFeatureError(feature, self.protocol_profile)
            if packet[:2] == b"\x20\x00":
                if self._imu_active or self._touchpad_lock.locked() or self.touchpad.active or self.touchpad.stage.value in ("starting", "running"):
                    raise ProtocolError("Stop IMU and touchpad before starting audio")
            elif self.audio.active and (packet[:2] in (b"\x21\x00", b"\x24\x00", b"\x28\x00", b"\x3c\x00")):
                raise ProtocolError("Stop audio before starting IMU or touchpad")
            if packet[:1] == b"\x3a" and self.mtu_size < 64:
                raise ProtocolError("Health requires BLE MTU >= 64")
            if packet[:1] in (b"\x21", b"\x24", b"\x28") and packet[1:2] == b"\x00":
                if self.capabilities.get("health", True) and self.health.blocks_sensor_start:
                    raise ProtocolError("Health owns the sensors or its state is not yet known; call health.refresh_status()")
            if not self._write_response and len(packet) > self._write_characteristic.max_write_without_response_size:
                raise ProtocolError("Command exceeds negotiated write size")
            try:
                await asyncio.wait_for(client.write_gatt_char(
                    self._write_characteristic, packet, response=self._write_response,
                ), self.write_timeout)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                # A submitted write with unknown completion cannot share a later session slot.
                await self._close(generation, client)
                raise
            if generation != self._generation:
                raise NotConnectedError("Connection changed during write")
            if packet[:2] == b"\x21\x00":
                self._imu_active = True
            elif packet[:2] == b"\x21\x01":
                self._imu_active = False

    async def send_command(self, packet: bytes) -> None:
        """Send one raw NUS command; successful return confirms ATT write, not a business ACK.

        This is an advanced interface. Do not use it to bypass a subclient's
        request matching or to send destructive firmware maintenance commands.
        """
        packet = bytes(packet)
        if not packet or len(packet) > 512:
            raise ValueError("A NUS command must contain 1..512 bytes")
        if packet[:2] in (b"\x20\x00", b"\x20\x01"):
            raise ProtocolError("Use start_audio()/stop_audio() to preserve microphone stream state")
        await self._write(packet, self._generation)

    async def _request(self, command: bytes, prefix: bytes, timeout: float, generation: int, *, initializing: bool = False) -> bytes:
        if prefix in self._pending:
            raise ProtocolError("Another request for this response is pending")
        future = asyncio.get_running_loop().create_future()
        self._pending[prefix] = future
        try:
            await self._write(command, generation, initializing=initializing)
            try:
                return await asyncio.wait_for(future, timeout)
            except asyncio.TimeoutError as error:
                raise RequestTimeoutError(f"No response for {command.hex(' ')}") from error
        finally:
            if self._pending.get(prefix) is future:
                self._pending.pop(prefix)
            if not future.done():
                future.cancel()
            elif not future.cancelled():
                future.exception()

    async def get_battery_level(self, timeout: float = 3.0) -> int:
        _positive(timeout, "timeout")
        generation = self._generation
        async with self._battery_lock:
            if self.protocol_profile == "ringo_touchpad_v2":
                # Ringo permits one control exchange, including the whole START handshake.
                async with self._touchpad_lock:
                    packet = await self._request(GET_BATTERY, b"\x29\x02", timeout, generation)
            else:
                packet = await self._request(GET_BATTERY, b"\x29\x02", timeout, generation)
            return parse_packet(packet)[0].percent

    async def _send_audio(self, packet: bytes) -> None:
        await self._write(packet, self._generation)

    async def _send_gesture(self, packet: bytes, generation: int) -> None:
        if self.protocol_profile == "ringo_touchpad_v2":
            if self._touchpad_lock.locked():
                raise ProtocolError("Ringo control operation is in progress")
            async with self._touchpad_lock:
                await self._write(packet, generation)
            return
        await self._write(packet, generation)

    async def _prepare_gesture(self, packet: bytes) -> None:
        self._require_feature("gesture" if packet[0] == 0x26 else "gesture_config")
        if self.protocol_profile == "r1_v2" and packet[0] == 0x26 and packet[1] != 1 and self.mtu_size < 68:
            raise ProtocolError("Gesture recognition requires BLE MTU >= 68")

    async def _prepare_audio(self) -> None:
        self._require_feature("audio")
        if self._imu_active or self._touchpad_lock.locked() or self.touchpad.active or self.touchpad.stage.value in ("starting", "running"):
            raise ProtocolError("Stop IMU and touchpad before starting audio")
        if self._firmware_maintenance or getattr(self, "_firmware_update_owner", None) or self.owner.is_unbinding:
            raise ProtocolError("Ring maintenance is in progress")

    async def start_audio(self, *, hardware_gain_db=None, software_gain_db=None):
        """Explicitly start microphone frames; does not record or play audio."""
        return await self.audio.start(hardware_gain_db=hardware_gain_db,
                                      software_gain_db=software_gain_db)

    async def stop_audio(self) -> None:
        """Submit the microphone stop command; this protocol has no business ACK."""
        await self.audio.stop()

    async def start_imu_tokens(self) -> None:
        """Start legacy six-feature encoder tokens; unavailable during health ownership."""
        self._require_feature("imu")
        await self.send_command(OPEN_IMU_TOKEN)

    async def stop_imu_tokens(self) -> None:
        self._require_feature("imu")
        await self.send_command(CLOSE_IMU)

    def _touchpad_failed(self, error: Exception) -> None:
        self._recognizer.invalidate()
        self._emit("error", error)

    def _check_touchpad_connection(self, generation: int, *, starting: bool = False) -> None:
        if generation != self._generation or not self.is_connected:
            raise NotConnectedError("Touchpad connection changed while waiting")
        if self._firmware_maintenance or self.owner.is_unbinding:
            raise ProtocolError("Ring maintenance is in progress")
        if starting and getattr(self, "_firmware_update_owner", None) is not None:
            raise ProtocolError("Firmware update preparation blocks sensor starts")
        self._require_feature("touchpad")

    async def start_touchpad(self):
        """Start CPU inference and publish Motion, ContactUpdate and Click events."""
        generation = self._generation
        async with self._touchpad_lock:
            self._check_touchpad_connection(generation, starting=True)
            if self.audio.active:
                raise ProtocolError("Stop audio before starting touchpad")
            try:
                await self._recognizer.start()
                self._check_touchpad_connection(generation, starting=True)
                return await self.touchpad.start(mtu=self.mtu_size,
                    ringo=self.protocol_profile == "ringo_touchpad_v2")
            except BaseException:
                await self._recognizer.stop()
                raise

    async def start_touchpad_raw(self):
        """Start validated Raw2 inputs without model inference (diagnostics)."""
        generation = self._generation
        async with self._touchpad_lock:
            self._check_touchpad_connection(generation, starting=True)
            if self.audio.active:
                raise ProtocolError("Stop audio before starting touchpad")
            await self._recognizer.stop()
            self._check_touchpad_connection(generation, starting=True)
            return await self.touchpad.start(mtu=self.mtu_size,
                ringo=self.protocol_profile == "ringo_touchpad_v2")

    async def stop_touchpad(self):
        generation = self._generation
        async with self._touchpad_lock:
            self._check_touchpad_connection(generation)
            await self._recognizer.stop()
            self._check_touchpad_connection(generation)
            return await self.touchpad.stop()

    async def read_rssi(self, timeout: float = 1.0) -> int | None:
        """Read live connected RSSI; None means unavailable, stale or timed out."""
        return await self._rssi.read(self, timeout)

    async def owner_unbind(self):
        """Explicitly reset firmware Owner binding; inspect the returned outcome."""
        self._require_feature("owner_unbind")
        return await self.owner.unbind()


__all__ = ["Ring", "DiscoveredRing", "scan"]
