"""Connection and request errors raised by the Python transport."""


class RingError(Exception):
    """Base transport error."""


class NotConnectedError(RingError):
    """The initialized NUS connection is unavailable or has changed."""


class ProtocolError(RingError):
    """The ring returned an invalid or unsupported protocol response."""


class RequestTimeoutError(RingError):
    """A reply did not arrive; the remote result may be unknown."""


class UnsupportedFeatureError(RingError, NotImplementedError):
    """This SDK backend does not implement the feature for this device profile."""

    reason = "unsupported"

    def __init__(self, feature: str, profile: str):
        self.feature, self.profile = feature, profile
        super().__init__(f"{feature} is not supported by the {profile} firmware backend")


__all__ = ["RingError", "NotConnectedError", "ProtocolError", "RequestTimeoutError", "UnsupportedFeatureError"]
