"""R1/Ringo Raw2 v2 feature transport, used by the CPU touchpad inference runtime.

Wire layouts are ported from Android 1.15.1 ``RingProtocol.java`` and
``ModelProfile.java``. Tokens are model inputs, not mouse motion or clicks.
"""

from __future__ import annotations

import asyncio
import logging
import struct
import time
from collections.abc import Awaitable, Callable, Sequence
from dataclasses import asdict, dataclass, replace
from enum import Enum

MODEL_ID = 0x77762A23
MODEL_PROFILE = "r1-raw2-mlp8-htp-aligned-v1"
PROTOCOL_VERSION = 2
TOKEN_BYTES = 28
START = bytes((0x3C, 0, 2, 1, 0, 0))
STOP = bytes((0x3C, 1))
STATUS = bytes((0x3C, 3))
DIAGNOSTICS = bytes((0x3C, 4))
INFO = bytes((0x2A, 1))
_MASK = 0xFFFFFFFF
_LOG = logging.getLogger(__name__)


class TouchpadProtocolError(ValueError):
    """Malformed packet or stream discontinuity; stop and start a new session."""


class TouchpadDeviceMismatch(TouchpadProtocolError):
    """The firmware frontend is incompatible with this Raw2 model profile."""


class TouchpadSequenceError(TouchpadProtocolError):
    """A first token or sequence number is invalid."""


class TouchpadUnavailableError(RuntimeError):
    """The protected model runtime could not be initialized."""


class _InitialStopAckTimeout(TimeoutError):
    """The idempotent initialization STOP was written but not acknowledged."""


@dataclass(frozen=True)
class TouchpadToken:
    session: int
    epoch: int
    sequence: int
    uptime: int
    reset: bool
    features: tuple[float, ...]


@dataclass(frozen=True)
class TouchpadStatus:
    state: int
    result: int
    session: int
    epoch: int
    frames: int
    tokens: int
    sent: int
    dropped: int
    resets: int
    max_us: int
    last_us: int
    total_us: int
    deadline: int

    @property
    def stopped(self) -> bool:
        # A latched firmware fault (state 2) also has no active stream.
        return self.result == 0 and self.state in (0, 2)


@dataclass(frozen=True)
class TouchpadDiagnostics:
    phase: int
    session: int
    input_depth: int
    input_high_water: int
    tx_depth: int
    tx_high_water: int
    max_consume_gap_ms: int
    max_input_age_ms: int
    max_send_us: int
    max_tx_age_ms: int
    current_send_ms: int
    fault_phase: int
    fault_input_depth: int
    fault_tx_depth: int
    last_send_result: int
    fault_kind: int

    @property
    def fault_name(self) -> str:
        names = (
            "none", "imu_input_queue_full", "feature_tx_queue_full",
            "feature_tx_age_exceeded", "ble_send_failed", "frontend_failure",
            "invalid_imu_input", "worker_wakeup_failed",
        )
        return names[self.fault_kind] if self.fault_kind < len(names) else f"unknown_{self.fault_kind}"


@dataclass(frozen=True)
class TouchpadFailureDiagnostics:
    """Post-failure evidence after an acknowledged STOP; not a recovery result."""

    error_type: str | None
    error_message: str | None
    status: TouchpadStatus
    diagnostics: TouchpadDiagnostics | None
    diagnostics_error: str | None = None

    def to_dict(self) -> dict:
        result = asdict(self)
        if self.diagnostics is not None:
            result["diagnostics"]["fault_name"] = self.diagnostics.fault_name
        return result


def _matches(packet: bytes, family: int, operation: int) -> bool:
    return len(packet) >= 2 and packet[0] == family and packet[1] == operation


def parse_token(packet: bytes) -> TouchpadToken:
    if (len(packet) != TOKEN_BYTES or not _matches(packet, 0x3C, 2)
            or packet[2] != PROTOCOL_VERSION or packet[3] & ~1):
        raise TouchpadProtocolError("Invalid Raw2 token format")
    quantized = struct.unpack_from("8b", packet, 20)
    if -128 in quantized:
        raise TouchpadProtocolError("Reserved Raw2 feature value -128")
    features = tuple(value / (64 if channel in (1, 5, 6) else 32)
                     for channel, value in enumerate(quantized))
    return TouchpadToken(*struct.unpack_from("<4I", packet, 4), bool(packet[3] & 1), features)


def parse_tokens(packet: bytes) -> tuple[TouchpadToken, ...]:
    """Validate an entire single/batch notification before exposing any token."""
    if _matches(packet, 0x3C, 2):
        return (parse_token(packet),)
    if len(packet) < 4 or not _matches(packet, 0x3C, 0x13) or packet[2] != PROTOCOL_VERSION:
        raise TouchpadProtocolError("Invalid Raw2 batch format")
    count = packet[3]
    if not 2 <= count <= 15 or len(packet) != 4 + TOKEN_BYTES * count:
        raise TouchpadProtocolError("Invalid Raw2 batch count or length")
    tokens = tuple(parse_token(packet[4 + i * TOKEN_BYTES:4 + (i + 1) * TOKEN_BYTES])
                   for i in range(count))
    if any(token.session != tokens[0].session for token in tokens):
        raise TouchpadProtocolError("A Raw2 batch cannot cross sessions")
    return tokens


def parse_status(packet: bytes) -> TouchpadStatus:
    if (len(packet) != 64 or not _matches(packet, 0x3C, 0x11)
            or packet[2] != PROTOCOL_VERSION or packet[3] > 2):
        raise TouchpadProtocolError("Invalid Raw2 status format")
    if struct.unpack_from("<I", packet, 44)[0] != MODEL_ID:
        raise TouchpadDeviceMismatch(f"Expected frontend model_id 0x{MODEL_ID:08x}")
    if struct.unpack_from("<HH4B", packet, 48) != (200, 100, 8, 255, 1, 1):
        raise TouchpadDeviceMismatch("Frontend rate, feature, quantization or coordinate mismatch")
    return TouchpadStatus(packet[3], struct.unpack_from("<i", packet, 4)[0],
                          *struct.unpack_from("<9I", packet, 8),
                          *struct.unpack_from("<2I", packet, 56))


def parse_diagnostics(packet: bytes) -> TouchpadDiagnostics:
    if len(packet) != 64 or not _matches(packet, 0x3C, 0x12) or packet[2] != PROTOCOL_VERSION:
        raise TouchpadProtocolError("Invalid Raw2 diagnostics format")
    return TouchpadDiagnostics(packet[3], *struct.unpack_from("<13I", packet, 4),
                              struct.unpack_from("<i", packet, 56)[0],
                              struct.unpack_from("<I", packet, 60)[0])


def parse_info(packet: bytes, *, ringo: bool = False) -> str:
    if len(packet) < 10 or not _matches(packet, 0x2A, 2) or packet[2] != 1:
        raise TouchpadProtocolError("Invalid R1 INFO format")
    end = 9 + 5 * packet[8]
    if end >= len(packet) or len(packet) != end + 1 + packet[end]:
        raise TouchpadProtocolError("Invalid R1 INFO length")
    try:
        version = packet[end + 1:].decode("utf-8", errors="strict")
    except UnicodeDecodeError as error:
        raise TouchpadProtocolError("Invalid R1 INFO UTF-8") from error
    if ringo:
        from mythring.protocol import is_ringo_touchpad_info, parse_device_info
        info = parse_device_info(packet)
        if info is None or not is_ringo_touchpad_info(info):
            raise TouchpadDeviceMismatch("Ringo Raw2 requires the supported hardware type 1 touchpad firmware")
    elif packet[3] != 2:
        raise TouchpadDeviceMismatch("Raw2 requires R1 hardware type 2")
    # Android Raw2 treats this string as metadata; STATUS and first token gate compatibility.
    return version


@dataclass
class TokenTracker:
    """Transactional uint32 sequence, epoch and device uptime validation."""

    session: int = 0
    epoch: int = 0
    sequence: int = 0
    uptime: int = 0
    first: bool = True

    def start(self, status: TouchpadStatus) -> None:
        self.session, self.epoch, self.first = status.session, status.epoch, True

    def accept_all(self, tokens: Sequence[TouchpadToken]) -> tuple[bool, ...]:
        if not tokens:
            raise TouchpadProtocolError("Empty Raw2 token batch")
        trial = replace(self)
        resets = tuple(trial.accept(token) for token in tokens)
        self.session, self.epoch = trial.session, trial.epoch
        self.sequence, self.uptime, self.first = trial.sequence, trial.uptime, trial.first
        return resets

    def accept(self, token: TouchpadToken) -> bool:
        if token.session != self.session:
            raise TouchpadProtocolError("Raw2 session mismatch; STOP/START required")
        if self.first:
            if token.sequence != 0 or token.epoch != self.epoch or not token.reset:
                raise TouchpadSequenceError("First token must be reset sequence 0 at the START epoch")
        else:
            expected = (self.sequence + 1) & _MASK
            if token.sequence != expected:
                raise TouchpadSequenceError(f"Raw2 sequence gap: expected {expected}, got {token.sequence}")
            if token.epoch != self.epoch and (not token.reset or token.epoch != (self.epoch + 1) & _MASK):
                raise TouchpadProtocolError("Raw2 epoch and reset flag are inconsistent")
            if token.epoch == self.epoch and token.reset:
                raise TouchpadProtocolError("Duplicate Raw2 reset flag")
            elapsed = (token.uptime - self.uptime) & _MASK
            if elapsed == 0 or elapsed > 3000:
                raise TouchpadProtocolError("Raw2 device uptime is discontinuous")
        reset = self.first or token.epoch != self.epoch
        self.first, self.epoch, self.sequence, self.uptime = False, token.epoch, token.sequence, token.uptime
        return reset


def sample_arrival(tokens: Sequence[TouchpadToken], index: int, arrival_ns: int) -> int:
    """Anchor the newest validated token at arrival; this does not measure radio latency."""
    age_ms = (tokens[-1].uptime - tokens[index].uptime) & _MASK
    return arrival_ns - age_ms * 1_000_000


class TouchpadStage(str, Enum):
    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    FAILED = "failed"


class TouchpadClient:
    """Serialized Raw2 INFO/STOP/START handshake and validated feature callbacks.

    Call ``feed`` from the same asyncio loop as ``start``. Callbacks must be
    synchronous and fast. ``RUNNING`` means raw features are arriving, not that
    touchpad inference is available. An ambiguous command quarantines this channel
    until a new connection because the firmware has no request transaction ID.
    Only Ringo's initial, idempotent STOP may retry a missing acknowledgement.
    """

    INITIAL_STOP_BUDGET = 12.0
    INITIAL_STOP_ATTEMPT = 3.0
    INITIAL_STOP_RETRY_DELAY = 0.25

    def __init__(self, send: Callable[[bytes], Awaitable[None]], timeout: float = 3.0,
                 *, on_tokens: Callable[[tuple[TouchpadToken, ...]], None] | None = None,
                 on_packet: Callable[[tuple[TouchpadToken, ...], int], None] | None = None,
                 on_error: Callable[[Exception], None] | None = None,
                 on_diagnostics: Callable[[TouchpadFailureDiagnostics], None] | None = None) -> None:
        if timeout <= 0:
            raise ValueError("timeout must be positive")
        self._send, self.timeout = send, timeout
        self.on_tokens, self.on_packet, self.on_error = on_tokens, on_packet, on_error
        self.on_diagnostics = on_diagnostics
        self.last_failure_diagnostics: TouchpadFailureDiagnostics | None = None
        self.stage = TouchpadStage.STOPPED
        self.status: TouchpadStatus | None = None
        self.version: str | None = None
        self.error: Exception | None = None
        self._lock = asyncio.Lock()
        self._pending: tuple[tuple[int, int], asyncio.Future[bytes], bool] | None = None
        self._first: asyncio.Future[None] | None = None
        self._tracker = TokenTracker()
        self._accepting = False
        self._active = False
        self._quarantined = False
        self._last_input_ns = 0
        self._watchdog: asyncio.Task[None] | None = None
        self._cleanup: asyncio.Task[None] | None = None
        self._generation = 0

    @property
    def active(self) -> bool:
        """START may have reached the ring and no STOP has been confirmed yet.

        This includes failed/uncertain streams and cleanup in progress; it is
        an occupancy guard, not proof that feature packets are still flowing.
        """
        return self._active

    def _check_generation(self, generation: int) -> None:
        if generation != self._generation:
            raise ConnectionError("Touchpad operation belongs to an earlier connection")

    async def _request(self, command: bytes, reply: tuple[int, int], generation: int,
                       *, timeout: float | None = None, retry_initial_stop_ack: bool = False) -> bytes:
        self._check_generation(generation)
        if self._quarantined:
            raise RuntimeError("Touchpad command result unknown; reconnect before retrying")
        result: asyncio.Future[bytes] = asyncio.get_running_loop().create_future()
        self._pending = (reply, result, command == START)
        write_completed = False
        try:
            # Include the write in the same budget, as in the Android implementation.
            async def complete() -> bytes:
                nonlocal write_completed
                self._check_generation(generation)
                if command == START:
                    self._active = True
                await self._send(command)
                write_completed = True
                self._check_generation(generation)
                packet = await result
                self._check_generation(generation)
                if command == STOP and parse_status(packet).stopped:
                    self._active = False
                return packet
            return await asyncio.wait_for(complete(), self.timeout if timeout is None else timeout)
        except asyncio.TimeoutError as error:
            if retry_initial_stop_ack and command == STOP and write_completed:
                raise _InitialStopAckTimeout("Initial STOP acknowledgement timed out") from error
            if generation == self._generation:
                self._quarantined = True
            raise
        except asyncio.CancelledError:
            if generation == self._generation:
                self._quarantined = True
            raise
        except Exception:
            if generation == self._generation and not result.done():
                self._quarantined = True
            raise
        finally:
            if self._pending is not None and self._pending[1] is result:
                self._pending = None
            if not result.done():
                result.cancel()
            elif not result.cancelled():
                result.exception()

    async def _initial_stop(self, generation: int, *, ringo: bool) -> None:
        loop = asyncio.get_running_loop()
        deadline = loop.time() + self.INITIAL_STOP_BUDGET
        try:
            while True:
                self._check_generation(generation)
                remaining = deadline - loop.time()
                if ringo and remaining <= 0:
                    self._quarantined = True
                    raise TimeoutError("Ringo initial STOP acknowledgement deadline expired")
                try:
                    stopped = parse_status(await self._request(
                        STOP, (0x3C, 0x11), generation,
                        timeout=min(self.timeout, self.INITIAL_STOP_ATTEMPT, remaining) if ringo else None,
                        retry_initial_stop_ack=ringo))
                    if not stopped.stopped:
                        raise TouchpadProtocolError(f"STOP refused: state={stopped.state}, result={stopped.result}")
                    return
                except _InitialStopAckTimeout:
                    # Only a completed, idempotent STOP may bridge Ringo's security setup delay.
                    await asyncio.sleep(min(self.INITIAL_STOP_RETRY_DELAY, max(0, deadline - loop.time())))
        except asyncio.CancelledError:
            if generation == self._generation:
                self._quarantined = True
            raise

    async def start(self, *, mtu: int, ringo: bool = False) -> TouchpadStatus:
        """Start raw features after identity checks and the first valid reset token.

        ``ringo=True`` selects the delivered hardware-1 touchpad firmware;
        the default retains the hardware-2 R1 identity gate.
        """
        generation = self._generation
        async with self._lock:
            self._check_generation(generation)
            if self.stage == TouchpadStage.RUNNING:
                assert self.status is not None
                return self.status
            if self._cleanup is not None:
                await self._cleanup
                self._check_generation(generation)
                self._cleanup = None
            if self._quarantined:
                raise RuntimeError("Touchpad command result unknown; reconnect before retrying")
            if mtu < 67:
                raise TouchpadProtocolError(f"Raw2 requires negotiated MTU >= 67, got {mtu}")
            self.stage, self.error = TouchpadStage.STARTING, None
            self.last_failure_diagnostics = None
            self._first = asyncio.get_running_loop().create_future()
            try:
                self.version = parse_info(await self._request(INFO, (0x2A, 2), generation), ringo=ringo)
                await self._initial_stop(generation, ringo=ringo)
                self.status = parse_status(await self._request(START, (0x3C, 0x11), generation))
                await asyncio.wait_for(asyncio.shield(self._first), self.timeout)
                self._check_generation(generation)
                if self.stage != TouchpadStage.RUNNING:
                    raise self.error or TouchpadProtocolError("Raw2 stream did not become ready")
                self._watchdog = asyncio.create_task(self._watch(generation), name="mythring-touchpad-watchdog")
                return self.status
            except BaseException as error:
                if generation == self._generation:
                    self._accepting = False
                    self.stage = TouchpadStage.FAILED
                    if isinstance(error, Exception):
                        self.error = error
                    await self._stop_after_failure(generation)
                raise
            finally:
                if self._first is not None:
                    if not self._first.done():
                        self._first.cancel()
                    elif not self._first.cancelled():
                        self._first.exception()
                    self._first = None

    async def stop(self) -> TouchpadStatus:
        """Stop the raw stream and require firmware acknowledgement."""
        generation = self._generation
        async with self._lock:
            self._check_generation(generation)
            self._accepting = False
            self._cancel_watchdog()
            if self._cleanup is not None:
                await self._cleanup
                self._check_generation(generation)
                self._cleanup = None
            try:
                status = parse_status(await self._request(STOP, (0x3C, 0x11), generation))
                if not status.stopped:
                    raise TouchpadProtocolError(f"STOP refused: state={status.state}, result={status.result}")
            except BaseException as error:
                if generation == self._generation:
                    self.error = error if isinstance(error, Exception) else RuntimeError("Touchpad STOP was cancelled")
                    self.stage = TouchpadStage.FAILED
                raise
            self.status, self.stage = status, TouchpadStage.STOPPED
            return status

    def feed(self, packet: bytes, arrival_ns: int | None = None) -> bool:
        """Handle a notification; return whether it belongs to this protocol."""
        if self._pending is not None:
            (family, operation), result, opens_stream = self._pending
            if _matches(packet, family, operation) and not result.done():
                try:
                    if opens_stream:
                        status = parse_status(packet)
                        if status.result != 0 or status.state != 1 or status.deadline != 0:
                            raise TouchpadProtocolError(
                                f"START refused: state={status.state}, result={status.result}, deadline={status.deadline}")
                        self._tracker.start(status)
                        self.status = status
                        self._accepting = True
                    result.set_result(bytes(packet))
                except Exception as error:
                    result.set_exception(error)
                return True
        if _matches(packet, 0x3C, 0x11) and self._accepting:
            self._fail(TouchpadProtocolError("Unexpected stream status; STOP/START required"))
            return True
        if not (_matches(packet, 0x3C, 2) or _matches(packet, 0x3C, 0x13)):
            return bool(packet and packet[0] == 0x3C)
        if not self._accepting:
            if self._pending is not None and self._pending[2] and not self._pending[1].done():
                error = TouchpadProtocolError("Feature arrived before START acknowledgement")
                self._quarantined = True
                self._pending[1].set_exception(error)
                self._fail(error)
            return True
        try:
            now = time.monotonic_ns()
            arrival = now if arrival_ns is None else arrival_ns
            if now - arrival > 200_000_000 or arrival > now:
                raise TouchpadProtocolError("Raw2 input is older than 200 ms or has an invalid arrival clock")
            tokens = parse_tokens(packet)
            self._tracker.accept_all(tokens)
            self._last_input_ns = now
            self.stage = TouchpadStage.RUNNING
            if self._first is not None and not self._first.done():
                self._first.set_result(None)
        except Exception as error:
            self._fail(error)
            return True
        if self.on_packet is not None:
            try:
                self.on_packet(tokens, arrival)
            except Exception as error:
                self._fail(error)
                return True
        if self.on_tokens is not None:
            try:
                self.on_tokens(tokens)
            except Exception:
                _LOG.exception("Touchpad token callback failed")
        return True

    def _fail(self, error: Exception) -> None:
        if self.stage == TouchpadStage.FAILED:
            return
        starting = self._first is not None
        self.error, self.stage, self._accepting = error, TouchpadStage.FAILED, False
        if self._first is not None and not self._first.done():
            self._first.set_exception(error)
        if not starting:
            self._cleanup = asyncio.create_task(self._stop_after_failure(self._generation), name="mythring-touchpad-stop")
        if self.on_error is not None:
            try:
                self.on_error(error)
            except Exception:
                _LOG.exception("Touchpad error callback failed")

    async def _stop_after_failure(self, generation: int) -> None:
        if generation != self._generation:
            return
        original_error = self.error
        try:
            if self._quarantined:
                # A late ACK cannot safely be attributed. Send STOP once, claim no acknowledgement.
                async def send_stop() -> None:
                    self._check_generation(generation)
                    await self._send(STOP)
                await asyncio.wait_for(send_stop(), self.timeout)
                return
            else:
                stopped = parse_status(await self._request(STOP, (0x3C, 0x11), generation))
                if not stopped.stopped:
                    raise TouchpadProtocolError("Firmware did not acknowledge cleanup STOP")
        except Exception:
            _LOG.warning("Touchpad cleanup STOP is unconfirmed", exc_info=True)
            return
        if generation != self._generation:
            return
        diagnostics, diagnostics_error = None, None
        try:
            diagnostics = parse_diagnostics(await self._request(DIAGNOSTICS, (0x3C, 0x12), generation))
        except Exception as error:
            diagnostics_error = f"{type(error).__name__}: {error}"
        if generation != self._generation:
            return
        snapshot = TouchpadFailureDiagnostics(
            type(original_error).__name__ if original_error is not None else None,
            str(original_error) if original_error is not None else None,
            stopped, diagnostics, diagnostics_error,
        )
        self.last_failure_diagnostics = snapshot
        if self.on_diagnostics is not None:
            try:
                self.on_diagnostics(snapshot)
            except Exception:
                _LOG.exception("Touchpad diagnostics callback failed")

    async def _watch(self, generation: int) -> None:
        try:
            while self.stage == TouchpadStage.RUNNING and generation == self._generation:
                await asyncio.sleep(0.1)
                if (generation == self._generation and self.stage == TouchpadStage.RUNNING
                        and time.monotonic_ns() - self._last_input_ns > 1_000_000_000):
                    # A stalled loop may resume this timer before queued BLE callbacks.
                    await asyncio.sleep(0)
                    if (generation == self._generation and self.stage == TouchpadStage.RUNNING
                            and time.monotonic_ns() - self._last_input_ns > 1_000_000_000):
                        self._fail(TouchpadProtocolError("Raw2 feature stream timed out after 1 second"))
        except asyncio.CancelledError:
            pass

    def _cancel_watchdog(self) -> None:
        if self._watchdog is not None:
            self._watchdog.cancel()
            self._watchdog = None

    def disconnected(self) -> None:
        """Invalidate this connection; call before reusing the client on a new connection."""
        self._generation += 1
        self._accepting, self._quarantined = False, False
        self._active = False
        self.last_failure_diagnostics = None
        self.stage = TouchpadStage.STOPPED
        self._cancel_watchdog()
        if self._cleanup is not None:
            self._cleanup.cancel()
            self._cleanup = None
        error = ConnectionError("Disconnected during touchpad operation")
        if self._pending is not None and not self._pending[1].done():
            self._pending[1].set_exception(error)
        if self._first is not None and not self._first.done():
            self._first.set_exception(error)


def require_touchpad_inference():
    """Load and verify the bundled CPU model; return a ready Raw2Model."""
    from mythring.touchpad_inference import Raw2Model
    return Raw2Model()
