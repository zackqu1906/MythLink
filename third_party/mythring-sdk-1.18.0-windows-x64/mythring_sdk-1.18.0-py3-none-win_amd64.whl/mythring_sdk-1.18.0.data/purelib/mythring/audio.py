"""Ringo public-firmware ADPCM audio, decoded to 16 kHz mono PCM16LE.

Wire contract follows the supplied Android public SDK 1.4.0 port in
ProximicVoice's ring_python_sdk/public_protocol.py. Firmware eligibility is
decided by Ring's compatibility rules; a microphone component alone is not
evidence that this protocol is available. No recording starts automatically.
"""
from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
import logging
import math
import struct
import time

from mythring.errors import NotConnectedError, ProtocolError, RequestTimeoutError, UnsupportedFeatureError

__all__ = ["AudioClient", "AudioFrame", "MicBlockAssembler", "decode_adpcm", "mic_start_command", "MIC_STOP"]

_LOG = logging.getLogger(__name__)
MIC_STOP = b"\x20\x01"


@dataclass(frozen=True)
class AudioFrame:
    sequence: int
    uptime_ms: int
    pcm: bytes
    sample_rate: int = 16000

    @property
    def sample_count(self) -> int:
        return len(self.pcm) // 2

    @property
    def samples(self) -> tuple[int, ...]:
        return struct.unpack(f"<{self.sample_count}h", self.pcm)


def mic_start_command(hardware_gain_db: float | None = None,
                      software_gain_db: float | None = None) -> bytes:
    def gain(value: float | None, minimum: int, maximum: int) -> int:
        if value is None:
            return 0x80
        if not math.isfinite(value) or not minimum <= value <= maximum or value * 2 != int(value * 2):
            raise ValueError(f"Gain must be {minimum}..{maximum} dB in 0.5 dB steps")
        return int(value * 2) & 255
    return bytes((0x20, 0, 1, gain(hardware_gain_db, -20, 20), gain(software_gain_db, -24, 24)))


_STEPS = (
    7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66,
    73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408,
    449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878,
    2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132,
    7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385,
    24623, 27086, 29794, 32767)
_INDICES = (-1, -1, -1, -1, 2, 4, 6, 8)


def decode_adpcm(block: bytes) -> bytes | None:
    """Decode one independent IMA block, including its initial predictor sample."""
    if len(block) < 6:
        return None
    predictor, index, reserved, count = struct.unpack_from("<hBBH", block)
    if index > 88 or reserved or not 1 <= count <= 1600 or len(block) != 6 + count // 2:
        return None
    samples = [predictor]
    for i in range(1, count):
        packed = block[6 + (i - 1) // 2]
        code = packed & 15 if i % 2 else packed >> 4
        step = _STEPS[index]
        delta = step >> 3
        if code & 4:
            delta += step
        if code & 2:
            delta += step >> 1
        if code & 1:
            delta += step >> 2
        predictor = max(-32768, min(32767, predictor + (-delta if code & 8 else delta)))
        index = max(0, min(88, index + _INDICES[code & 7]))
        samples.append(predictor)
    return struct.pack(f"<{count}h", *samples)


class MicBlockAssembler:
    """Keep at most one 806-byte block; never combine damaged or missing blocks.

    Frames retain firmware sequence numbers so callers can observe gaps. A
    partial block is discarded on a newer sequence, conflict or 500 ms timeout.
    """

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.sequence: int | None = None
        self.uptime = 0
        self.started_at = 0.0
        self.parts: list[bytes | None] = []
        self.byte_count = 0
        self.retired = False

    def _retire(self) -> None:
        self.retired = True
        self.parts = []
        self.byte_count = 0

    def accept(self, packet: bytes, now_ms: float | None = None) -> AudioFrame | None:
        if len(packet) <= 12 or packet[:2] != b"\x20\x03":
            return None
        seq, fragment, count, uptime = struct.unpack_from("<HHHI", packet, 2)
        if not 1 <= count <= 806 or fragment >= count or len(packet) - 12 > 806:
            return None
        now = time.monotonic() * 1000 if now_ms is None else now_ms
        if seq != self.sequence:
            if self.sequence is not None and not 1 <= ((seq - self.sequence) & 65535) <= 32767:
                return None
            self.sequence, self.uptime, self.started_at = seq, uptime, now
            self.parts, self.byte_count, self.retired = [None] * count, 0, False
        if self.retired:
            return None
        if self.uptime != uptime or len(self.parts) != count or now - self.started_at > 500:
            self._retire()
            return None
        payload = bytes(packet[12:])
        if self.parts[fragment] is not None:
            if self.parts[fragment] != payload:
                self._retire()
            return None
        self.byte_count += len(payload)
        if self.byte_count > 806:
            self._retire()
            return None
        self.parts[fragment] = payload
        if any(part is None for part in self.parts):
            return None
        block = b"".join(self.parts)
        self._retire()
        pcm = decode_adpcm(block)
        return AudioFrame(seq, uptime, pcm) if pcm is not None else None


class AudioClient:
    """Explicit streaming on one event loop; callbacks must return quickly.

    start() returns after a complete valid audio frame, not just an ATT write.
    stop() submits MIC STOP; the public protocol has no stop acknowledgement.
    The SDK retains no audio history; callers may stream frame.pcm into a WAV.
    """

    def __init__(self, send: Callable[[bytes], Awaitable[None]], *,
                 on_frame: Callable[[AudioFrame], None] | None = None,
                 prepare: Callable[[], Awaitable[None]] | None = None,
                 timeout: float = 5.0) -> None:
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("timeout must be positive and finite")
        self._send, self._on_frame, self._prepare = send, on_frame, prepare
        self._timeout = timeout
        self._generation = 0
        self._connected = False
        self._supported = False
        self._profile = "unknown"
        self._active = False
        self._accepting = False
        self._stop_serial = 0
        self._first: asyncio.Future[AudioFrame] | None = None
        self._assembler = MicBlockAssembler()

    @property
    def active(self) -> bool:
        """Microphone may own the sensors, including an unconfirmed failed STOP."""
        return self._active

    def connected(self, *, supported: bool, profile: str = "unknown") -> None:
        self.disconnected()
        self._connected, self._supported, self._profile = True, supported, profile

    def disconnected(self) -> None:
        self._generation += 1
        self._connected = self._supported = self._active = self._accepting = False
        self._assembler.reset()
        if self._first is not None and not self._first.done():
            self._first.set_exception(NotConnectedError("Audio connection ended"))

    def _admission(self) -> int:
        if not self._connected:
            raise NotConnectedError("Audio requires a connected Ring")
        if not self._supported:
            raise UnsupportedFeatureError("audio", self._profile)
        return self._generation

    def accept(self, packet: bytes) -> bool:
        if packet[:2] != b"\x20\x03":
            return False
        if self._accepting:
            frame = self._assembler.accept(packet)
            if frame is not None:
                if self._first is not None and not self._first.done():
                    self._first.set_result(frame)
                if self._on_frame is not None:
                    try:
                        self._on_frame(frame)
                    except Exception:
                        _LOG.exception("Audio frame callback failed")
        return True

    async def start(self, hardware_gain_db: float | None = None,
                    software_gain_db: float | None = None) -> AudioFrame:
        generation = self._admission()
        command = mic_start_command(hardware_gain_db, software_gain_db)
        if self._active or self._first is not None:
            raise ProtocolError("Audio is already starting or streaming")
        first = asyncio.get_running_loop().create_future()
        self._first = first
        sent = False
        stop_serial = self._stop_serial

        async def begin() -> AudioFrame:
            nonlocal sent
            if self._prepare is not None:
                await self._prepare()
            if generation != self._admission():
                raise NotConnectedError("Audio connection changed")
            if first.done():
                return await first
            self._assembler.reset()
            self._active = True
            self._accepting = True
            sent = True
            await self._send(command)
            frame = await first
            if generation != self._admission() or not self._active:
                raise NotConnectedError("Audio session ended during start")
            return frame

        try:
            return await asyncio.wait_for(begin(), self._timeout)
        except BaseException as error:
            cleanup = (sent and self._active and self._connected and generation == self._generation
                       and stop_serial == self._stop_serial)
            if generation == self._generation:
                self._accepting = False
                self._assembler.reset()
                if not sent:
                    self._active = False
            if cleanup:
                try:
                    await asyncio.wait_for(self._send(MIC_STOP), self._timeout)
                    if generation == self._generation:
                        self._active = False
                except Exception:
                    # Keep sensor ownership until STOP succeeds or this connection ends.
                    _LOG.warning("Audio start failed and MIC STOP could not be confirmed as sent", exc_info=True)
            if isinstance(error, TimeoutError):
                raise RequestTimeoutError("No complete audio frame received; microphone start was not confirmed") from error
            raise
        finally:
            if self._first is first:
                self._first = None
            if not first.done():
                first.cancel()
            elif not first.cancelled():
                first.exception()  # A disconnect during the write may precede awaiting this future.

    async def stop(self) -> None:
        generation = self._admission()
        self._stop_serial += 1
        self._accepting = False
        self._assembler.reset()
        if self._first is not None and not self._first.done():
            self._first.set_exception(ProtocolError("Audio start cancelled by stop"))
        await self._send(MIC_STOP)
        if generation != self._admission():
            raise NotConnectedError("Audio connection changed during stop")
        self._active = False
