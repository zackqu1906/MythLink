"""Public values carried by the R1 SDK's Nordic UART notifications."""

from dataclasses import dataclass, field
from enum import Enum
import re

__all__ = [
    "Battery", "DeviceInfo", "InfoComponent", "GestureEvent", "ImuToken", "LinkState",
    "RingProduct", "RingStatus", "is_supported_ble_name",
]


def is_supported_ble_name(name: str | None) -> bool:
    """Match known R1 advertisements; INFO still establishes identity."""
    if not name or not name.strip():
        return False
    if re.fullmatch(r"(?:R1|Ringo)[0-9A-F]{4}", name, re.IGNORECASE):
        return True
    suffix = "的Ringo"
    return name.endswith(suffix) and len(name) > len(suffix) and len(name.encode("utf-8")) <= 29


class RingProduct(str, Enum):
    R1 = "R1"

    @classmethod
    def from_ble_name(cls, name: str | None) -> "RingProduct":
        if not is_supported_ble_name(name):
            raise ValueError("Unsupported device name")
        return cls.R1

    is_supported_ble_name = staticmethod(is_supported_ble_name)


class LinkState(str, Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"


@dataclass(frozen=True)
class InfoComponent:
    """One INFO component record, preserving its five unsigned wire bytes."""

    id: int
    present: int
    count: int
    model: int
    flags: int


@dataclass(frozen=True)
class DeviceInfo:
    """INFO values; ``hardware_revision`` remains the legacy wire hardware code.

    Product identity is separate from a physical board revision. Current INFO
    does not report the latter, so ``board_revision`` is unknown.
    """

    firmware_version: str
    hardware_revision: int = 2
    swipe_available: bool = False
    format_version: int = 1
    firmware_numeric_version: tuple[int, int, int, int] = (0, 0, 0, 0)
    components: tuple[InfoComponent, ...] = ()
    product_id: str | None = field(default=None, kw_only=True, compare=False)
    board_revision: str | None = field(default=None, kw_only=True, compare=False)
    firmware_text_version: str | None = field(default=None, kw_only=True, compare=False)
    firmware_version_source: str | None = field(default=None, kw_only=True, compare=False)

    @property
    def legacy_hardware_code(self) -> int:
        """The original INFO hardware byte, not a product's PCB revision."""
        return self.hardware_revision


@dataclass(frozen=True)
class RingStatus:
    battery: int | None = None
    software_version: str | None = None


@dataclass(frozen=True)
class Battery:
    percent: int


@dataclass(frozen=True)
class ImuToken:
    """Six decoded float16 encoder features, **not** physical IMU readings.

    ``packet_uptime_ms`` belongs to the packet's final frame, not each frame.
    """

    values: tuple[float, ...]
    sequence: int
    frame_index: int = 0
    frame_count: int = 1
    packet_uptime_ms: int = 0


@dataclass(frozen=True)
class GestureEvent:
    """A recognized gesture; legacy trigger time occupies ``center_uptime_ms``.

    Legacy int8 logits do not define a probability, so confidence is ``None``.
    Current final events reserve probabilities as zero and retain ``0.0``.
    """

    sequence: int
    class_id: int
    center_uptime_ms: int
    confidence: float | None = 0.0
