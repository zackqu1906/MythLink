"""Persistent health workflows shared by the public async client."""
from __future__ import annotations

import asyncio
import struct
import time
from dataclasses import replace
from datetime import date, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from .health_models import *
from .health_protocol import HealthCompactWindow, HealthError, HealthWindow, MAX_FILE, read_block, read_blocks
from .health_store import HealthStore


class HealthArchiveClientMixin:
    def _initialize_archive(self, address: str, storage_path: str | Path | None) -> None:
        self._address = address
        self._storage_path = Path(storage_path or Path.home() / ".local" / "share" / "mythring" / "health")
        self._account_scope = "local-default"
        self._scope_generation = 0
        self._operation_scope = None
        self._store_instance = None
        self.sync_progress = None
        self.last_sync_timings = []
        self._report_callbacks = []
        self._automatic_work = None
        self._created_utc_ms = time.time_ns() // 1000000
        self._analysis_activation_utc_ms = None

    @property
    def store(self) -> HealthStore:
        if self._store_instance is None:
            self._store_instance = HealthStore(self._storage_path, self._address, self._account_scope)
        return self._store_instance

    async def set_account_scope(self, account: str) -> None:
        if not account.strip() or len(account) > 1024:
            raise ValueError("Invalid health account scope")
        if account == self._account_scope:
            return
        self._scope_generation += 1
        async with self._operation(require_connection=False):
            self._account_scope = account
            self._store_instance = None
            self.sync_progress = None

    async def local_recordings(self) -> list[HealthRecording]:
        async with self._operation(require_connection=False):
            return self.store.recordings()

    def is_analysis_eligible(self, record: HealthRecording) -> bool:
        if record.mode == 7:
            return True
        if self._analysis_activation_utc_ms is None:
            self._analysis_activation_utc_ms = self.store.analysis_activation(self._created_utc_ms)
        return record.start_utc_ms >= self._analysis_activation_utc_ms

    async def local_reports(self) -> list[HealthReport]:
        async with self._operation(require_connection=False):
            return self.store.reports()

    @staticmethod
    def read_local_reports(storage_path: str | Path, address: str, account: str) -> list[HealthReport]:
        return HealthStore(storage_path, address, account, read_only=True).reports()

    async def get_report(self, recording_id: int) -> HealthReport | None:
        async with self._operation(require_connection=False):
            return self.store.report(recording_id)

    async def get_reports(self) -> list[HealthReport]:
        return await self.local_reports()

    async def is_recording_verified(self, recording: HealthRecording) -> bool:
        async with self._operation(require_connection=False):
            return self.store.is_verified(recording)

    async def verified_recordings(self, recordings: list[HealthRecording]) -> dict[int, bool]:
        async with self._operation(require_connection=False):
            return {row.id: self.store.is_verified(row) for row in recordings}

    async def reusable_reports(self, records: list[HealthRecording], reports: list[HealthReport]) -> set[int]:
        async with self._operation(require_connection=False):
            existing = {report.recording.id: report for report in reports}
            return {record.id for record in records if self._report_reusable(record, existing.get(record.id))}

    def _report_reusable(self, record, report) -> bool:
        if report is None or report.recording != record:
            return False
        from .health_analysis import ANALYSIS_VERSIONS
        if report.algorithm_version.removesuffix("-scenes1") not in ANALYSIS_VERSIONS:
            return False
        if "TIME_UNKNOWN" not in report.warnings:
            return True
        from .health_analysis import HealthFeatureSegment
        segment = HealthFeatureSegment(self.store.raw(record.id).read_bytes(), record.duration_ms if record.status in (2, 3) else None)
        return self.store.clock(segment.boot) is None

    async def loss_ranges(self) -> list[HealthLossRange]:
        async with self._operation():
            return await self._loss_ranges()

    async def _loss_ranges(self):
        if not (await self.get_capabilities()).automatic:
            return []
        ranges, after = [], 0
        for _ in range(33):
            try:
                payload = await self._request(10, struct.pack("<I", after))
            except HealthError as error:
                if error.device_code == -2:
                    return ranges
                raise
            if len(payload) != 9:
                raise ValueError("Invalid health loss range")
            first, last, compacted = struct.unpack("<IIB", payload)
            if not 0 < first <= last or last <= after or compacted not in (1, 2):
                raise ValueError("Invalid health loss range")
            ranges.append(HealthLossRange(first, last, compacted == 2))
            after = last
        return ranges

    async def _delete_on_ack(self, caps=None):
        caps = caps or await self.get_capabilities()
        if not caps.ack_policy_supported:
            return None
        payload = await self._request(18)
        if payload not in (b"\x00", b"\x01"):
            raise ValueError("Invalid ACK policy")
        return payload == b"\x01"

    async def get_delete_on_ack(self) -> bool | None:
        async with self._operation():
            return await self._delete_on_ack()

    async def set_delete_on_ack(self, enabled: bool) -> bool:
        async with self._operation():
            if not (await self.get_capabilities()).ack_policy_supported:
                raise HealthError(-95, "Configurable ACK policy unavailable")
            payload = await self._request(18, bytes((int(enabled),)))
            if payload not in (b"\x00", b"\x01"):
                raise ValueError("Invalid ACK policy")
            return payload == b"\x01"

    async def acknowledge(self, record: HealthRecording, retained_on_device: bool = False,
                          allow_device_deletion: bool = False) -> None:
        async with self._operation():
            await self._acknowledge(record, retained_on_device, allow_device_deletion)

    async def _acknowledge(self, record, retained_on_device=False, allow_device_deletion=False):
        caps = await self.get_capabilities()
        if record.mode != 7 or record.status not in (1, 2, 3) or not caps.retained_history:
            raise ValueError("Unknown or legacy ACK retention behavior")
        if not allow_device_deletion and await self._delete_on_ack(caps):
            raise ValueError("ACK would delete device history; allow_device_deletion is required")
        if not retained_on_device and self.store.is_acknowledged(record):
            return
        if self.store.require_verified(record.id) != record:
            raise ValueError("Local recording changed before ACK")
        if await self._request(8, struct.pack("<II", record.id, record.bytes)):
            raise ValueError("Unexpected ACK reply")
        self.store.mark_acknowledged(record)

    async def delete_recording(self, recording_id: int) -> None:
        """Delete a device recording only after independently verifying its durable local copy."""
        async with self._operation():
            record = self.store.require_verified(recording_id)
            await self._request(6, struct.pack("<II", record.id, record.bytes))

    async def _read_transfer_window(self, record_id, offset, total, status, caps, current=False):
        cap = min(470, self._mtu() - 28)
        compact_cap = min(479, self._mtu() - 19)
        credits = 32 if caps.flags & (1 << 12) else 8
        compact = bool(caps.flags & (1 << 25)) and compact_cap > 0
        sizes = list(dict.fromkeys((credits, min(credits, 8), 1)))
        for attempt, size in enumerate(sizes):
            try:
                if compact:
                    return await self._request(19, struct.pack("<IIIHBB", record_id, offset, total, compact_cap, size, status),
                        window=HealthCompactWindow(record_id, offset, total, status, compact_cap, size))
                payload = struct.pack("<IIIHB", record_id, offset, total, cap, size) + (b"\x01" if current else b"")
                return await self._request(11, payload, window=HealthWindow(record_id, offset, total, cap, size, allow_open=current))
            except HealthError as error:
                if error.device_code != -110 or error.operation not in (11, 19) or attempt == len(sizes) - 1:
                    raise

    async def sync(self, recording_id: int, known_record: HealthRecording | None = None,
                   on_progress=None) -> HealthRecording:
        self._sync_callers += 1
        try:
            async with self._operation():
                return await self._sync_internal(recording_id, known_record, on_progress=on_progress)
        finally:
            self._sync_callers -= 1

    async def _sync_internal(self, recording_id, record=None, current=False, defer_ack=False, on_progress=None, deadline=None):
        if record is None:
            record = next((row for row in await self._list_recordings() if row.id == recording_id), None)
            if record is None:
                raise HealthError(-2, "Recording not found")
        if record.id != recording_id or not (record.status in (1, 2, 3) or current and record.status == 0 and record.mode == 7):
            raise ValueError("Invalid health recording snapshot")
        caps = await self.get_capabilities()
        maximum = min(caps.max_read_bytes, self._mtu() - 26)
        if maximum <= 0:
            raise ValueError("BLE MTU too small for health transfer")
        args = lambda offset, total: struct.pack("<IIIH", recording_id, offset, total, maximum)
        initial = await self._request(5, args(0, 0))
        if len(initial) < 13:
            raise ValueError("Truncated health snapshot")
        identity, zero, total, status = struct.unpack_from("<IIIB", initial)
        if identity != recording_id or zero != 0 or status not in (0, 1, 2, 3) or total > (512 * 1024 if current else MAX_FILE):
            raise ValueError("Health snapshot changed")
        if record.mode == 7 and record.status in (1, 2, 3) and (total != record.bytes or status != record.status):
            raise ValueError("Immutable health snapshot changed")
        if not current and status == 0:
            raise ValueError("Sealed recording became active")
        snapshot = replace(record, bytes=total, status=0 if current else status)
        self.store.save(snapshot)
        offset = self.store.recover(recording_id)
        if offset > total:
            self.store.truncate(recording_id, total)
            offset = self.store.recover(recording_id)
        use_window = bool(caps.flags & (1 << 11)) and self._mtu() > 28 and (status in (1, 2, 3) or current and bool(caps.flags & (1 << 24)))
        while offset < total:
            if deadline is not None and time.monotonic() >= deadline:
                self.store.recover(recording_id)
                raise TimeoutError("Legacy health transfer deferred to the next synchronization")
            reply = await self._read_transfer_window(recording_id, offset, total, status, caps, current and status == 0) if use_window else initial if offset == 0 else await self._request(5, args(offset, total))
            if len(reply) <= 13 or struct.unpack_from("<IIIB", reply) != (recording_id, offset, total, status) or offset + len(reply) - 13 > total:
                raise ValueError("Health transfer snapshot changed")
            self.store.append(recording_id, offset, reply[13:])
            offset += len(reply) - 13
            self.sync_progress = HealthSyncProgress(recording_id, offset, total)
            if on_progress:
                on_progress(self.sync_progress)
        if current and total:
            reply = await self._request(5, args(total, total))
            if len(reply) != 13 or struct.unpack_from("<III", reply) != (recording_id, total, total):
                raise ValueError("Invalid current snapshot completion")
        committed = self.store.recover(recording_id)
        if not current and committed != total:
            raise ValueError("Health transfer ended in a damaged or partial record")
        result = replace(snapshot, bytes=committed)
        self.store.save(result)
        if not current:
            self.store.require_verified(recording_id)
            if not defer_ack and result.mode == 7 and caps.retained_history and not await self._delete_on_ack(caps):
                await self._acknowledge(result)
        self.sync_progress = HealthSyncProgress(recording_id, committed, total, not current)
        if on_progress:
            on_progress(self.sync_progress)
        return result

    async def current_step_record(self, status: HealthState) -> HealthRecording | None:
        async with self._operation():
            return await self._current_step_record(status)

    async def _current_step_record(self, status):
        if not (await self.get_capabilities()).automatic or not status.recording or not status.recording_id or not status.boot_id:
            return None
        data = bytearray()
        while len(data) < 72:
            size = min(72 - len(data), self._mtu() - 26)
            if size <= 0:
                raise ValueError("MTU too small")
            try:
                payload = await self._request(5, struct.pack("<IIIH", status.recording_id, len(data), 72, size))
            except HealthError as error:
                if error.device_code in (-2, -22):
                    return None
                raise
            if len(payload) <= 13 or struct.unpack_from("<III", payload) != (status.recording_id, len(data), 72) or len(payload) - 13 > 72 - len(data):
                raise ValueError("Current recording header changed")
            if payload[12] != 0:
                return None
            data.extend(payload[13:])
        import io
        header = read_block(io.BytesIO(data))
        if header.kind != 1 or header.schema != 4 or header.sequence != 0 or struct.unpack_from("<Q", header.payload, 24)[0] != status.boot_id:
            raise ValueError("Current recording boot changed")
        return HealthRecording(status.recording_id, 0, 72, struct.unpack_from("<Q", header.payload, 4)[0], 0, 7)

    async def sync_current_steps(self, record: HealthRecording) -> HealthReport | None:
        self._sync_callers += 1
        try:
            async with self._operation():
                return await self._sync_current_steps(record)
        finally:
            self._sync_callers -= 1

    async def _sync_current_steps(self, record):
        before = await self.refresh_status()
        if not before.recording or before.recording_id != record.id:
            return None
        local = await self._sync_internal(record.id, record, current=True)
        after = await self.refresh_status()
        if before.boot_id != after.boot_id or before.boot_id == 0:
            raise ValueError("Device boot changed")
        if local.bytes < 72:
            return None
        from .health_analysis import analyze_current_steps
        report = analyze_current_steps(self.store.raw(local.id).read_bytes(), local, before.boot_id, self.store.clock(before.boot_id))
        return self.store.save_report(report)

    async def analyze(self, recording_id: int) -> HealthReport:
        async with self._operation(require_connection=False):
            return await self._analyze_internal(recording_id)

    async def _analyze_internal(self, recording_id: int, manual_hrv: bool = False) -> HealthReport:
        previous = self.store.report(recording_id)
        if previous is not None and not self.is_analysis_eligible(previous.recording):
            return previous
        record = self.store.require_verified(recording_id)
        if not self.is_analysis_eligible(record):
            raise ValueError("Legacy record is retained without reanalysis")
        from .health_analysis import analyze_recording
        scope, epoch = self._scope_generation, self._epoch
        report = await asyncio.to_thread(analyze_recording, self.store, record, manual_hrv)
        if scope != self._scope_generation or epoch != self._epoch:
            raise HealthError(-125, "Health scope or device session changed during analysis")
        report = self.store.save_report(report)
        for callback in tuple(self._report_callbacks):
            callback(report)
        return report

    def on_report(self, callback):
        self._report_callbacks.append(callback)
        return lambda: self._report_callbacks.remove(callback) if callback in self._report_callbacks else None

    async def measure_report(self, metric: HealthMetric, on_state=None) -> HealthReport:
        metric = HealthMetric(metric)
        if metric == HealthMetric.HEART_RATE and (self._sync_callers or self._operations.locked()):
            raise HealthError(-16, "Health synchronization or another operation is in progress")
        async with self._operation():
            automatic = (await self.get_capabilities()).automatic
            if not automatic and (await self.refresh_status()).recording:
                raise HealthError(-16, "Stop the scheduled session before measuring")
            self.connection_checked = False
            await self._set_clock()
            payload = await self._request(7, bytes((int(metric),)))
            if len(payload) != 4:
                raise ValueError("Invalid manual recording ID")
            record_id = struct.unpack("<I", payload)[0]
            async def wait_complete():
                while True:
                    status = await self.refresh_status()
                    if on_state:
                        on_state(status)
                    if status.device_error:
                        raise HealthError(status.device_error, "Measurement capture failed")
                    if (status.recording_id != record_id and status.manual_done) if automatic else not status.recording:
                        return
                    await asyncio.sleep(1)
            await asyncio.wait_for(wait_complete(), 180)
            if automatic:
                candidates = [row.id for row in await self._list_recordings() if row.mode == 7 and row.status in (1, 2, 3) and row.id >= record_id]
                if not candidates:
                    raise HealthError(-2, "Manual segment missing")
                record_id = max(candidates)
            await self._sync_internal(record_id)
            report = await self._analyze_internal(record_id, metric == HealthMetric.HRV)
            return replace(report, values=[value for value in report.values if value.metric == metric and value.measurement_id is not None], rri=[], sleep=[], bedtimes=[]) if automatic else report

    async def measure(self, metric: HealthMetric) -> HealthValue:
        report = await self.measure_report(metric)
        values = [value for value in report.values if value.metric == metric]
        return values[-1] if values else HealthValue(time.time_ns() // 1000000, metric, None,
            {HealthMetric.HEART_RATE: "bpm", HealthMetric.SPO2: "%", HealthMetric.HRV: "ms"}[metric],
            HealthQuality.INSUFFICIENT_DATA, HealthSource.ANDROID if metric == HealthMetric.HRV else HealthSource.FIRMWARE)

    async def get_daily_summary(self, day: date | str, time_zone: str = "UTC") -> HealthDailySummary:
        async with self._operation(require_connection=False):
            day = date.fromisoformat(day) if isinstance(day, str) else day
            zone = ZoneInfo(time_zone)
            start = int(datetime.combine(day, datetime.min.time(), zone).timestamp() * 1000)
            until = int(datetime.combine(day + timedelta(days=1), datetime.min.time(), zone).timestamp() * 1000)
            reports = self.store.reports()
            activity = {row.window_key or f"legacy:{row.start_utc_ms}": row for report in reports for row in report.activity if start <= row.start_utc_ms < until and row.quality == HealthQuality.VALID}
            values = {(row.metric, row.time_utc_ms): row for report in reports for row in report.values if start <= row.time_utc_ms < until}
            sleep = []
            from .health_summary import bridge_restarts
            epochs = {row.start_utc_ms: row for report in reports for row in report.sleep}.values()
            for row in bridge_restarts(epochs, reports):
                a, b = max(start, row.start_utc_ms), min(until, row.start_utc_ms + row.duration_ms)
                if b > a:
                    sleep.append(replace(row, start_utc_ms=a, duration_ms=b-a))
            return HealthDailySummary(day.isoformat(), time_zone, sum(row.steps for row in activity.values()),
                sum(row.duration_ms for row in activity.values() if row.steps > 0) // 1000,
                sorted(values.values(), key=lambda row: row.time_utc_ms), sleep,
                bool(activity) or any(report.activity_available and report.recording.start_utc_ms < until and report.recording.start_utc_ms + report.recording.duration_ms > start for report in reports))

    async def _directory_snapshot(self, boot, caps):
        if boot == 0 or not caps.flags & (1 << 13) or not caps.flags & (1 << 14) or self._mtu() < 45:
            return await self._list_recordings()
        async def generation():
            payload = await self._request(12)
            if len(payload) != 4:
                raise ValueError("Invalid directory generation")
            return struct.unpack("<I", payload)[0]
        for _ in range(3):
            revision = await generation()
            cached = self.store.read_json("directory-v1")
            if cached is not None and cached["boot"] == boot and cached["generation"] == revision:
                return [self.store.decode_recording(row) for row in cached["records"]]
            records, identities, after = [], set(), 0
            try:
                for page in range(65536):
                    payload = await self._request(13, struct.pack("<IIBH", after, revision, 18, min(self._mtu()-3, 495)))
                    if len(payload) < 6:
                        raise ValueError("Truncated directory page")
                    observed, eof, count = struct.unpack_from("<IBB", payload)
                    if observed != revision or eof not in (0, 1) or count > 18 or len(payload) != 6+26*count or count == 0 and not eof:
                        raise ValueError("Invalid directory page")
                    for i in range(count):
                        row = payload[6+i*26:32+i*26]
                        record = HealthRecording.decode(row)
                        sequence = struct.unpack_from("<I", row, 22)[0]
                        if sequence <= after or record.id == 0 or record.id in identities:
                            raise ValueError("Directory sequence did not advance")
                        after = sequence
                        identities.add(record.id)
                        if record.mode in (6, 7):
                            records.append(record)
                    if eof:
                        if page == 0 or await generation() == revision:
                            from dataclasses import asdict
                            self.store.atomic("directory-v1", {"boot": boot, "generation": revision, "records": [asdict(row) for row in records]})
                            return records
                        break
                else:
                    raise ValueError("Directory did not terminate")
            except HealthError as error:
                if error.device_code not in (-116, -133):
                    raise
        raise HealthError(-116, "Directory changed during synchronization; retry the next round")

    async def _batch_acknowledge(self, directory, records):
        from dataclasses import asdict
        reclaim = bool(await self._delete_on_ack())
        remote = {record.id: record for record in directory}
        receipts = self.store.receipts()
        fresh = []
        for record in records:
            receipt = receipts.get(str(record.id), {})
            done = receipt.get("record") == asdict(record) and receipt.get("reclaimed", False) if reclaim else self.store.is_acknowledged(record)
            if remote.get(record.id) == record and not done:
                fresh.append(record)
        pending = [record for record in self.store.pending_batch() if reclaim or remote.get(record.id) == record]
        outstanding = list({record.id: record for record in pending+fresh}.values())
        self.store.save_pending_batch(outstanding)
        batch_size = max(1, min(30, (self._mtu()-13)//16))
        while outstanding:
            batch = outstanding[:batch_size]
            for record in batch:
                if self.store.require_verified(record.id) != record:
                    raise ValueError("Complete local copy required before batch confirmation")
                report = self.store.report(record.id)
                if report is None or report.recording != record:
                    raise ValueError("Saved analysis required before batch confirmation")
            payload = bytes((int(reclaim), len(batch)))+b"".join(struct.pack("<IIq", row.id, row.bytes, row.start_utc_ms) for row in batch)
            if await self._request(20, payload):
                raise ValueError("Unexpected batch confirmation reply")
            self.store.save_sync_progress(directory, batch, reclaim)
            outstanding = outstanding[len(batch):]
            self.store.save_pending_batch(outstanding)

    async def sync_automatic(self, account_scope: str, time_zone: str = "UTC", options=None, on_update=None):
        """Share a concurrent sync round, then project a caller-specific page summary."""
        if not account_scope.strip() or len(account_scope) > 1024:
            raise ValueError("Invalid health account scope")
        ZoneInfo(time_zone)
        key = (account_scope, time_zone)
        self._sync_callers += 1
        try:
            while True:
                active = self._automatic_work
                if active is None or active["task"].done():
                    if account_scope != self._account_scope:
                        await self.set_account_scope(account_scope)
                    work = {"key": key, "listeners": [], "latest": None, "callers": 0}
                    def publish(update):
                        work["latest"] = update
                        for listener in tuple(work["listeners"]):
                            try:
                                listener(update)
                            except Exception:
                                pass
                    work["task"] = asyncio.create_task(self._sync_automatic_round(account_scope, time_zone, publish))
                    self._automatic_work = active = work
                if active["key"] == key:
                    break
                await asyncio.shield(active["task"])
            active["callers"] += 1
            if on_update:
                active["listeners"].append(on_update)
                if active["latest"] is not None:
                    try:
                        on_update(active["latest"])
                    except Exception:
                        pass
            try:
                result = await asyncio.shield(active["task"])
                return result.with_page_summary(options) if hasattr(result, "with_page_summary") else result
            finally:
                active["callers"] -= 1
                if on_update in active["listeners"]:
                    active["listeners"].remove(on_update)
                if active["callers"] == 0 and not active["task"].done():
                    active["task"].cancel()
                    try:
                        await active["task"]
                    except asyncio.CancelledError:
                        pass
        finally:
            self._sync_callers -= 1

    async def _sync_automatic_round(self, account, zone, update):
        from .health_summary import (AutomaticSyncUpdate, PublicHealthReport, SyncSummary, SyncError, build_automatic_result)
        async with self._operation(require_connection=False):
            started = time.monotonic()
            reports = self.store.reports()
            errors, deferred, losses = [], [], []
            confirmed, caps, current_updated = None, self._capabilities, False
            downloaded, received, total, record_id, stage = 0, 0, 0, None, "STATUS"
            def result(status):
                return build_automatic_result(account_scope=account, device_address=self._address, time_zone=zone,
                    status=status, device_state=confirmed, sync=SyncSummary(received, total, downloaded, current_updated, list(deferred)),
                    reports=reports, loss_ranges=losses, errors=errors, live_heart_supported=bool(caps and caps.live_heart_supported),
                    capabilities=caps, synced_at_utc_ms=self.store.read_json("automatic-sync.utc"))
            update(AutomaticSyncUpdate("CACHE", cached_reports=[PublicHealthReport.from_report(report) for report in reports]))
            if not self._connection_live:
                return result("CACHE_ONLY")
            try:
                update(AutomaticSyncUpdate(stage))
                caps = await self.get_capabilities()
                if not caps.automatic:
                    raise HealthError(-95, "Automatic health firmware required")
                before = await self.refresh_status()
                utc, uptime = await self._set_clock()
                confirmed = await self.refresh_status()
                if not confirmed.time_known or confirmed.boot_id != before.boot_id or not confirmed.boot_id or not 0 <= uptime <= 0xFFFFFFFF:
                    raise ValueError("Clock acknowledgement missing or device boot changed")
                boot = confirmed.boot_id
                self.store.save_clock(boot, utc-uptime)
                stage = "CURRENT_STEPS"
                current = await self._current_step_record(confirmed)
                if current is not None:
                    current_updated = await self._sync_current_steps(current) is not None
                stage = "DIRECTORY"
                update(AutomaticSyncUpdate(stage, received_bytes=received, total_bytes=total))
                directory = await self._directory_snapshot(boot, caps)
                self.store.save_sync_progress(directory)
                remote = {row.id: row for row in directory}
                records = {row.id: row for row in self.store.recordings()}
                records.update(remote)
                automatic = sorted((row for row in records.values() if row.mode == 7 and row.status in (1, 2, 3)), key=lambda row: row.id)
                ready = []
                for record in automatic:
                    record_id = record.id
                    if self.store.is_verified(record):
                        ready.append(record)
                        continue
                    if record.id not in remote:
                        errors.append(SyncError("TRANSFER", record.id, "RECORD_EXPIRED", None, "Incomplete local recording is no longer in device history"))
                        continue
                    stage = "TRANSFER"
                    if self.store.has_recovered_source(record):
                        update(AutomaticSyncUpdate("ARCHIVE_RECOVERED", record.id, received, total, True))
                        continue
                    refusal = self.store.cached_refusal(record, boot, caps.flags, caps.feature_revision)
                    baseline = self.store.recover(record.id)
                    base_received, base_total = received, total
                    def progress(value):
                        nonlocal received, total
                        received, total = base_received+max(0, value.received-baseline), base_total+max(0, value.total-baseline)
                        update(AutomaticSyncUpdate("VERIFY" if value.verified else stage, value.recording_id, received, total, value.verified))
                    try:
                        if refusal is not None:
                            raise HealthError(refusal, "Previously refused unchanged record in this firmware boot", 5)
                        local = await self._sync_internal(record.id, record, defer_ack=bool(caps.flags & (1 << 27)), on_progress=progress)
                        ready.append(local)
                        downloaded += 1
                    except HealthError as error:
                        if error.operation not in (5, 11, 19) or error.device_code not in (-134, -95):
                            raise
                        if refusal is None:
                            self.store.save_refusal(record, boot, caps.flags, caps.feature_revision, error.device_code)
                        errors.append(SyncError(stage, record.id, "RECORD_UNSUPPORTED", error.device_code, str(error)))
                if not caps.flags & (1 << 27) and caps.retained_history and not await self._delete_on_ack(caps):
                    for record in ready:
                        if remote.get(record.id) == record:
                            await self._acknowledge(record)
                stage = "ANALYZE"
                for record in sorted(ready, key=lambda row: row.id, reverse=True):
                    record_id = record.id
                    if not self._report_reusable(record, self.store.report(record.id)) or downloaded:
                        update(AutomaticSyncUpdate(stage, record.id, received, total, True))
                        await self._analyze_internal(record.id)
                legacy = sorted((row for row in records.values() if row.mode == 6 and row.status in (1, 2, 3) and self.is_analysis_eligible(row)), key=lambda row: row.id)
                pending_legacy = []
                for record in legacy:
                    if self.store.is_verified(record):
                        if not self._report_reusable(record, self.store.report(record.id)):
                            await self._analyze_internal(record.id)
                    elif record.id in remote:
                        pending_legacy.append(record)
                if pending_legacy:
                    record = pending_legacy[0]
                    record_id, stage = record.id, "TRANSFER"
                    try:
                        await self._sync_internal(record.id, record, deadline=time.monotonic()+60)
                        downloaded += 1
                        stage = "ANALYZE"
                        await self._analyze_internal(record.id)
                    except TimeoutError:
                        deferred.append(record.id)
                    deferred.extend(row.id for row in pending_legacy[1:])
                reports = self.store.reports()
                snapshot = result("SYNCING")
                update(AutomaticSyncUpdate("DATA_READY", received_bytes=received, total_bytes=total, cached_reports=snapshot.reports, snapshot=snapshot))
                if caps.flags & (1 << 27):
                    stage, record_id = "BATCH_ACK", None
                    update(AutomaticSyncUpdate(stage, received_bytes=received, total_bytes=total))
                    await self._batch_acknowledge(directory, ready)
                stage = "LOSS_RANGES"
                losses = await self._loss_ranges()
                stage = "STATUS"
                confirmed = await self.refresh_status()
                if confirmed.boot_id != boot:
                    raise ValueError("Device boot changed during synchronization")
                if not deferred and not errors:
                    self.store.atomic("automatic-sync.utc", time.time_ns()//1000000)
                update(AutomaticSyncUpdate("COMPLETE", received_bytes=received, total_bytes=total))
                return result("PARTIAL" if deferred or errors else "SUCCESS")
            except asyncio.CancelledError:
                raise
            except Exception as error:
                if isinstance(error, HealthError) and error.device_code == -125:
                    raise
                reports = self.store.reports()
                if not self._connection_live:
                    confirmed = None
                errors.append(SyncError(stage, record_id, "DEVICE_ERROR" if isinstance(error, HealthError) else "SYNC_ERROR", error.device_code if isinstance(error, HealthError) else None, str(error)))
                return result("PARTIAL" if reports else "FAILED")
            finally:
                self.last_sync_timings = [HealthTiming("sync.total", 1, (time.monotonic()-started)*1000)]
