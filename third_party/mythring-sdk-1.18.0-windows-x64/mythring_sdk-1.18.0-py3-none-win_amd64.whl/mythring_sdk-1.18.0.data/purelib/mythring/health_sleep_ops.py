"""CPU implementations of the five operators in the delivered sleep graph.

The classifier runs the original AArch64 decision trees in an isolated CPU
instance. It never links Android libtorch into the host process.
"""
from __future__ import annotations

import ctypes
from functools import lru_cache
from importlib.resources import files
from io import BytesIO
import math
import struct
import threading
import numpy as np

_libraries = []
_register_lock = threading.Lock()


class _Classifier:
    def __init__(self):
        from elftools.elf.elffile import ELFFile
        from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
        from unicorn.arm64_const import UC_ARM64_REG_D0, UC_ARM64_REG_PC, UC_ARM64_REG_LR
        self.lock = threading.Lock()
        self.uc = u = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
        elf = ELFFile(BytesIO(files('mythring').joinpath('assets', 'sleep_native.so').read_bytes()))
        self.base = 0x1000000
        segments = [s for s in elf.iter_segments() if s['p_type'] == 'PT_LOAD']
        size = (max(s['p_vaddr'] + s['p_memsz'] for s in segments) + 4095) & ~4095
        u.mem_map(self.base, size)
        for segment in segments:
            u.mem_write(self.base + segment['p_vaddr'], segment.data())
        stub_base, stubs = 0x2000000, {}
        u.mem_map(stub_base, 0x10000)
        for section in elf.iter_sections():
            if section['sh_type'] != 'SHT_RELA':
                continue
            symbols = elf.get_section(section['sh_link'])
            for relocation in section.iter_relocations():
                kind = relocation['r_info_type']
                symbol = symbols.get_symbol(relocation['r_info_sym'])
                if kind == 1027:
                    value = self.base + relocation['r_addend']
                elif kind in (257, 1025, 1026):
                    if symbol['st_shndx'] == 'SHN_UNDEF':
                        if symbol.name not in stubs:
                            stubs[symbol.name] = stub_base + len(stubs) * 16
                        value = stubs[symbol.name] + relocation['r_addend']
                    else:
                        value = self.base + symbol['st_value'] + relocation['r_addend']
                else:
                    raise RuntimeError(f'Unsupported sleep classifier relocation: {kind}')
                u.mem_write(self.base + relocation['r_offset'], struct.pack('<Q', value))
        names = {address: name for name, address in stubs.items()}
        def external(machine, address, size, data):
            name = names.get(address)
            if name != 'exp':
                raise RuntimeError(f'Unexpected sleep classifier external call: {name}')
            value = struct.unpack('<d', struct.pack('<Q', machine.reg_read(UC_ARM64_REG_D0)))[0]
            result = math.exp(value)
            machine.reg_write(UC_ARM64_REG_D0, struct.unpack('<Q', struct.pack('<d', result))[0])
            machine.reg_write(UC_ARM64_REG_PC, machine.reg_read(UC_ARM64_REG_LR))
        u.hook_add(UC_HOOK_CODE, external, begin=stub_base, end=stub_base+0xffff)
        self.entry = self.base + elf.get_section_by_name('.symtab').get_symbol_by_name('r1_classify')[0]['st_value']
        self.stack, self.data, self.end = 0x3000000, 0x4000000, 0x5000000
        u.mem_map(self.stack, 0x20000)
        u.mem_map(self.data, 0x1000)
        u.mem_map(self.end, 0x1000)
        # Segment permissions retain executable code and read-only model data.
        u.mem_protect(self.base, size, 1)
        for segment in segments:
            start = segment['p_vaddr'] & ~4095
            length = (segment['p_vaddr']+segment['p_memsz']-start+4095)&~4095
            flags = segment['p_flags']
            u.mem_protect(self.base+start, length, (1 if flags&4 else 0)|(2 if flags&2 else 0)|(4 if flags&1 else 0))

    def __call__(self, features):
        from unicorn.arm64_const import UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_SP, UC_ARM64_REG_LR, UC_ARM64_REG_PC, UC_ARM64_REG_CPACR_EL1
        matrix = np.ascontiguousarray(features, dtype=np.float32)
        if matrix.ndim != 2 or matrix.shape[1] != 182 or len(matrix)>6000:
            raise ValueError('Sleep classifier expects at most 6000 rows of 182 features')
        output = np.empty((len(matrix),4), dtype=np.float32)
        with self.lock:
            u = self.uc
            try:
                for i, row in enumerate(matrix):
                    u.mem_write(self.data, row.tobytes())
                    u.reg_write(UC_ARM64_REG_X0, self.data)
                    u.reg_write(UC_ARM64_REG_X1, self.data+1024)
                    u.reg_write(UC_ARM64_REG_SP, self.stack+0x1fff0)
                    u.reg_write(UC_ARM64_REG_LR, self.end)
                    u.reg_write(UC_ARM64_REG_CPACR_EL1, 3<<20)
                    u.emu_start(self.entry, self.end, timeout=2_000_000, count=2_000_000)
                    if u.reg_read(UC_ARM64_REG_PC) != self.end:
                        raise RuntimeError('Sleep classifier execution budget exceeded')
                    output[i] = np.frombuffer(u.mem_read(self.data+1024,16),dtype='<f4')
            finally:
                u.mem_write(self.data, bytes(4096))
                u.mem_write(self.stack, bytes(0x20000))
        return output


@lru_cache(maxsize=1)
def _classifier():
    return _Classifier()


def _windows(timestamps, seconds):
    import torch
    if timestamps.dtype != torch.int64 or timestamps.ndim != 2 or timestamps.shape[1] != 1 or len(timestamps)==0:
        raise ValueError('Window timestamps must be a nonempty int64 Nx1 tensor')
    t = timestamps.detach().numpy().reshape(-1)
    if np.any(t[1:] < t[:-1]) or not math.isfinite(seconds):
        raise ValueError('Invalid window timestamps or duration')
    period = int(seconds*1000)
    if period<1:raise ValueError('Window duration must be at least 1 ms')
    origin = int(t[0])//period*period
    last = int(t[-1]); trunc_last = (abs(last)//period)*(1 if last>=0 else -1)
    boundary = last+period-(last-trunc_last*period)
    count = (boundary-origin)//period
    if not 1<=count<100000:raise ValueError('Window count exceeds source contract')
    ends = origin+np.arange(1,count+1,dtype=np.int64)*period
    starts = ends-period
    result = np.stack([np.searchsorted(t,ends-300000), np.searchsorted(t,ends-60000), np.searchsorted(t,starts),np.searchsorted(t,ends-1)],axis=1)
    result[ends-300000<origin,0] = -1
    result[ends-60000<origin,1:] = -1
    return [torch.from_numpy(ends.reshape(-1,1)), torch.from_numpy(result.astype(np.int64))]


def _indices(x, xnew):
    import torch
    a,b = x.detach().numpy().astype(np.float64),xnew.detach().numpy().astype(np.float64)
    if a.ndim!=1 or b.ndim!=1 or len(a)<2 or np.any(a[1:]<a[:-1]) or np.any(b[1:]<b[:-1]) or (len(b) and b[-1]>a[-1]):
        raise ValueError('Interpolation indices need sorted vectors within the input endpoint')
    return torch.from_numpy((np.maximum(np.searchsorted(a,b,side='left'),1)-1).astype(np.int64))


def _peaks(x):
    import torch
    if x.ndim!=1:raise ValueError('Peaks input must be one dimensional')
    a=x.detach().numpy().astype(np.float64); result=[]; i=1
    while i<len(a)-1:
        if a[i-1]<a[i]:
            j=i+1
            while j<len(a)-1 and a[j]==a[i]:j+=1
            if a[j]<a[i]:result.append((i+j-1)//2)
            i=j
        else:i+=1
    return torch.tensor(result,dtype=torch.int64)


def _biquad(sos,x):
    import torch
    from .health_native import _library
    if sos.ndim!=2 or sos.shape[1]!=6 or x.ndim!=1:raise ValueError('Invalid biquad dimensions')
    coeff=sos.detach().numpy().astype(np.float32)
    coeff=np.ascontiguousarray(coeff/coeff[:,3:4])
    raw=np.ascontiguousarray(x.detach().numpy(),dtype=np.float32);out=np.empty_like(raw)
    fn=_library().ring_biquad
    pointer=np.ctypeslib.ndpointer(dtype=np.float32,flags='C_CONTIGUOUS')
    fn.argtypes=[pointer,ctypes.c_int,pointer,ctypes.c_int,pointer];fn.restype=ctypes.c_int
    if fn(coeff,len(coeff),raw,len(raw),out)<0:raise ValueError('Invalid biquad size')
    return torch.from_numpy(out)


def register_sleep_ops():
    """Register the original graph's CPU operator contract once per process."""
    import torch
    with _register_lock:
        if _libraries:return
        lib=torch.library.Library('oura_ops','DEF')
        for schema in ('oura_create_windows(Tensor timestamps, float seconds) -> Tensor[]','oura_find_indices(Tensor x, Tensor xnew) -> Tensor','oura_find_peaks(Tensor x) -> Tensor','oura_biquad_cascade(Tensor sos, Tensor x) -> Tensor','oura_sleep_classifier(Tensor features) -> Tensor'):
            lib.define(schema)
        for name,fn in [('oura_create_windows',_windows),('oura_find_indices',_indices),('oura_find_peaks',_peaks),('oura_biquad_cascade',_biquad),('oura_sleep_classifier',lambda x:torch.from_numpy(_classifier()(x.detach().numpy())))]:
            lib.impl(name,fn,'CPU')
        _libraries.append(lib)
