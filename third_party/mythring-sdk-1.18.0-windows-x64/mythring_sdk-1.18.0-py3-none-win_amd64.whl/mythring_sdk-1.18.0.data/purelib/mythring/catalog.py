"""Bundled firmware targets and read-only, product-aware compatibility checks.

The JSON catalog is the release contract; discovering a target never downloads
or flashes it. Missing board/bootloader evidence is not an upgrade permission.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

_DIRECTORY = Path(__file__).with_name("firmware")


def _catalog() -> dict:
    data = json.loads((_DIRECTORY / "catalog.json").read_text(encoding="utf-8"))
    if data.get("schema_version") != 1 or not isinstance(data.get("targets"), list):
        raise ValueError("Unsupported firmware catalog schema")
    identifiers = [entry["target_id"] for entry in data["targets"]]
    if len(set(identifiers)) != len(identifiers):
        raise ValueError("Duplicate firmware target IDs")
    return data


def _package_path(entry: dict) -> Path:
    name = entry["package_file"]
    if not isinstance(name, str) or Path(name).name != name or not name.endswith(".zip"):
        raise ValueError("Invalid bundled firmware filename")
    path = (_DIRECTORY / name).resolve()
    if path.parent != _DIRECTORY.resolve():
        raise ValueError("Firmware package is outside the SDK attachment directory")
    return path


def list_firmware_targets() -> tuple[dict, ...]:
    """Return fresh JSON-compatible metadata, without connecting to a device."""
    catalog = _catalog()
    return tuple(dict(entry, catalog_revision=catalog["catalog_revision"],
                      package_path=str(_package_path(entry))) for entry in catalog["targets"])


def get_firmware_target(target_id: str) -> dict:
    for target in list_firmware_targets():
        if target["target_id"] == target_id:
            return target
    raise ValueError(f"Unknown firmware target: {target_id}")


def bundled_firmware_path(target_id: str) -> Path:
    """Validate the selected attachment against its catalog before using it."""
    from .ota import FirmwarePackage, FirmwarePackageError
    entry = get_firmware_target(target_id)
    path = Path(entry["package_path"])
    if not path.is_file() or path.stat().st_size > 64 * 1024 * 1024:
        raise FirmwarePackageError("Bundled firmware is missing or exceeds its size limit")
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != entry["package_sha256"]:
        raise FirmwarePackageError("Bundled firmware package differs from its catalog")
    package = FirmwarePackage.parse(data)
    if (hashlib.sha256(package.image_bytes).hexdigest() != entry["image_sha256"]
            or package.runtime_version != entry["expected_info_version"]
            or package.version != entry["image_version"]):
        raise FirmwarePackageError("Bundled image identity differs from its catalog")
    package.verification_hash()
    return path


def evaluate_target(ring, target_id: str) -> dict:
    """Explain target compatibility without sending any BLE commands.

    A matching INFO display version is not proof that the same image is running.
    The current attachments intentionally retain unverified board/bootloader
    bounds. Their presence is not a recommendation to upgrade.
    """
    entry = get_firmware_target(target_id)
    result = dict(target_id=target_id, status="device_required", reason_code="not_connected",
                  reason="连接设备后可评估此固件目标。", can_update=False, can_verify=False,
                  current_version=None, target_version=entry["expected_info_version"],
                  same_version=False, catalog_revision=entry["catalog_revision"])
    info = getattr(ring, "device_info", None)
    if not getattr(ring, "is_connected", False) or info is None:
        return result
    result["current_version"] = info.firmware_version
    code = getattr(info, "hardware_revision", None)
    product = getattr(info, "product_id", None) or {1: "ringo", 2: "r1"}.get(code)
    if product is None:
        return dict(result, status="target_unverified", reason_code="unknown_product",
                    reason="无法确认设备产品型号。")
    if product != entry["product_id"] or code != entry["legacy_hardware_code"]:
        return dict(result, status="incompatible", reason_code="product_mismatch",
                    reason=f"此固件用于 {entry['product_id']}，当前设备为 {product}，不可交叉刷写。")
    sdk_ota = bool(entry["sdk_ota_supported"] and getattr(ring, "capabilities", {}).get("ota"))
    result["can_verify"] = sdk_ota
    result["same_version"] = info.firmware_version == entry["expected_info_version"]
    if not sdk_ota:
        return dict(result, status="unsupported", reason_code="sdk_ota_not_supported",
                    reason="当前设备协议尚未开放 SDK 在线 OTA；附件保留供核对与维护。")
    if result["same_version"]:
        return dict(result, status="same_version", reason_code="version_matches",
                    reason="设备版本文本与目标相同，无需按版本重复升级；可只读核验活动镜像。")
    if (entry.get("compatibility_status") != "verified" or not entry.get("board_revisions")
            or not entry.get("ota_profile")):
        return dict(result, status="target_unverified", reason_code="target_constraints_unverified",
                    reason="目标板级修订和 bootloader／分区适用范围尚未确认，不能推荐或执行附件升级。")
    board = getattr(info, "board_revision", None)
    ota_profile = getattr(info, "ota_profile", None)
    if board is None or ota_profile is None:
        return dict(result, status="target_unverified", reason_code="device_constraints_unknown",
                    reason="设备未提供板级修订或 OTA 配置身份。")
    if board not in entry["board_revisions"] or ota_profile != entry["ota_profile"]:
        return dict(result, status="incompatible", reason_code="ota_profile_mismatch",
                    reason="设备板级修订或 bootloader／分区配置与固件目标不匹配。")
    return dict(result, status="compatible", reason_code="target_compatible",
                reason="设备与目标的适配条件匹配；升级仍需应用显式发起。", can_update=True)


def check_known_package_product(package, info=None, *, hardware_code: int | None = None) -> None:
    """Also catch a renamed/extracted bundled image passed to the legacy API."""
    from .ota import FirmwarePackageError
    digest = hashlib.sha256(package.image_bytes).hexdigest()
    hardware_code = getattr(info, "hardware_revision", hardware_code)
    for entry in _catalog()["targets"]:
        if digest == entry["image_sha256"]:
            if hardware_code != entry["legacy_hardware_code"]:
                raise FirmwarePackageError(f"Selected firmware belongs to {entry['product_id']}; device product mismatch")
            return
