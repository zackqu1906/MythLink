"""Versioned wellness scoring equations from SDK 1.15.1 HealthScoring.kt."""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import date, datetime, timedelta
import math
from statistics import median

from .health_models import HealthQuality

VERSION = "wellness-v2-complete-today"


@dataclass(frozen=True)
class HealthScoringProfile:
    sleep_goal_minutes: int = 480
    preferred_onset_minute: int = 23 * 60

    def __post_init__(self):
        if not 360 <= self.sleep_goal_minutes <= 600 or not 0 <= self.preferred_onset_minute <= 1439:
            raise ValueError("Invalid sleep goal or preferred onset minute")


@dataclass(frozen=True)
class HealthScoreContributor:
    key: str
    score: float | None
    weight: float
    effective_weight: float
    input_value: float | None
    reference_value: float | None
    unit: str
    status: str


@dataclass(frozen=True)
class HealthActivityLoad:
    load_units: float | None
    observed_minutes: float
    minimum_minutes: int = 180


@dataclass(frozen=True)
class HealthScore:
    value: int | None
    status: str
    is_mock: bool = False
    label: str | None = "实验评分"
    maximum: int = 100
    algorithm_version: str = VERSION
    coverage: float = 0.0
    contributors: list[HealthScoreContributor] = field(default_factory=list)
    missing_inputs: list[str] = field(default_factory=list)


def _points(value, anchors):
    if value <= anchors[0][0]:
        return anchors[0][1]
    for left, right in zip(anchors, anchors[1:]):
        if value <= right[0]:
            return left[1] + (right[1] - left[1]) * (value - left[0]) / (right[0] - left[0])
    return anchors[-1][1]


def _contributor(key, weight, value, reference, unit, formula, status="AVAILABLE"):
    score = (max(0.0, min(100.0, formula(value, reference)))
             if value is not None and reference is not None and math.isfinite(value) and math.isfinite(reference) else None)
    return HealthScoreContributor(key, score, weight, 0.0, value, reference, unit,
                                   "MISSING_INPUT_OR_BASELINE" if score is None else status)


def _result(parts, usable, partial=False, nested_coverage=None):
    total = sum(part.weight for part in parts if part.score is not None)
    coverage = max(0.0, min(1.0, total if nested_coverage is None else nested_coverage))
    value = (max(0, min(100, math.floor(sum(p.score * p.weight for p in parts if p.score is not None) / total + .5)))
             if usable and total >= .5 else None)
    return HealthScore(value, "INSUFFICIENT_DATA" if value is None else "PARTIAL" if partial or coverage < .999 else "READY",
                       coverage=coverage,
                       contributors=[replace(p, effective_weight=0.0 if p.score is None or total == 0 else p.weight / total) for p in parts],
                       missing_inputs=[p.key for p in parts if p.score is None])


def empty_score() -> HealthScore:
    return _result([], False)


def activity_load(windows, now: int) -> HealthActivityLoad:
    seen, valid = set(), []
    for item in windows:
        key = item.window_key or str(item.start_utc_ms)
        if (item.quality == HealthQuality.VALID and item.duration_ms > 0 and item.steps >= 0
                and item.start_utc_ms + item.duration_ms <= now and key not in seen):
            valid.append(item)
            seen.add(key)
    minutes = sum(item.duration_ms / 60000 for item in valid)
    load = sum(item.duration_ms / 60000 * min(item.steps / (item.duration_ms / 60000) / 100, 2.4) ** 2 for item in valid)
    return HealthActivityLoad(load if minutes >= 180 else None, minutes)


def _reference(night, all_nights, get_value):
    current = date.fromisoformat(night.date)
    values = [get_value(item) for item in all_nights
              if current - timedelta(days=28) <= date.fromisoformat(item.date) < current
              and not item.is_partial and item.sleep_minutes >= 180]
    values = [value for value in values if value is not None]
    return median(values) if len(values) >= 3 else None


def _recovery(night, all_nights, temperature, heart_weight, hrv_weight, temperature_weight):
    resting = _reference(night, all_nights, lambda n: n.resting_heart_rate_bpm) if night is not None else None
    hrv = _reference(night, all_nights, lambda n: n.hrv_rmssd_ms if n.hrv_rmssd_ms is not None and n.hrv_rmssd_ms > 0 else None) if night else None
    temp = temperature.deviation_celsius if temperature and temperature.baseline_source not in ("NONE", "INITIAL_SLEEP") else None
    return [
        _contributor("RESTING_HEART_RATE", heart_weight, night.resting_heart_rate_bpm if night else None, resting, "bpm",
                     lambda x, baseline: 100 - max(0, x - baseline) * 100 / 12),
        _contributor("HRV", hrv_weight, night.hrv_rmssd_ms if night else None, hrv, "ms",
                     lambda x, baseline: _points(x / baseline, ((.4, 0), (.6, 40), (.8, 80), (1, 100)))),
        _contributor("TEMPERATURE_DEVIATION", temperature_weight, temp, 0.0, "°C",
                     lambda x, _: _points(abs(x), ((.2, 100), (.5, 70), (1, 20), (1.5, 0))),
                     "SHORT_BASELINE" if temperature and temperature.baseline_source == "LATEST_SLEEP" else "AVAILABLE"),
    ]


def sleep_score(night, all_nights, temperature, zone, profile: HealthScoringProfile) -> HealthScore:
    duration = night.sleep_duration_ms / 60000 if night else None
    local = datetime.fromtimestamp(night.estimated_onset_utc_ms / 1000, zone) if night else None
    onset = local.hour * 60 + local.minute if local else None
    deep = sum(e.duration_ms / 60000 for e in night.stages if e.stage == "DEEP" and e.quality == HealthQuality.VALID
               and not e.estimated and not e.provisional) if night else None
    span = (night.bed_end_utc_ms - night.bed_start_utc_ms) / 60000 if night else None
    span = span if span and span > 0 else None
    efficiency = duration / span if duration is not None and span is not None else None
    parts = [
        _contributor("SLEEP_DURATION", .25, duration, float(profile.sleep_goal_minutes), "min",
                     lambda x, b: _points(x / b, ((0, 0), (.375, 20), (.625, 55), (.75, 70), (.875, 90), (1, 100)))),
        _contributor("SLEEP_TIMING", .10, onset, float(profile.preferred_onset_minute), "minuteOfDay",
                     lambda x, b: 100 - max(0, min(abs(x - b), 1440 - abs(x - b)) - 30) * .12),
        _contributor("DEEP_SLEEP", .15, deep, duration if duration and duration > 0 else None, "min",
                     lambda x, b: _points(x / b, ((0, 0), (.05, 30), (.10, 65), (.15, 90), (.20, 100)))),
        _contributor("SLEEP_EFFICIENCY", .10, efficiency, 1.0, "ratio",
                     lambda x, _: _points(x, ((0, 0), (.60, 30), (.75, 65), (.85, 90), (.90, 100)))),
    ] + _recovery(night, all_nights, temperature, .15, .15, .10)
    known = sum(e.duration_ms / 60000 for e in night.stages if e.quality == HealthQuality.VALID and not e.estimated
                and not e.provisional and e.stage in ("LIGHT", "DEEP", "REM", "AWAKE")) if night else 0
    usable = bool(night and night.sleep_minutes >= 180 and span is not None and known / span >= .70)
    return _result(parts, usable, bool(night and night.is_partial or temperature and temperature.baseline_source == "LATEST_SLEEP"))


def today_score(day, days, all_nights, temperature) -> HealthScore:
    current = date.fromisoformat(day.date)
    previous = next((item.activity_load.load_units for item in days if item.date == (current - timedelta(days=1)).isoformat()), None)
    two_days = next((item.activity_load.load_units for item in days if item.date == (current - timedelta(days=2)).isoformat()), None)
    baseline = [item.activity_load.load_units for item in days if current - timedelta(days=30) <= date.fromisoformat(item.date) < current - timedelta(days=2)
                and item.activity_load.load_units is not None]
    has_reference = len(baseline) >= 3 and median(baseline) > 1
    reference = median(baseline) if has_reference else 30.0
    load_status = "AVAILABLE" if has_reference else "DEFAULT_REFERENCE"

    def load(value, base):
        return _points(value / base, ((0, 75), (.25, 100), (1.25, 100), (2, 60), (3, 0)))

    parts = [
        _contributor("SLEEP_SCORE", .50, day.sleep_score.value, 100.0, "score", lambda x, _: x, day.sleep_score.status),
        _contributor("YESTERDAY_ACTIVITY", .15, previous, reference, "walkingLoad", load, load_status),
        _contributor("TWO_DAYS_AGO_ACTIVITY", .10, two_days, reference, "walkingLoad", load, load_status),
    ] + _recovery(day.night, all_nights, temperature, .10, .10, .05)
    coverage = sum(part.weight * day.sleep_score.coverage if part.key == "SLEEP_SCORE" else part.weight
                   for part in parts if part.score is not None)
    complete = day.sleep_score.status == "READY" and load_status == "AVAILABLE" and coverage >= .999 and all(p.score is not None for p in parts)
    return _result(parts, complete, nested_coverage=coverage)


def average_score(scores) -> HealthScore:
    valid = [score for score in scores if score.value is not None]
    if not valid:
        return empty_score()
    return HealthScore(math.floor(sum(score.value for score in valid) / len(valid) + .5),
                       "READY" if len(valid) == 7 and all(score.status == "READY" for score in valid) else "PARTIAL",
                       coverage=sum(score.coverage for score in valid) / 7,
                       contributors=[HealthScoreContributor("VALID_DAYS", None, 1.0, 1.0, float(len(valid)), 7.0, "days", "AVAILABLE")])


__all__ = ["HealthScoringProfile", "HealthScoreContributor", "HealthActivityLoad", "HealthScore",
           "empty_score", "activity_load", "sleep_score", "today_score", "average_score"]
