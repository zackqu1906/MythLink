"""Raw2 CPU inference and the Android 1.15.1 touchpad interaction algorithm.

Two model heads form a 200 Hz logical frame timeline. Event timestamps remain
packet-ingress monotonic nanoseconds; all tokens in one notification share that
timestamp. Coordinates are logical pixels after the original motion curve.
"""
from __future__ import annotations

import asyncio
from collections import deque
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from enum import Enum
import hashlib
import logging
import math
import time
from typing import Any
import uuid

from mythring.touchpad import TouchpadToken

_LOG = logging.getLogger(__name__)
PERIOD_NS = 5_000_000
EXPIRY_NS = 200_000_000
MODEL_SHA256 = "c16d77015ad37ec09a7b3b9d86055aab910096ce4595142c91238724eed3c8ab"
STATE_WIDTHS = (256, 256, 256, 256, 64, 64, 64)
_LONG_MAX = (1 << 63) - 1


class MotionMode(str, Enum):
    UNKNOWN = "unknown"
    SINGLE = "single"
    TWO_FINGER = "two_finger"


class EpisodeMode(str, Enum):
    UNKNOWN = "unknown"
    SINGLE = "single"
    TWO_FINGER = "two_finger"


class ContactPhase(str, Enum):
    BEGIN = "begin"
    CLASSIFIED = "classified"
    END = "end"
    CANCEL = "cancel"


class Button(str, Enum):
    LEFT = "left"
    RIGHT = "right"


@dataclass(frozen=True)
class TouchpadMeta:
    session_id: str
    interaction_generation: int
    sequence: int
    source_time_ns: int


@dataclass(frozen=True)
class ContactRange:
    start_frame: int
    start_time_ns: int
    end_frame_exclusive: int | None = None
    end_time_ns: int | None = None


@dataclass(frozen=True)
class Motion:
    meta: TouchpadMeta
    frame_id: int
    dx: float
    dy: float
    mode: MotionMode
    episode_id: int | None


@dataclass(frozen=True)
class ContactUpdate:
    meta: TouchpadMeta
    episode_id: int
    phase: ContactPhase
    mode: EpisodeMode
    range: ContactRange


@dataclass(frozen=True)
class Click:
    meta: TouchpadMeta
    click_id: int
    button: Button
    count: int
    is_preview: bool


TouchpadEvent = Motion | ContactUpdate | Click


class TouchpadBacklogWarning(RuntimeWarning):
    """Recoverable processing delay; stale interactions have been discarded."""

    def __init__(self, delay_ns: int) -> None:
        self.delay_ms = delay_ns / 1_000_000
        super().__init__(f"Touchpad processing delayed {self.delay_ms:.0f} ms; "
                         "stale interactions discarded, stream remains active")


class Raw2Model:
    """The exact seven-state Raw2 ONNX receiver, using CPUExecutionProvider.

    ``session`` is an injectable ONNX-compatible session for deterministic
    tests. Production calls unlock the bundled model only in memory.
    """

    output_names = ("xy", "touch", "finger", *(f"next_h{i}" for i in range(7)))

    def __init__(self, *, session: Any = None, model_bytes: bytes | None = None,
                 warmup_steps: int = 1) -> None:
        import numpy as np
        self._np = np
        if not isinstance(warmup_steps, int) or warmup_steps < 0:
            raise ValueError("warmup_steps must be a nonnegative integer")
        if session is not None and model_bytes is not None:
            raise ValueError("Provide a session or model bytes, not both")
        if session is None:
            import onnxruntime as ort
            if model_bytes is None:
                from mythring.protected_models import load_model_bytes
                model_bytes = load_model_bytes(kind="touchpad")
            if hashlib.sha256(model_bytes).hexdigest() != MODEL_SHA256:
                raise ValueError("Raw2 model SHA-256 does not match SDK 1.15.1")
            options = ort.SessionOptions()
            options.intra_op_num_threads = options.inter_op_num_threads = 1
            session = ort.InferenceSession(model_bytes, options, providers=["CPUExecutionProvider"])
        self._session = session
        self._validate_contract()
        self.reset()
        for _ in range(warmup_steps):
            self.step((0.0,) * 8)
        self.reset()

    def _validate_contract(self) -> None:
        inputs = {node.name: node for node in self._session.get_inputs()}
        output_nodes = self._session.get_outputs()
        outputs = {node.name: node for node in output_nodes}
        if len(inputs) != 8 or tuple(node.name for node in output_nodes) != self.output_names:
            raise ValueError("Raw2 model input/output contract mismatch")
        for nodes, name, width in (
            (inputs, "features", 8), (outputs, "xy", 4),
            (outputs, "touch", 2), (outputs, "finger", 2),
            *((inputs, f"h{i}", width) for i, width in enumerate(STATE_WIDTHS)),
            *((outputs, f"next_h{i}", width) for i, width in enumerate(STATE_WIDTHS)),
        ):
            node = nodes.get(name)
            if node is None or node.type != "tensor(float)" or list(node.shape) != [1, width]:
                raise ValueError(f"Raw2 tensor contract mismatch: {name}")

    def reset(self) -> None:
        self._states = [self._np.zeros((1, width), dtype=self._np.float32) for width in STATE_WIDTHS]

    def step(self, features: Sequence[float]) -> tuple[float, ...]:
        np = self._np
        values = np.asarray(features, dtype=np.float32)
        if values.shape != (8,) or not np.isfinite(values).all():
            raise ValueError("Raw2 expects eight finite features")
        feed = {"features": values.reshape(1, 8)}
        feed.update((f"h{i}", state) for i, state in enumerate(self._states))
        outputs = self._session.run(list(self.output_names), feed)
        if len(outputs) != 10:
            raise ValueError("Raw2 model output count mismatch")
        for output, width in zip(outputs, (4, 2, 2, *STATE_WIDTHS)):
            if output.shape != (1, width) or output.dtype != np.float32 or not np.isfinite(output).all():
                raise ValueError("Raw2 output/state shape, dtype or finiteness mismatch")
        # Validate all outputs before advancing live recurrent state.
        self._states = [output.copy() for output in outputs[3:]]
        xy, touch, finger = outputs[:3]
        return tuple(float(value) for head in range(2)
                     for value in (xy[0, head * 2], xy[0, head * 2 + 1], touch[0, head], finger[0, head]))

    def backend_state(self) -> tuple[float, ...]:
        return tuple(float(value) for state in self._states for value in state.ravel())


def motion_delta(vx: float, vy: float) -> tuple[float, float]:
    """Original trackpad-standard-v1 curve, shared by movement and scrolling."""
    if not math.isfinite(vx) or not math.isfinite(vy):
        raise ValueError("Nonfinite velocity")
    speeds = (0, .05, .10, .20, .325, .50, .75, 1.10, 1.55, 2.15, 3, 4)
    ratios = (292.5, 292.5, 303.75, 330, 371.25, 423.75, 491.25, 615, 768.75, 1001.25, 1312.5, 1665)
    speed, ratio = math.hypot(vx, vy), ratios[-1]
    for index in range(1, len(speeds)):
        if speed <= speeds[index]:
            ratio = ratios[index - 1] + (speed - speeds[index - 1]) / (speeds[index] - speeds[index - 1]) * (ratios[index] - ratios[index - 1])
            break
    dx, dy = vx * ratio * .005, vy * ratio * .005
    return (0.0, 0.0) if math.hypot(dx, dy) < .1 else (dx, dy)


@dataclass(frozen=True)
class _ContactTimes:
    down_time_ns: int
    up_time_ns: int
    down_frame_time_ns: int
    up_frame_time_ns: int


class _ClickPairing:
    WINDOW = 250_000_000
    MAX_CONTACT = 200_000_000
    MAX_WAIT = 1_000_000_000

    def __init__(self, sink: Any, ids: Callable[[], int]) -> None:
        self.sink, self.ids = sink, ids
        self.last_lateness = self.max_lateness = 0
        self.entered = self.id = self.safe_ready_at = 0
        self.clear()

    def clear(self) -> None:
        self.first: _ContactTimes | None = None
        self.second_down: int | None = None
        self.safe = -(1 << 63)

    def down(self, frame_time: int, now: int) -> None:
        if self.first is not None and self.second_down is None and now > self.first.up_time_ns + self.WINDOW:
            self._single(now)
        if (self.first is not None and self.second_down is None
                and self.first.up_frame_time_ns < frame_time <= self.first.up_frame_time_ns + self.WINDOW
                and now <= self.first.up_time_ns + self.WINDOW):
            self.second_down, self.safe_ready_at = frame_time, now

    def rejected(self, down: int, now: int) -> None:
        if self.second_down is not None and self.second_down == down:
            self._single(now)

    def candidate(self, button: Button, contact: _ContactTimes, now: int) -> None:
        if now > contact.up_time_ns + EXPIRY_NS:
            self.rejected(contact.down_frame_time_ns, now)
            return
        if self.first is not None and self.second_down == contact.down_frame_time_ns:
            if button == Button.LEFT:
                self.sink.click(self.id, Button.LEFT, (self.first, contact), now)
                self.first = self.second_down = None
                return
            self._single(now)
        elif self.first is not None:
            self._single(now)
        if button == Button.RIGHT:
            self.sink.click(self.ids(), button, (contact,), now)
            return
        self.first, self.entered, self.id, self.second_down = contact, now, self.ids(), None
        if now >= contact.up_time_ns + self.WINDOW:
            self._single(now)
        else:
            self.sink.preview(self.id, contact, now)

    def progress(self, frame_time: int, now: int) -> None:
        if self.second_down is not None and self.safe <= self.second_down + self.MAX_CONTACT < frame_time:
            self.safe_ready_at = now
        self.safe = frame_time
        self.tick(now)

    def tick(self, now: int) -> None:
        if self.first is None:
            return
        due = self.entered + self.MAX_WAIT
        if self.second_down is None:
            due = min(due, self.first.up_time_ns + self.WINDOW)
        elif self.safe > self.second_down + self.MAX_CONTACT:
            due = min(due, self.safe_ready_at)
        if now >= due:
            self.last_lateness = max(0, now - due)
            self.max_lateness = max(self.max_lateness, self.last_lateness)
            self._single(now)

    def next(self, now: int) -> int:
        if self.first is None:
            return _LONG_MAX
        if self.second_down is None:
            return self.first.up_time_ns + self.WINDOW
        return min(self.entered + self.MAX_WAIT, self.safe_ready_at) if self.safe > self.second_down + self.MAX_CONTACT else self.entered + self.MAX_WAIT

    def _single(self, now: int) -> None:
        contact, click_id = self.first, self.id
        self.first = self.second_down = None
        if contact is not None:
            self.sink.click(click_id, Button.LEFT, (contact,), now)


@dataclass(frozen=True)
class _Recognition:
    frame: int
    source: int
    ready: int
    x: float
    y: float
    touch: float
    finger: float


@dataclass
class _Episode:
    id: int
    start: int
    down_time: int
    end: int = _LONG_MAX
    two: bool | None = None
    seen: int = 0
    votes: int = 0


@dataclass(frozen=True)
class InteractionTiming:
    last_recognition_ns: int
    max_recognition_ns: int
    round_frames: int
    last_round_ns: int
    max_round_ns: int
    click_late_ns: int
    click_max_late_ns: int


class InteractionEngine:
    """Deterministic port; one owner calls publish, round and clear.

    ``sink`` implements motion/contact/click/preview with the argument order
    used below. TouchpadInference supplies the public immutable event sink.
    """

    def __init__(self, sink: Any, ids: Callable[[], int]) -> None:
        self.sink, self.clicks = sink, _ClickPairing(sink, ids)
        self.episode_ids = self.dropped = self.recognition_progress = self.rounds = 0
        self.recognition_high = self.checkpoint = self.last_recognition_at = 0
        self.recognition_duration = self.recognition_max = self.round_max = 0
        self.timing: InteractionTiming | None = None
        self.clear()

    def clear(self) -> None:
        self.recognition: deque[_Recognition] = deque()
        self.fixed: dict[int, _Recognition] = {}
        self.fingers: dict[int, float] = {}
        self.history: deque[_Recognition] = deque(maxlen=15)
        self.active: _Episode | None = None
        self.published = self.last_touch = self.confirmed = -1
        self._edges: dict[bool, int] = {}
        self.clicks.clear()

    @staticmethod
    def _sigmoid(value: float) -> float:
        try:
            return 1 / (1 + math.exp(-value))
        except OverflowError:
            return 0.0

    def publish(self, g: int, arrival: int, values: Sequence[float], available: int) -> None:
        if len(values) != 8 or not all(math.isfinite(value) for value in values):
            raise ValueError("Expected two finite normalized heads")
        batch, previous = [], self.published
        for head in range(2):
            frame = g - 1 + head
            if frame < 0 or previous >= 0 and frame != previous + 1:
                raise ValueError("Touchpad frame discontinuity")
            x, y, touch, finger = values[head * 4:head * 4 + 4]
            batch.append(_Recognition(frame, arrival, available, x, y, self._sigmoid(touch), self._sigmoid(finger)))
            previous = frame
        if len(self.recognition) + 2 > 600:
            raise ValueError("Touchpad recognition frame capacity exceeded")
        self.recognition.extend(batch)
        self.published = previous
        self.recognition_high = max(self.recognition_high, len(self.recognition))

    def round(self, clock: Callable[[], int], valid: Callable[[], bool] = lambda: True) -> None:
        self.rounds = min(_LONG_MAX, self.rounds + 1)
        now = round_start = clock()
        processed = 0
        try:
            if not valid():
                return
            self.clicks.tick(clock())
            spent = 0
            for _ in range(2):
                if spent >= 1_000_000 or not valid() or not self.recognition:
                    break
                recognition = self.recognition.popleft()
                begin = clock()
                self._recognize(recognition, begin)
                finished = clock()
                self.recognition_duration = max(0, finished - begin)
                self.recognition_max = max(self.recognition_max, self.recognition_duration)
                spent += self.recognition_duration
                self.recognition_progress = min(_LONG_MAX, self.recognition_progress + 1)
                self.last_recognition_at = finished
                processed += 1
                if not valid():
                    return
                now = clock()
                self.clicks.tick(now)
            self.checkpoint = clock()
        finally:
            duration = max(0, clock() - round_start)
            self.round_max = max(self.round_max, duration)
            self.timing = InteractionTiming(self.recognition_duration, self.recognition_max, processed,
                                           duration, self.round_max, self.clicks.last_lateness, self.clicks.max_lateness)

    def next_wake(self, now: int) -> int:
        return now if self.recognition else self.clicks.next(now)

    @staticmethod
    def _mode(episode: _Episode) -> EpisodeMode:
        return EpisodeMode.UNKNOWN if episode.two is None else EpisodeMode.TWO_FINGER if episode.two else EpisodeMode.SINGLE

    def _contact(self, episode: _Episode, phase: ContactPhase, confirming: _Recognition, now: int) -> None:
        closed = phase in (ContactPhase.END, ContactPhase.CANCEL)
        end = self.fixed.get(episode.end) if closed else None
        if closed and end is None:
            raise RuntimeError("Missing contact end reference")
        contact_range = ContactRange(episode.start, episode.down_time, episode.end if closed else None,
                                     end.source if end is not None else None)
        self.sink.contact(episode.id, phase, self._mode(episode), contact_range, confirming.source, now)

    def _accept_edge(self, down: bool, confirmation: int) -> bool:
        previous = self._edges.get(down)
        if previous is not None and confirmation - previous < 15:
            return False
        self._edges[down] = confirmation
        return True

    def _recognize(self, recognition: _Recognition, now: int) -> None:
        r = recognition
        if self.last_touch >= 0 and r.frame != self.last_touch + 1:
            raise ValueError("Touch frame gap")
        self.last_touch = r.frame
        self.fixed[r.frame], self.fingers[r.frame] = r, r.finger
        self.history.append(r)
        down, up = self._edge(True), self._edge(False)
        cancelled_down = new_down = None
        ended = None
        if down >= 0 and self._accept_edge(True, r.frame):
            self.confirmed = r.frame
            if self.active is not None:
                self.active.end = down
                self._decide(self.active, True)
                self._contact(self.active, ContactPhase.CANCEL, r, now)
                cancelled_down = self.active.start * PERIOD_NS
            start = self.fixed[down]
            if self.episode_ids == _LONG_MAX:
                raise RuntimeError("Episode identity exhausted")
            self.episode_ids += 1
            self.active = _Episode(self.episode_ids, down, start.source)
            self._contact(self.active, ContactPhase.BEGIN, r, now)
            new_down = start.frame * PERIOD_NS
        elif up >= 0 and self._accept_edge(False, r.frame):
            self.confirmed = r.frame
            if self.active is not None:
                ended, self.active = self.active, None
                ended.end = up
                self._decide(ended, True)
                self._contact(ended, ContactPhase.END, r, now)
        if self.active is not None:
            unknown = self.active.two is None
            self._decide(self.active, False)
            if unknown and self.active.two is not None:
                self._contact(self.active, ContactPhase.CLASSIFIED, r, now)
        if cancelled_down is not None:
            self.clicks.rejected(cancelled_down, now)
        if new_down is not None:
            self.clicks.down(new_down, now)
        if ended is not None:
            self._finish(ended, now)
        self.fingers = {frame: value for frame, value in self.fingers.items() if frame >= self.last_touch - 50}
        self.fixed = {frame: value for frame, value in self.fixed.items() if frame >= self.last_touch - 800}
        safe = self.fixed.get(self.last_touch - 14)
        if safe is not None:
            self.clicks.progress(safe.frame * PERIOD_NS, now)
        if now > r.source + EXPIRY_NS:
            self.dropped = min(_LONG_MAX, self.dropped + 1)
            return
        dx, dy = motion_delta(r.x, r.y)
        if dx != 0 or dy != 0:
            mode = (MotionMode.SINGLE if self.active is None else MotionMode.UNKNOWN if self.active.two is None
                    else MotionMode.TWO_FINGER if self.active.two else MotionMode.SINGLE)
            self.sink.motion(r.frame, mode, self.active.id if self.active else None, r.source, dx, dy, now)

    def _edge(self, down: bool) -> int:
        if len(self.history) != 15:
            return -1
        values = sorted(r.touch for r in self.history)
        high, low = values[12], values[2]
        if high - low <= .5 or abs(high - low - .5) <= 1e-12:
            return -1
        high_frames = [r.frame for r in self.history if r.touch >= high][-3:]
        low_frames = [r.frame for r in self.history if r.touch <= low][-3:]
        arrival, departure = (high_frames, low_frames) if down else (low_frames, high_frames)
        return arrival[0] if departure[-1] < arrival[0] and arrival[-1] == self.last_touch and arrival[0] > self.confirmed else -1

    def _decide(self, episode: _Episode, closed: bool) -> None:
        count = max(0, min(episode.start + 10, self.last_touch + 1, episode.end) - episode.start)
        for index in range(count):
            if not episode.seen & (1 << index):
                probability = self.fingers.get(episode.start + index)
                if probability is None:
                    raise RuntimeError("Finger vote history missing")
                episode.seen |= 1 << index
                if probability >= .5:
                    episode.votes |= 1 << index
        if episode.two is not None:
            return
        votes = (episode.votes & ((1 << count) - 1)).bit_count()
        if closed or votes >= 2 or count == 10:
            episode.two = votes >= 2

    def _finish(self, episode: _Episode, now: int) -> None:
        end = self.fixed.get(episode.end)
        if end is None or episode.end <= episode.start or (episode.end - episode.start) * PERIOD_NS >= EXPIRY_NS:
            self.clicks.rejected(episode.start * PERIOD_NS, now)
            return
        part = [self.fixed.get(frame) for frame in range(episode.start, episode.end)]
        if any(r is None for r in part):
            self.clicks.rejected(episode.start * PERIOD_NS, now)
            return
        x = y = 0.0
        for r in part:
            x += r.x * .005
            y += r.y * .005
        if math.hypot(x, y) > .020:
            self.clicks.rejected(episode.start * PERIOD_NS, now)
            return
        count = max(0, min(10, episode.end - episode.start))
        two = (episode.votes & ((1 << count) - 1)).bit_count() >= 2
        self.clicks.candidate(Button.RIGHT if two else Button.LEFT,
                              _ContactTimes(episode.down_time, end.source, episode.start * PERIOD_NS, episode.end * PERIOD_NS), now)


class TouchpadInference:
    """Synchronous model + interaction owner for transport-validated token batches."""

    def __init__(self, model: Any = None, *, clock: Callable[[], int] = time.monotonic_ns,
                 session_id: str | None = None) -> None:
        self.model = Raw2Model() if model is None else model
        self.clock = clock
        self.session_id = session_id or str(uuid.uuid4())
        self.generation = 1
        self.sequence = self.click_ids = self.ordinal = 0
        self._events: list[TouchpadEvent] = []
        self._backlogged = False
        self._warning: TouchpadBacklogWarning | None = None
        self.interaction = InteractionEngine(self, self._next_click_id)

    def _next_click_id(self) -> int:
        self.click_ids += 1
        return self.click_ids

    def _meta(self, source: int) -> TouchpadMeta:
        self.sequence += 1
        return TouchpadMeta(self.session_id, self.generation, self.sequence, source)

    def motion(self, frame: int, mode: MotionMode, episode_id: int | None, source: int,
               dx: float, dy: float, now: int) -> None:
        self._events.append(Motion(self._meta(source), frame, dx, dy, mode, episode_id))

    def contact(self, episode_id: int, phase: ContactPhase, mode: EpisodeMode,
                contact_range: ContactRange, source: int, now: int) -> None:
        self._events.append(ContactUpdate(self._meta(source), episode_id, phase, mode, contact_range))

    def click(self, click_id: int, button: Button, contacts: Sequence[_ContactTimes], now: int) -> None:
        self._events.append(Click(self._meta(contacts[0].up_time_ns), click_id, button, len(contacts), False))

    def preview(self, click_id: int, contact: _ContactTimes, now: int) -> None:
        self._events.append(Click(self._meta(contact.up_time_ns), click_id, Button.LEFT, 1, True))

    def process(self, tokens: Sequence[TouchpadToken], arrival_ns: int) -> tuple[TouchpadEvent, ...]:
        if not tokens:
            raise ValueError("Empty touchpad token batch")
        for token in tokens:
            self._check_backlog(arrival_ns)
            if token.reset:
                self.model.reset()
                if self.ordinal != 0:
                    self.generation += 1
                self.ordinal = 0
                self.interaction.clear()
            output = self.model.step(token.features)
            self.ordinal += 1
            # Advance every recurrent input, but never replay delayed interactions.
            if self._check_backlog(arrival_ns):
                continue
            self._backlogged = False
            self.interaction.publish(self.ordinal * 2 - 1, arrival_ns, output, self.clock())
            self.interaction.round(self.clock)
            self._check_backlog(arrival_ns)
        return self._drain()

    def round(self, scheduled_ns: int | None = None) -> tuple[TouchpadEvent, ...]:
        if scheduled_ns is None or not self._check_backlog(scheduled_ns):
            self.interaction.round(self.clock)
        return self._drain()

    def _check_backlog(self, started_ns: int) -> bool:
        delay = self.clock() - started_ns
        if delay < 0:
            raise RuntimeError("Touchpad arrival clock is invalid")
        if delay <= EXPIRY_NS:
            return False
        if not self._backlogged:
            self._backlogged = True
            self.generation += 1
            self.interaction.clear()
            self._warning = TouchpadBacklogWarning(delay)
        self._events.clear()
        return True

    def take_warning(self) -> TouchpadBacklogWarning | None:
        warning, self._warning = self._warning, None
        return warning

    def _drain(self) -> tuple[TouchpadEvent, ...]:
        events, self._events = tuple(self._events), []
        return events


class TouchpadRecognizer:
    """Async lifecycle around one serial CPU worker and the 5 ms click timer.

    Start this before the ring feature stream; feed its ``submit`` method from
    TouchpadClient's ``on_packet`` callback. Events/errors run on the asyncio
    loop, never on the inference thread. Recoverable delay emits a warning and
    cancels stale interactions. A stopped generation cannot publish.
    """

    def __init__(self, on_event: Callable[[TouchpadEvent], None],
                 on_error: Callable[[Exception], None] | None = None,
                 *, on_warning: Callable[[TouchpadBacklogWarning], None] | None = None,
                 model_factory: Callable[[], Any] = Raw2Model) -> None:
        self.on_event, self.on_error, self.model_factory = on_event, on_error, model_factory
        self.on_warning = on_warning
        self._generation = 0
        self._active = False
        self._task: asyncio.Task | None = None
        self._inflight: asyncio.Task | None = None
        self._queue: asyncio.Queue | None = None
        self._engine: TouchpadInference | None = None
        self._lock = asyncio.Lock()
        self.error: Exception | None = None

    @property
    def running(self) -> bool:
        return self._active

    @property
    def session_id(self) -> str | None:
        return self._engine.session_id if self._engine else None

    async def start(self) -> None:
        async with self._lock:
            if self._active:
                return
            if self._inflight is not None and not self._inflight.done():
                raise RuntimeError("Previous native touchpad model call has not finished")
            self._generation += 1
            generation = self._generation
            self.error = None
            loading = asyncio.create_task(asyncio.to_thread(lambda: TouchpadInference(self.model_factory())))
            loading.add_done_callback(self._consume_background_failure)
            self._inflight = loading
            engine = await asyncio.wait_for(asyncio.shield(loading), 20.0)
            if generation != self._generation:
                raise ConnectionError("Touchpad connection changed while loading the model")
            self._engine, self._active = engine, True
            self._queue = asyncio.Queue(maxsize=64)
            self._task = asyncio.create_task(self._run(generation, engine, self._queue), name="mythring-touchpad-inference")

    def submit(self, tokens: tuple[TouchpadToken, ...], arrival_ns: int) -> None:
        if not self._active or self._queue is None:
            return
        try:
            self._queue.put_nowait((tokens, arrival_ns))
        except asyncio.QueueFull:
            self._fail(RuntimeError("Touchpad receive queue is full"))

    def invalidate(self) -> None:
        """Synchronously discard this run on disconnect; native calls finish safely."""
        self._generation += 1
        self._active = False
        if self._task is not None:
            self._task.cancel()
        self._queue = self._engine = None

    async def stop(self) -> None:
        task = self._task
        self.invalidate()
        if task is not None and task is not asyncio.current_task():
            try:
                await task
            except asyncio.CancelledError:
                pass
        if self._task is task:
            self._task = None

    def _fail(self, error: Exception) -> None:
        if not self._active:
            return
        self.error = error
        self.invalidate()
        if self.on_error is not None:
            try:
                self.on_error(error)
            except Exception:
                _LOG.exception("Touchpad inference error callback failed")

    @staticmethod
    def _consume_background_failure(task: asyncio.Task) -> None:
        # Native calls can finish after cancellation; retrieve their errors without publishing.
        if not task.cancelled():
            task.exception()

    def _report_warning(self, engine: TouchpadInference) -> None:
        warning = engine.take_warning()
        if warning is not None:
            if self.on_warning is None:
                _LOG.warning("%s", warning)
            else:
                try:
                    self.on_warning(warning)
                except Exception:
                    _LOG.exception("Touchpad warning callback failed")

    async def _run(self, generation: int, engine: TouchpadInference, queue: asyncio.Queue) -> None:
        waiting = asyncio.create_task(queue.get())
        try:
            while self._active and generation == self._generation:
                # Keep the same get task across timer rounds: no canceled receive can lose a packet.
                started = time.monotonic_ns()
                done, _ = await asyncio.wait((waiting,), timeout=.005)
                if done:
                    tokens, arrival = waiting.result()
                    started = arrival
                    waiting = asyncio.create_task(queue.get())
                    work = asyncio.create_task(asyncio.to_thread(engine.process, tokens, arrival))
                else:
                    work = asyncio.create_task(asyncio.to_thread(engine.round, started))
                self._inflight = work
                work.add_done_callback(self._consume_background_failure)
                try:
                    events = await asyncio.wait_for(asyncio.shield(work), 3.0)
                except asyncio.TimeoutError as error:
                    raise RuntimeError("Native touchpad model call exceeded 3 seconds") from error
                if not self._active or generation != self._generation:
                    return
                # Check dispatch delay, including a stalled loop or event callback.
                if engine._check_backlog(started):
                    events = ()
                self._report_warning(engine)
                for event in events:
                    if not self._active or generation != self._generation:
                        return
                    if engine._check_backlog(started):
                        self._report_warning(engine)
                        break
                    try:
                        self.on_event(event)
                    except Exception:
                        _LOG.exception("Touchpad event callback failed")
        except asyncio.CancelledError:
            raise
        except Exception as error:
            if generation == self._generation:
                self._fail(error)
        finally:
            waiting.cancel()
            try:
                await waiting
            except asyncio.CancelledError:
                pass


__all__ = [
    "Raw2Model", "TouchpadInference", "TouchpadRecognizer", "TouchpadEvent",
    "TouchpadMeta", "Motion", "ContactUpdate", "Click", "ContactRange",
    "MotionMode", "EpisodeMode", "ContactPhase", "Button", "InteractionEngine",
    "InteractionTiming", "TouchpadBacklogWarning", "motion_delta",
]
