"""Daily, page and cross-language automatic health snapshots from SDK 1.15.1."""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field, fields, is_dataclass, replace
from datetime import date, datetime, time as clock_time, timedelta
from enum import Enum
import json
import math
from statistics import median
import time
from typing import Any
from zoneinfo import ZoneInfo

from .health_models import (
    HealthActivity, HealthBedtime, HealthLossRange, HealthMetric, HealthQuality,
    HealthReport, HealthRri, HealthSleepEpoch, HealthSource, HealthValue,
    HealthWearEvent, HealthWearStateEvent,
)
from .health_protocol import HealthCapabilities, HealthRecording, HealthState
from .health_scoring import (
    HealthActivityLoad, HealthScore, HealthScoreContributor, HealthScoringProfile,
    activity_load, average_score, empty_score, sleep_score, today_score,
)
from .health_temperature import (
    HealthTemperatureResult, build_temperature, merged_beds,
)


@dataclass(frozen=True)
class PublicHealthReport:
    recording: HealthRecording
    algorithm_version: str
    values: list[HealthValue]
    activity: list[HealthActivity]
    bedtimes: list[HealthBedtime]
    sleep: list[HealthSleepEpoch]
    wear: list[HealthWearEvent]
    activity_available: bool
    nightly_hrv_available: bool
    warnings: list[str]
    wear_states: list[HealthWearStateEvent] = field(default_factory=list)
    wear_states_available: bool = False
    temperature_available: bool = False

    @classmethod
    def from_report(cls, report: HealthReport):
        return cls(report.recording, report.algorithm_version, report.values, report.activity, report.bedtimes,
                   [replace(epoch, probabilities=None) for epoch in report.sleep], report.wear,
                   report.activity_available, report.nightly_hrv_available, report.warnings,
                   report.wear_states, report.wear_states_available, report.temperature_available)


@dataclass(frozen=True)
class VitalHistoryValue:
    measurement: HealthValue
    date: str
    period: str
    derived_from_rri: bool


@dataclass(frozen=True)
class DailyHealthSummary:
    date: str
    time_zone: str
    steps: int | None
    walking_seconds: int | None
    activity_available: bool
    values: list[HealthValue]
    bedtimes: list[HealthBedtime]
    sleep: list[HealthSleepEpoch]
    valid_sleep_minutes: int
    has_valid_sleep: bool


@dataclass(frozen=True)
class SyncSummary:
    received_bytes: int = 0
    total_bytes: int = 0
    downloaded_record_count: int = 0
    current_steps_updated: bool = False
    deferred_record_ids: list[int] = field(default_factory=list)


@dataclass(frozen=True)
class SyncError:
    stage: str
    recording_id: int | None
    code: str
    device_code: int | None
    message: str


@dataclass(frozen=True)
class AutomaticSyncUpdate:
    stage: str
    recording_id: int | None = None
    received_bytes: int = 0
    total_bytes: int | None = None
    verified: bool = False
    cached_reports: list[PublicHealthReport] | None = None
    snapshot: AutomaticSyncResult | None = None


@dataclass(frozen=True)
class HealthBodyProfile:
    height_cm: float
    weight_kg: float

    def __post_init__(self):
        if not math.isfinite(self.height_cm) or not 100 <= self.height_cm <= 250:
            raise ValueError("height_cm must be 100..250 cm")
        if not math.isfinite(self.weight_kg) or not 20 <= self.weight_kg <= 300:
            raise ValueError("weight_kg must be 20..300 kg")


@dataclass(frozen=True)
class HealthSummaryOptions:
    body_profile: HealthBodyProfile | None = None
    debug_scores: bool = False  # Compatibility flag: ignored, as in Android 1.15.1.
    scoring_profile: HealthScoringProfile = field(default_factory=HealthScoringProfile)


@dataclass(frozen=True)
class HealthCaloriesSummary:
    kcal: float | None
    status: str
    excluded_steps: int


@dataclass(frozen=True)
class HealthActivityHour:
    start_utc_ms: int
    end_utc_ms: int
    local_hour: int
    utc_offset_seconds: int
    steps: int | None
    calories: HealthCaloriesSummary


@dataclass(frozen=True)
class HealthHeartHour:
    start_utc_ms: int
    end_utc_ms: int
    sample_count: int
    minimum_bpm: float | None
    maximum_bpm: float | None
    average_bpm: float | None


@dataclass(frozen=True)
class HealthHeartSummary:
    latest: HealthValue | None
    minimum_bpm: float | None
    maximum_bpm: float | None
    hourly: list[HealthHeartHour]


@dataclass(frozen=True)
class HealthNightSummary:
    date: str
    bed_start_utc_ms: int
    bed_end_utc_ms: int
    sleep_duration_ms: int
    sleep_minutes: int
    estimated_onset_utc_ms: int
    estimated_wake_utc_ms: int
    is_partial: bool
    stages: list[HealthSleepEpoch]
    resting_heart_rate_bpm: float | None
    resting_heart_rate_minutes: int
    average_spo2: float | None
    spo2_sample_count: int
    hrv_rmssd_ms: float | None = None
    hrv_minutes: int = 0


@dataclass(frozen=True)
class HealthSleepDay:
    date: str
    night: HealthNightSummary | None
    score: HealthScore


@dataclass(frozen=True)
class HealthSleepWeekSummary:
    from_date: str
    through_date: str
    days: list[HealthSleepDay]
    valid_night_count: int
    average_sleep_minutes: float | None
    average_onset_minutes_after_noon: float | None
    average_wake_minutes_after_noon: float | None
    average_score: HealthScore


@dataclass(frozen=True)
class HealthHrvPoint:
    start_utc_ms: int
    end_utc_ms: int
    period: str
    interval_minutes: int
    median_rmssd_ms: float | None
    sample_count: int
    valid_minutes: int
    is_complete: bool


@dataclass(frozen=True)
class HealthHrvTimeline:
    algorithm_version: str = "hrv-median-v3-day60-night10"
    unit: str = "ms"
    day_interval_minutes: int = 60
    night_interval_minutes: int = 10
    points: list[HealthHrvPoint] = field(default_factory=list)


@dataclass(frozen=True)
class HealthDayPageSummary:
    date: str
    steps: int | None
    hourly_activity: list[HealthActivityHour]
    walking_calories: HealthCaloriesSummary
    heart: HealthHeartSummary
    night: HealthNightSummary | None
    today_score: HealthScore
    sleep_score: HealthScore
    activity_load: HealthActivityLoad = field(default_factory=lambda: HealthActivityLoad(None, 0.0))
    hrv: HealthHrvTimeline = field(default_factory=HealthHrvTimeline)


@dataclass(frozen=True)
class HealthPageSummary:
    algorithm_version: str
    time_zone: str
    generated_at_utc_ms: int
    body_profile: HealthBodyProfile | None
    debug_scores_enabled: bool
    latest_heart: HealthValue | None
    today: HealthDayPageSummary
    days: list[HealthDayPageSummary]
    sleep_last7_days: HealthSleepWeekSummary
    scoring_profile: HealthScoringProfile = field(default_factory=HealthScoringProfile)


@dataclass(frozen=True)
class AutomaticSyncResult:
    account_scope: str
    device_address: str
    time_zone: str
    synced_at_utc_ms: int | None = None
    status: str = "EMPTY"
    device_state: HealthState | None = None
    sync: SyncSummary = field(default_factory=SyncSummary)
    reports: list[PublicHealthReport] = field(default_factory=list)
    vital_history: list[VitalHistoryValue] = field(default_factory=list)
    daily: list[DailyHealthSummary] = field(default_factory=list)
    loss_ranges: list[HealthLossRange] = field(default_factory=list)
    errors: list[SyncError] = field(default_factory=list)
    live_heart_supported: bool = False
    temperature: HealthTemperatureResult = field(default_factory=HealthTemperatureResult)
    page: HealthPageSummary | None = None
    capabilities: HealthCapabilities | None = None
    schema_version: int = 2

    def with_page_summary(self, options: HealthSummaryOptions | None = None,
                          now_utc_ms: int | None = None) -> AutomaticSyncResult:
        now = time.time_ns() // 1_000_000 if now_utc_ms is None else now_utc_ms
        page = build_page(self, options or HealthSummaryOptions(), now)
        if self.status == "DEMO":
            page = mark_demo_page(page)
        return replace(self, page=page)

    def to_map(self) -> dict[str, Any]:
        """Exact Android JSON contract: camelCase, string identities, explicit nulls."""
        return _wire(self)

    def to_json(self) -> str:
        return json.dumps(self.to_map(), ensure_ascii=False, allow_nan=False, separators=(",", ":"))


def _camel(name):
    first, *rest = name.split("_")
    return first + "".join(word[0].upper() + word[1:] for word in rest)


def _wire(value):
    if isinstance(value, Enum):
        return value.name
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, VitalHistoryValue):
        return _wire(value.measurement) | {"date": value.date, "period": value.period, "derivedFromRri": value.derived_from_rri}
    if is_dataclass(value):
        result = {_camel(item.name): _wire(getattr(value, item.name)) for item in fields(value)}
        if isinstance(value, HealthSleepEpoch):
            result.pop("probabilities", None)
        identities = []
        if isinstance(value, HealthRecording):
            identities = ["id"]
        elif isinstance(value, HealthValue):
            identities = ["measurementId"]
        elif isinstance(value, HealthState):
            identities = ["recordingId", "bootId"]
        elif isinstance(value, HealthLossRange):
            identities = ["firstSequence", "lastSequence"]
        elif isinstance(value, (SyncError, AutomaticSyncUpdate)):
            identities = ["recordingId"]
        for name in identities:
            if result[name] is not None:
                result[name] = str(result[name])
        if isinstance(value, SyncSummary):
            result["deferredRecordIds"] = [str(item) for item in value.deferred_record_ids]
        if isinstance(value, HealthCapabilities):
            for name in ("automatic", "swipe_day_concurrent", "swipe_sleep_concurrent", "retained_history", "ack_policy_supported",
                         "effective_accelerometer_hz", "effective_green_hz"):
                result[_camel(name)] = getattr(value, name)
        return result
    if isinstance(value, (list, tuple)):
        return [_wire(item) for item in value]
    if isinstance(value, dict):
        return {key: _wire(item) for key, item in value.items()}
    return value


def _distinct(values, key):
    found = {}
    for value in values:
        found.setdefault(key(value), value)
    return list(found.values())


def _local(timestamp, zone):
    return datetime.fromtimestamp(timestamp / 1000, zone)


def _start(day, zone):
    return int(datetime.combine(day, clock_time(), zone).timestamp() * 1000)


def _valid_sleep(epoch):
    return (epoch.quality == HealthQuality.VALID and not epoch.estimated and not epoch.provisional
            and epoch.stage in ("LIGHT", "DEEP", "REM") and epoch.duration_ms > 0)


@dataclass(frozen=True)
class HrvArtifactResult:
    rmssd_ms: float | None
    rejected: int
    intervals: int
    pairs: int
    original_rmssd_ms: float | None


def evaluate_hrv_artifacts(beats: list[HealthRri]) -> HrvArtifactResult:
    rows = sorted(beats, key=lambda row: row.time_utc_ms)
    rejected = [False] * len(rows)
    for index, row in enumerate(rows):
        if not math.isfinite(row.milliseconds) or not 350 <= row.milliseconds <= 1800 or row.confidence <= 0:
            rejected[index] = True
            continue
        near = [item.milliseconds for item in rows[max(0, index - 5):index + 6]
                if item.segment == row.segment and abs(item.time_utc_ms - row.time_utc_ms) <= 10000
                and math.isfinite(item.milliseconds) and 350 <= item.milliseconds <= 1800 and item.confidence > 0]
        if len(near) < 5:
            continue
        ordered, center = sorted(near), median(near)
        mad = median([abs(value - center) for value in near])
        spread = max(mad, (ordered[len(ordered) * 3 // 4] - ordered[len(ordered) // 4]) / 2)
        rejected[index] = abs(row.milliseconds - center) > max(center * .20, 3 * 1.4826 * spread)
    total = original = 0.0
    pairs = original_pairs = 0
    for index in range(1, len(rows)):
        left, right = rows[index - 1:index + 1]
        delta_time = right.time_utc_ms - left.time_utc_ms
        if (left.segment != right.segment or not 1 <= delta_time <= 2000 or abs(delta_time - right.milliseconds) > 150
                or not math.isfinite(left.milliseconds) or not math.isfinite(right.milliseconds)):
            continue
        delta = right.milliseconds - left.milliseconds
        original += delta * delta
        original_pairs += 1
        if not rejected[index - 1] and not rejected[index]:
            total += delta * delta
            pairs += 1
    bad = sum(rejected)
    good = len(rows) - bad
    return HrvArtifactResult(math.sqrt(total / pairs) if good >= 12 and pairs >= 10 and bad * 5 <= len(rows) else None,
                              bad, good, pairs, math.sqrt(original / original_pairs) if original_pairs >= 10 else None)


def build_vital_history(reports, zone: ZoneInfo | str, now: int) -> list[VitalHistoryValue]:
    zone = ZoneInfo(zone) if isinstance(zone, str) else zone
    beds = merged_beds(reports)

    def night(timestamp):
        return any(bed.start_utc_ms <= timestamp < bed.end_utc_ms for bed in beds)

    def row(value, derived):
        return VitalHistoryValue(value, _local(value.time_utc_ms, zone).date().isoformat(), "night" if night(value.time_utc_ms) else "day", derived)

    dated = [report for report in reports if "TIME_UNKNOWN" not in report.warnings and "POWER_DIAGNOSTIC" not in report.warnings]
    corrected_times, measured = set(), []
    for report in dated:
        for value in report.values:
            if value.metric == HealthMetric.HRV and value.source == HealthSource.FIRMWARE and value.quality == HealthQuality.VALID and night(value.time_utc_ms):
                beats = [beat for beat in report.rri if value.time_utc_ms <= beat.time_utc_ms < value.time_utc_ms + 30000 and beat.time_utc_ms <= now]
                screened = evaluate_hrv_artifacts(beats)
                matches = screened.original_rmssd_ms is not None and value.value is not None and abs(screened.original_rmssd_ms - value.value) <= max(.5, value.value * .02)
                if screened.rejected > 0 and len(beats) >= 12 and matches:
                    corrected_times.add(value.time_utc_ms)
                    value = replace(value, value=screened.rmssd_ms, source=HealthSource.ANDROID,
                                    quality=HealthQuality.VALID if screened.rmssd_ms is not None else HealthQuality.INSUFFICIENT_DATA)
            if 1 <= value.time_utc_ms <= now and value.quality == HealthQuality.VALID and value.value is not None and math.isfinite(value.value):
                measured.append(value)
    measured = _distinct(measured, lambda value: (value.metric, value.time_utc_ms))
    output = [row(value, value.metric == HealthMetric.HRV and value.time_utc_ms in corrected_times) for value in measured]
    measured_minutes = {value.time_utc_ms // 60000 for value in measured if value.metric == HealthMetric.HEART_RATE}
    hrv_minutes = {value.time_utc_ms // 60000 for value in measured if value.metric == HealthMetric.HRV}
    seen = set()
    for report in dated:
        groups = defaultdict(list)
        for beat in report.rri:
            if (1 <= beat.time_utc_ms <= now and math.isfinite(beat.milliseconds) and 350 <= beat.milliseconds <= 1800
                    and beat.confidence > 0 and night(beat.time_utc_ms) and beat.time_utc_ms not in seen):
                seen.add(beat.time_utc_ms)
                groups[(beat.segment, beat.time_utc_ms // 60000)].append(beat)
        for group in groups.values():
            runs = []
            for beat in sorted(group, key=lambda value: value.time_utc_ms):
                if not runs or beat.time_utc_ms - runs[-1][-1].time_utc_ms > 2000:
                    runs.append([beat])
                else:
                    runs[-1].append(beat)
            for run in runs:
                if len(run) >= 12 and run[-1].time_utc_ms // 60000 not in hrv_minutes:
                    rmssd = evaluate_hrv_artifacts(run).rmssd_ms
                    if rmssd is not None:
                        output.append(row(HealthValue(run[-1].time_utc_ms, HealthMetric.HRV, rmssd, "ms", HealthQuality.VALID,
                                                      HealthSource.ANDROID, min(beat.confidence for beat in run)), True))
            for run in runs:
                if len(run) >= 10 and run[-1].time_utc_ms - run[0].time_utc_ms >= 8000 and run[-1].time_utc_ms // 60000 not in measured_minutes:
                    output.append(row(HealthValue(run[-1].time_utc_ms, HealthMetric.HEART_RATE,
                                                  60000 / (sum(beat.milliseconds for beat in run) / len(run)), "bpm", HealthQuality.VALID,
                                                  HealthSource.ANDROID, min(beat.confidence for beat in run)), True))
    return sorted(_distinct(output, lambda item: (item.measurement.metric, item.measurement.time_utc_ms)), key=lambda item: item.measurement.time_utc_ms)


def bridge_restarts(epochs, reports):
    ordered, added = sorted(epochs, key=lambda epoch: epoch.start_utc_ms), []

    def bounds(report):
        if report.sleep:
            first = min(epoch.start_utc_ms for epoch in report.sleep)
            last = max(epoch.start_utc_ms + epoch.duration_ms for epoch in report.sleep)
            if first > 0 and last - first == report.recording.duration_ms:
                return HealthBedtime(first, last)
        recording = report.recording
        return HealthBedtime(recording.start_utc_ms, recording.start_utc_ms + recording.duration_ms) if recording.start_utc_ms > 0 and recording.duration_ms > 0 else None

    records = []
    for report in reports:
        if (report.recording.mode == 7 and report.recording.status in (1, 2, 3) and "BEDTIME_CROSS_BOOT_CONTEXT" in report.warnings
                and "TIME_UNKNOWN" not in report.warnings and "POWER_DIAGNOSTIC" not in report.warnings):
            interval = bounds(report)
            if interval is not None:
                records.append((report, interval))
    records.sort(key=lambda item: item[1].start_utc_ms)
    for (before, before_bounds), (after, after_bounds) in zip(records, records[1:]):
        start, end = before_bounds.end_utc_ms, after_bounds.start_utc_ms
        if not 1 <= end - start <= 120000:
            continue
        if not any(bed.start_utc_ms <= start and bed.end_utc_ms >= end and bed in after.bedtimes for bed in before.bedtimes):
            continue
        if any(epoch.start_utc_ms < end and epoch.start_utc_ms + epoch.duration_ms > start for epoch in ordered):
            continue
        left = next((epoch for epoch in reversed(ordered) if epoch.start_utc_ms + epoch.duration_ms == start), None)
        right = next((epoch for epoch in ordered if epoch.start_utc_ms == end), None)
        if not all(epoch is not None and epoch.stage in ("LIGHT", "DEEP", "REM", "AWAKE")
                   and epoch.quality in (HealthQuality.VALID, HealthQuality.GAP, HealthQuality.PROVISIONAL) for epoch in (left, right)):
            continue
        added.append(replace(left, start_utc_ms=start, duration_ms=end - start, probabilities=None, estimated=True,
                             provisional=left.provisional or right.provisional, quality=HealthQuality.GAP))
    return sorted(ordered + _distinct(added, lambda epoch: epoch.start_utc_ms), key=lambda epoch: epoch.start_utc_ms)


def build_daily(reports, zone: ZoneInfo | str, now: int) -> list[DailyHealthSummary]:
    zone = ZoneInfo(zone) if isinstance(zone, str) else zone
    dated = [report for report in reports if "TIME_UNKNOWN" not in report.warnings]
    activity = [item for report in dated for item in report.activity if 1 <= item.start_utc_ms <= now]
    values = _distinct([item for report in dated for item in report.values if 1 <= item.time_utc_ms <= now], lambda item: (item.metric, item.time_utc_ms))
    beds = merged_beds(dated)
    observed = []
    epochs = _distinct([epoch for report in dated for epoch in report.sleep if 1 <= epoch.start_utc_ms <= now and epoch.duration_ms > 0], lambda epoch: epoch.start_utc_ms)
    for epoch in sorted(epochs, key=lambda epoch: epoch.start_utc_ms):
        start = max(epoch.start_utc_ms, observed[-1].start_utc_ms + observed[-1].duration_ms if observed else epoch.start_utc_ms)
        end = min(epoch.start_utc_ms + epoch.duration_ms, now)
        if end > start:
            observed.append(replace(epoch, start_utc_ms=start, duration_ms=end - start, probabilities=None))
    sleep = bridge_restarts(observed, dated)
    dates = set()

    def add_range(start, end):
        if start <= 0 or end <= start:
            return
        day, last = _local(start, zone).date(), _local(end - 1, zone).date()
        while day <= last:
            dates.add(day)
            day += timedelta(days=1)

    for item in activity:
        add_range(item.start_utc_ms, item.start_utc_ms + 1)
    for item in values:
        add_range(item.time_utc_ms, item.time_utc_ms + 1)
    for bed in beds:
        add_range(bed.start_utc_ms, min(bed.end_utc_ms, now))
    for epoch in sleep:
        add_range(epoch.start_utc_ms, epoch.start_utc_ms + epoch.duration_ms)
    output = []
    for day in sorted(dates):
        start, end = _start(day, zone), _start(day + timedelta(days=1), zone)
        windows = sorted(_distinct([item for item in activity if start <= item.start_utc_ms < end and item.quality == HealthQuality.VALID],
                                   lambda item: item.window_key or f"legacy:{item.start_utc_ms}"), key=lambda item: item.start_utc_ms)
        day_beds = [HealthBedtime(max(bed.start_utc_ms, start), min(bed.end_utc_ms, end, now)) for bed in beds
                    if min(bed.end_utc_ms, end, now) > max(bed.start_utc_ms, start)]
        clipped = []
        for epoch in sleep:
            for bed in day_beds:
                left, right = max(epoch.start_utc_ms, bed.start_utc_ms), min(epoch.start_utc_ms + epoch.duration_ms, bed.end_utc_ms)
                if right > left:
                    clipped.append(replace(epoch, start_utc_ms=left, duration_ms=right - left))
        clipped.sort(key=lambda epoch: epoch.start_utc_ms)
        valid = [epoch for epoch in clipped if _valid_sleep(epoch)]
        available = any(report.activity_available and report.recording.start_utc_ms < end
                        and report.recording.start_utc_ms + report.recording.duration_ms > start for report in dated) or bool(windows)
        output.append(DailyHealthSummary(day.isoformat(), str(zone), sum(item.steps for item in windows) if windows else None,
                                         sum(item.duration_ms for item in windows if item.steps > 0) // 1000 if windows else None,
                                         available, sorted([item for item in values if start <= item.time_utc_ms < end], key=lambda item: item.time_utc_ms),
                                         day_beds, clipped, sum(epoch.duration_ms for epoch in valid) // 60000, bool(valid)))
    return output


def build_hrv_timeline(snapshot, day: date, zone: ZoneInfo, now: int) -> HealthHrvTimeline:
    start, end = _start(day, zone), _start(day + timedelta(days=1), zone)
    beds = [bed for report in snapshot.reports if "TIME_UNKNOWN" not in report.warnings and "POWER_DIAGNOSTIC" not in report.warnings
            for bed in report.bedtimes if bed.start_utc_ms > 0 and bed.end_utc_ms > bed.start_utc_ms]
    cuts = sorted({start, end, *[edge for bed in beds for edge in (bed.start_utc_ms, bed.end_utc_ms) if start < edge < end]})
    rows = sorted(_distinct([item.measurement for item in snapshot.vital_history
                             if item.measurement.metric == HealthMetric.HRV and item.measurement.quality == HealthQuality.VALID
                             and item.measurement.value is not None and math.isfinite(item.measurement.value) and item.measurement.value >= 0
                             and start <= item.measurement.time_utc_ms < end and item.measurement.time_utc_ms <= now], lambda item: item.time_utc_ms),
                  key=lambda item: item.time_utc_ms)
    points = []
    for left, right in zip(cuts, cuts[1:]):
        is_night = any(bed.start_utc_ms <= left < bed.end_utc_ms for bed in beds)
        interval, timestamp = (10 if is_night else 60), left
        while timestamp < right and timestamp < now:
            local = _local(timestamp, zone)
            floor = local.replace(minute=local.minute // interval * interval, second=0, microsecond=0)
            next_clock = int(floor.timestamp() * 1000) + interval * 60000
            until = min(right, next_clock)
            bucket = [row for row in rows if timestamp <= row.time_utc_ms < until]
            values = [row.value for row in bucket]
            points.append(HealthHrvPoint(timestamp, until, "NIGHT" if is_night else "DAY", interval, median(values) if values else None,
                                         len(values), len({row.time_utc_ms // 60000 for row in bucket}), until <= now))
            timestamp = until
    return HealthHrvTimeline(points=points)


def _hours(day, zone):
    timestamp, end = _start(day, zone), _start(day + timedelta(days=1), zone)
    output = []
    while timestamp < end:
        local = _local(timestamp, zone)
        following = min(timestamp + 3600000, end)
        output.append((timestamp, following, local.hour, int(local.utcoffset().total_seconds())))
        timestamp = following
    return output


def _walking_met(speed):
    anchors = ((0, 1), (1.6, 2.3), (3.2, 2.8), (4.0, 3.0), (4.5, 3.8), (5.6, 4.8), (6.4, 5.5), (7.2, 7.0), (8.0, 8.5))
    for left, right in zip(anchors, anchors[1:]):
        if speed <= right[0]:
            return left[1] + (right[1] - left[1]) * (speed - left[0]) / (right[0] - left[0])
    return anchors[-1][1]


def walking_calories(windows, body: HealthBodyProfile | None, now: int) -> HealthCaloriesSummary:
    if body is None:
        return HealthCaloriesSummary(None, "PROFILE_REQUIRED", 0)
    complete = [item for item in windows if item.duration_ms > 0 and item.start_utc_ms + item.duration_ms <= now]
    if not complete:
        return HealthCaloriesSummary(None, "NO_DATA", 0)
    energy = 0.0
    excluded = included = 0
    for item in complete:
        if item.steps == 0:
            included += 1
            continue
        seconds = item.duration_ms / 1000
        speed = item.steps / seconds * (body.height_cm / 100 * .414) * 3.6
        if speed > 9 or item.steps / seconds * 60 > 180:
            excluded += item.steps
            continue
        energy += (_walking_met(speed) - 1) * body.weight_kg * seconds / 3600
        included += 1
    return HealthCaloriesSummary(energy if included else None, "OUT_OF_RANGE" if not included else "PARTIAL" if excluded else "READY", excluded)


def _merge_intervals(intervals):
    output = []
    for item in sorted([item for item in intervals if item.start_utc_ms > 0 and item.end_utc_ms > item.start_utc_ms], key=lambda item: item.start_utc_ms):
        if output and item.start_utc_ms <= output[-1].end_utc_ms:
            output[-1] = replace(output[-1], end_utc_ms=max(output[-1].end_utc_ms, item.end_utc_ms))
        else:
            output.append(item)
    return output


def build_nights(snapshot, zone: ZoneInfo, now: int) -> list[HealthNightSummary]:
    reports = [report for report in snapshot.reports if "TIME_UNKNOWN" not in report.warnings and "POWER_DIAGNOSTIC" not in report.warnings]
    coverage = _merge_intervals([HealthBedtime(report.recording.start_utc_ms, min(now, report.recording.start_utc_ms + report.recording.duration_ms))
                                 for report in reports if report.recording.status in (1, 2, 3)])
    epochs = [epoch for day in snapshot.daily for epoch in day.sleep if 0 < epoch.start_utc_ms < now and epoch.duration_ms > 0]
    beds = []
    for bed in merged_beds(reports):
        end_date = _local(bed.end_utc_ms, zone).date()
        noon = int(datetime.combine(end_date, clock_time(12), zone).timestamp() * 1000)
        previous_noon = int(datetime.combine(end_date - timedelta(days=1), clock_time(12), zone).timestamp() * 1000)
        if bed.end_utc_ms <= now and previous_noon <= bed.start_utc_ms < noon:
            beds.append(bed)
    vitals = _distinct([item.measurement for item in snapshot.vital_history
                        if 1 <= item.measurement.time_utc_ms <= now and item.measurement.quality == HealthQuality.VALID
                        and item.measurement.value is not None and math.isfinite(item.measurement.value)], lambda item: (item.metric, item.time_utc_ms))

    def clipped(bed):
        result = []
        for epoch in epochs:
            left, right = max(epoch.start_utc_ms, bed.start_utc_ms), min(epoch.start_utc_ms + epoch.duration_ms, bed.end_utc_ms, now)
            if right > left:
                result.append(replace(epoch, start_utc_ms=left, duration_ms=right - left))
        return sorted(result, key=lambda epoch: epoch.start_utc_ms)

    groups = defaultdict(list)
    for bed in beds:
        groups[_local(bed.end_utc_ms, zone).date()].append(bed)
    result = []
    for day, candidates in groups.items():
        bed, stages = max(((bed, clipped(bed)) for bed in candidates),
                          key=lambda pair: (sum(epoch.duration_ms for epoch in pair[1] if _valid_sleep(epoch)), pair[0].end_utc_ms))
        asleep = [epoch for epoch in stages if _valid_sleep(epoch)]
        if not asleep:
            continue
        samples = [sample for sample in vitals if any(epoch.start_utc_ms <= sample.time_utc_ms < epoch.start_utc_ms + epoch.duration_ms for epoch in asleep)]

        def minute_values(metric, predicate=lambda value: True):
            minutes = defaultdict(list)
            for sample in samples:
                if sample.metric == metric and predicate(sample.value):
                    minutes[sample.time_utc_ms // 60000].append(sample.value)
            return sorted(sum(values) / len(values) for values in minutes.values())

        minutes = minute_values(HealthMetric.HEART_RATE)
        oxygen = [sample.value for sample in samples if sample.metric == HealthMetric.SPO2 and 1 <= sample.value <= 100]
        partial = (any(epoch.provisional or epoch.quality == HealthQuality.PROVISIONAL for epoch in stages)
                   or not any(item.start_utc_ms <= bed.start_utc_ms - 900000 and item.end_utc_ms >= bed.end_utc_ms + 900000 for item in coverage)
                   or any("BEDTIME_CONTEXT_PENDING" in report.warnings and report.recording.start_utc_ms < bed.end_utc_ms
                          and report.recording.start_utc_ms + report.recording.duration_ms > bed.start_utc_ms for report in reports))
        hrv = minute_values(HealthMetric.HRV, lambda value: value >= 0)
        duration = sum(epoch.duration_ms for epoch in asleep)
        result.append(HealthNightSummary(day.isoformat(), bed.start_utc_ms, bed.end_utc_ms, duration, duration // 60000,
                                         asleep[0].start_utc_ms, max(epoch.start_utc_ms + epoch.duration_ms for epoch in asleep),
                                         partial, stages, median(minutes) if len(minutes) >= 30 else None, len(minutes),
                                         sum(oxygen) / len(oxygen) if oxygen else None, len(oxygen), median(hrv) if len(hrv) >= 5 else None, len(hrv)))
    return sorted(result, key=lambda item: item.date)


def build_page(snapshot: AutomaticSyncResult, options: HealthSummaryOptions, now: int) -> HealthPageSummary:
    if now <= 0:
        raise ValueError("now must be positive")
    zone = ZoneInfo(snapshot.time_zone)
    today = _local(now, zone).date()
    reports = [report for report in snapshot.reports if "TIME_UNKNOWN" not in report.warnings and "POWER_DIAGNOSTIC" not in report.warnings]
    activity = _distinct([item for report in reports for item in report.activity if item.quality == HealthQuality.VALID
                          and 1 <= item.start_utc_ms <= now and item.duration_ms > 0 and item.steps >= 0], lambda item: item.window_key or f"legacy:{item.start_utc_ms}")
    heart = sorted(_distinct([item.measurement for item in snapshot.vital_history if item.measurement.metric == HealthMetric.HEART_RATE
                             and item.measurement.quality == HealthQuality.VALID and item.measurement.value is not None
                             and math.isfinite(item.measurement.value) and 1 <= item.measurement.time_utc_ms <= now], lambda item: item.time_utc_ms),
                   key=lambda item: item.time_utc_ms)
    nights = {night.date: night for night in build_nights(snapshot, zone, now)}
    dates = {date.fromisoformat(day.date) for day in snapshot.daily} | {date.fromisoformat(day) for day in nights} | {today}
    dates.update(_local(item.measurement.time_utc_ms, zone).date() for item in snapshot.vital_history if 1 <= item.measurement.time_utc_ms <= now)
    raw_days = []
    for day in sorted(day for day in dates if day <= today):
        bins = _hours(day, zone)
        windows = [item for item in activity if bins[0][0] <= item.start_utc_ms < bins[-1][1]]
        values = [item for item in heart if bins[0][0] <= item.time_utc_ms < bins[-1][1]]
        readings = [item.value for item in values]
        activity_hours, heart_hours = [], []
        for start, end, hour, offset in bins:
            hour_windows = [item for item in windows if start <= item.start_utc_ms < end]
            hour_values = [item.value for item in values if start <= item.time_utc_ms < end]
            activity_hours.append(HealthActivityHour(start, end, hour, offset, sum(item.steps for item in hour_windows) if hour_windows else None,
                                                      walking_calories(hour_windows, options.body_profile, now)))
            heart_hours.append(HealthHeartHour(start, end, len(hour_values), min(hour_values) if hour_values else None,
                                                max(hour_values) if hour_values else None, sum(hour_values) / len(hour_values) if hour_values else None))
        temperature = next((item for item in snapshot.temperature.nightly if item.date == day.isoformat()), None)
        raw_days.append(HealthDayPageSummary(day.isoformat(), sum(item.steps for item in windows) if windows else None,
                                             activity_hours, walking_calories(windows, options.body_profile, now),
                                             HealthHeartSummary(values[-1] if values else None, min(readings) if readings else None, max(readings) if readings else None, heart_hours),
                                             nights.get(day.isoformat()), empty_score(),
                                             sleep_score(nights.get(day.isoformat()), list(nights.values()), temperature, zone, options.scoring_profile),
                                             activity_load(windows, now), build_hrv_timeline(snapshot, day, zone, now)))
    days = [replace(day, today_score=today_score(day, raw_days, list(nights.values()),
                                                next((item for item in snapshot.temperature.nightly if item.date == day.date), None))) for day in raw_days]
    week = []
    for offset in range(6, -1, -1):
        day = (today - timedelta(days=offset)).isoformat()
        week.append(HealthSleepDay(day, nights.get(day), next((item.sleep_score for item in days if item.date == day), empty_score())))
    valid = [day.night for day in week if day.night is not None and not day.night.is_partial]

    def clock(timestamp, day):
        local = _local(timestamp, zone)
        offset = (local.date() - (date.fromisoformat(day) - timedelta(days=1))).days
        return offset * 1440 + (local.hour * 3600 + local.minute * 60 + local.second) / 60 - 720

    sleep_week = HealthSleepWeekSummary(week[0].date, week[-1].date, week, len(valid),
                                        sum(night.sleep_duration_ms / 60000 for night in valid) / len(valid) if valid else None,
                                        sum(clock(night.estimated_onset_utc_ms, night.date) for night in valid) / len(valid) if valid else None,
                                        sum(clock(night.estimated_wake_utc_ms, night.date) for night in valid) / len(valid) if valid else None,
                                        average_score([day.score for day in week]))
    return HealthPageSummary("health-page-v2", str(zone), now, options.body_profile, False, heart[-1] if heart else None,
                              next(day for day in days if day.date == today.isoformat()), days, sleep_week, options.scoring_profile)


def mark_demo_page(page: HealthPageSummary) -> HealthPageSummary:
    # Demo values remain actual calculated scores; mark every score as simulated.
    def score(value):
        return replace(value, is_mock=True, label="演示数据")

    days = [replace(day, today_score=score(day.today_score), sleep_score=score(day.sleep_score)) for day in page.days]
    week = replace(page.sleep_last7_days, days=[replace(day, score=score(day.score)) for day in page.sleep_last7_days.days],
                   average_score=score(page.sleep_last7_days.average_score))
    return replace(page, today=next(day for day in days if day.date == page.today.date), days=days, sleep_last7_days=week)


def build_automatic_result(*, account_scope: str, device_address: str, time_zone: str,
                           status: str, device_state: HealthState | None, sync: SyncSummary,
                           reports: list[HealthReport], loss_ranges: list[HealthLossRange], errors: list[SyncError],
                           live_heart_supported: bool = False, capabilities: HealthCapabilities | None = None,
                           now_utc_ms: int | None = None, synced_at_utc_ms: int | None = None,
                           options: HealthSummaryOptions | None = None) -> AutomaticSyncResult:
    now = time.time_ns() // 1_000_000 if now_utc_ms is None else now_utc_ms
    zone = ZoneInfo(time_zone)
    daily = build_daily(reports, zone, now)
    result = AutomaticSyncResult(account_scope, device_address, time_zone, synced_at_utc_ms, status, device_state, sync,
                                  [PublicHealthReport.from_report(report) for report in reports], build_vital_history(reports, zone, now), daily,
                                  loss_ranges, errors, live_heart_supported, build_temperature(reports, daily, zone, now), capabilities=capabilities)
    return result.with_page_summary(options, now)


class HealthPageSnapshotCache:
    """Caller-local projection cache; never shares body/scoring preferences."""

    def __init__(self, options: HealthSummaryOptions | None = None):
        self.options = options or HealthSummaryOptions()
        self.previous: AutomaticSyncResult | None = None

    def project(self, value: AutomaticSyncResult, now_utc_ms: int | None = None) -> AutomaticSyncResult:
        old = self.previous
        if (old is not None and old.page is not None and old.account_scope == value.account_scope and old.device_address == value.device_address
                and old.time_zone == value.time_zone and old.reports is value.reports and old.daily is value.daily
                and old.vital_history is value.vital_history and old.temperature is value.temperature
                and (old.status == "DEMO") == (value.status == "DEMO")):
            return replace(value, page=old.page)
        self.previous = value.with_page_summary(self.options, now_utc_ms)
        return self.previous


__all__ = [
    "PublicHealthReport", "VitalHistoryValue", "DailyHealthSummary", "SyncSummary", "SyncError", "AutomaticSyncUpdate", "AutomaticSyncResult",
    "HealthBodyProfile", "HealthSummaryOptions", "HealthCaloriesSummary", "HealthActivityHour", "HealthHeartHour", "HealthHeartSummary",
    "HealthNightSummary", "HealthSleepDay", "HealthSleepWeekSummary", "HealthHrvPoint", "HealthHrvTimeline", "HealthDayPageSummary", "HealthPageSummary",
    "HealthScoringProfile", "HealthScoreContributor", "HealthActivityLoad", "HealthScore", "HealthPageSnapshotCache",
    "HrvArtifactResult", "evaluate_hrv_artifacts", "bridge_restarts", "build_vital_history", "build_daily", "build_hrv_timeline",
    "build_nights", "build_page", "build_automatic_result", "walking_calories", "mark_demo_page",
]
