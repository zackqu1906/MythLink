"""Bounded cross-record and cross-boot bedtime context; sensor rows stay in their boot."""
from __future__ import annotations

import bisect
import math
from dataclasses import dataclass, field

from .health_analysis import HealthFeatureSegment, _i32, _u16, reconcile_wear, repair_bedtime
from .health_models import HealthBedtime
from .health_sleep import BedtimeDetector


@dataclass
class SleepContext:
    periods: list[HealthBedtime]
    warnings: set[str]
    start: int
    end: int
    finalized_boots: set[int] = field(default_factory=set)


def offset(segments):
    return next((segment.utc_offset for segment in reversed(segments) if segment.utc_offset is not None), None)


def groups(segments):
    by_boot = {}
    for segment in segments:
        by_boot.setdefault(segment.boot, []).append(segment)
    result = []
    for boot in by_boot.values():
        for segment in sorted(boot, key=lambda row: row.index):
            if result and HealthFeatureSegment.contiguous([result[-1][-1], segment]):
                result[-1].append(segment)
            else:
                result.append([segment])
    return sorted(result, key=lambda run: offset(run)+run[0].start if offset(run) is not None else 2**63-1)


def can_join(a, b):
    if any(not segment.feature_mask & 16 for segment in a+b) or a[-1].control_boundary(False) or b[0].control_boundary(True):
        return False
    ao, bo = offset(a), offset(b)
    if ao is None or bo is None:
        return False
    def states(run):
        return sorted((block for segment in run for block in segment.blocks if block.kind == 6 and block.payload[0] == 19), key=lambda block: block.uptime_ms)
    before, after = states(a), states(b)
    before = _i32(before[-1].payload, 1) & 255 if before else None
    after = _i32(after[0].payload, 1) & 255 if after else None
    return a[0].boot != b[0].boot and 0 <= bo+b[0].start-(ao+a[-1].end) <= 120000 and before != 0 and after != 0 and all(segment.blocks[0].payload[39] == 0 for segment in a+b)


def select(segments, target):
    runs = groups(segments)
    all_segments = [segment for run in runs for segment in run]
    owners = {segment: run for run in runs for segment in run}
    low = high = all_segments.index(target)
    def connected(a, b):
        return HealthFeatureSegment.contiguous([a, b]) or can_join(owners[a], owners[b])
    def fits(a, b):
        first, last = all_segments[a], all_segments[b]
        base = first.origin+(first.start-first.origin)//30000*30000
        if first.boot == last.boot:
            return last.end-base <= 86400000
        start, end = offset(owners[first]), offset(owners[last])
        return start is not None and end is not None and 0 <= end+last.end-(start+base) <= 86400000
    while high+1 < len(all_segments) and connected(all_segments[high], all_segments[high+1]) and fits(low, high+1):
        high += 1
    while low > 0 and connected(all_segments[low-1], all_segments[low]) and fits(low-1, high):
        low -= 1
    return groups(all_segments[low:high+1])


def context_input(segments):
    first = segments[0]
    base = first.origin+(first.start-first.origin)//30000*30000
    count = (segments[-1].end-base+29999)//30000
    seconds = [-1]*((count+1)//2*2)
    temperatures, non_wear, eligible = {}, [False]*len(seconds), [False]*len(seconds)
    recovered, _ = reconcile_wear(segments)
    for segment in segments:
        for block in segment.blocks:
            p, i = block.payload, (block.uptime_ms-base)//30000
            if block.kind == 4 and block.flags == 0 and _i32(p, 4) == 0 and 1 <= _i32(p) <= 60000:
                temperatures[block.uptime_ms] = _i32(p)
            if block.uptime_ms < base or not 0 <= i < count:
                continue
            if block.kind == 8:
                non_wear[i] = _u16(p, 28) > 0
            elif block.kind == 12:
                if (p[3] & 1 or block.uptime_ms in recovered) and 0 <= p[12] <= 30:
                    seconds[i] = p[12]
                eligible[i] = p[3] == 0 and p[14] == 30 and 24 <= p[13] <= 26 and _u16(p, 18) == 0 and 37 <= _u16(p, 16) <= 800
    temp, times = [0]*(len(seconds)//2), sorted(temperatures)
    for i in range(len(temp)):
        time = base+(min(i*2+1, count-1)+1)*30000
        j = bisect.bisect_right(times, time)-1
        if j >= 0 and time-times[j] <= 30000:
            temp[i] = math.floor(temperatures[times[j]]/10+.5)
    for i, off in enumerate(non_wear):
        if off:
            seconds[i] = 31
    return offset(segments)+base, repair_bedtime(seconds, temp, eligible), temp


def detect_context(runs):
    if not runs or not all(can_join(a, b) for a, b in zip(runs, runs[1:])):
        raise ValueError("Untrusted cross-boot sleep context")
    inputs = [context_input(run) for run in runs]
    start, end = inputs[0][0], offset(runs[-1])+runs[-1][-1].end
    if not 0 <= end-start <= 86400000:
        raise ValueError("Sleep context exceeds 24 hours")
    seconds = [-1]*((end-start+59999)//60000*2)
    half_temperature, warnings = [0]*len(seconds), set()
    for first, motion, temp in inputs:
        shift = math.floor((first-start)/30000+.5)
        for i, value in enumerate(motion):
            at = shift+i
            if 0 <= at < len(seconds):
                seconds[at], half_temperature[at] = value, temp[i//2]
    for run in runs[1:]:
        seam = offset(run)+run[0].start
        at = max(0, min(len(seconds)-1, (seam-start)//30000))
        left = next((i for i in range(at-1, max(0, at-5)-1, -1) if 0 <= seconds[i] <= 30), None)
        right = next((i for i in range(at, min(len(seconds), at+6)) if 0 <= seconds[i] <= 30), None)
        if left is None or right is None:
            continue
        duration = (right-left-1)*30000
        if right <= left or not 1 <= duration <= 120000 or any(seconds[i] != -1 for i in range(left+1, right)) or seconds[left] > 3 or seconds[right] > 3 or not 2600 <= half_temperature[left] <= 4000 or not 2600 <= half_temperature[right] <= 4000 or abs(half_temperature[left]-half_temperature[right]) > 100:
            continue
        for i in range(left+1, right):
            seconds[i], half_temperature[i] = max(seconds[left], seconds[right]), half_temperature[right]
        warnings.add("BEDTIME_RESTART_GAP_BRIDGED")
    if len(runs) > 1:
        warnings.add("BEDTIME_CROSS_BOOT_CONTEXT")
    temp = half_temperature[1::2]
    periods = [HealthBedtime(max(start, a), min(end, b)) for a, b in BedtimeDetector.detect(start, seconds, temp).periods if min(end, b) > max(start, a)] if any(value > 0 for value in temp) else []
    finalized = {previous[0].boot for previous, following in zip(runs, runs[1:]) if following[-1].end-following[0].start >= 900000}
    return SleepContext(periods, warnings, start, end, finalized)
