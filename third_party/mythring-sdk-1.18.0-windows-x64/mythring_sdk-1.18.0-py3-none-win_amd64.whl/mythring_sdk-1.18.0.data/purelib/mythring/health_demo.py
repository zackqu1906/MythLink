"""Explicit synthetic yesterday showcase; never used by sync or persisted to an archive."""
from dataclasses import replace
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
import time

from .health_models import *
from .health_summary import (HealthBodyProfile, HealthSummaryOptions, PublicHealthReport,
                            SyncSummary, AutomaticSyncResult, build_daily, build_vital_history)
from .health_temperature import HealthTemperaturePoint, HealthTemperatureNight, HealthTemperatureResult

HEART = (60.38,62.11,59.92,57.98,58.89,57.23,56.57,58.05,59.54,59.99,59.9,64.36,89.25,84.22,94.29,81.33,79.74,82.81,85.89,88.96,84.33,87.92,85.9,85.9)
HRV = (51.74,38.44,31.61,45.19,43.92,58.04,53.08,69.51,51.24,22.18,36.01,31.88,26.23,20.58,20.,20.,20.,20.,20.,20.,20.,20.,20.,20.)
TEMPERATURE = (-.143,-.021,-.047,-.089,-.125,-.045,-.14,-.06,-.118,-.093,-.117,-.165,-.495,-.008,-.146,-.127,-.285,-.6,-.281,-.107,-.033,-.047,-.071,-.071)
STEPS = (19,0,0,0,0,0,0,0,0,0,0,229,438,0,113,205,376,403,610,498,51,334,161,0)
SLEEP = "WLLLLLLLLLLLLLLDLLLLLLLLDDDDDLLRRRRLRLRRLLDDDDWLLDLDDDDDDLLLLLLDDDDDDDDDDDLLLLLLLLLLDDLLDDDDDLLLLLLLRLRRRRLRRLLLDDLLLLLLLLLLLLLDDRRRLLL"


class HealthDemoData:
    @staticmethod
    def yesterday(time_zone="UTC", now_utc_ms=None, options=None):
        now = time.time_ns()//1000000 if now_utc_ms is None else now_utc_ms
        if now <= 0:
            raise ValueError("A positive reference time is required")
        zone = ZoneInfo(time_zone)
        day = datetime.fromtimestamp(now/1000, zone).date()-timedelta(days=1)
        start = int(datetime.combine(day, datetime.min.time(), zone).timestamp()*1000)
        end = int(datetime.combine(day+timedelta(days=1), datetime.min.time(), zone).timestamp()*1000)
        bed_end = int(datetime(day.year, day.month, day.day, 8, tzinfo=zone).timestamp()*1000)
        bed = HealthBedtime(start, bed_end)
        def local(timestamp):
            return datetime.fromtimestamp(timestamp/1000, zone)
        def shape(values, timestamp):
            clock = local(timestamp)
            part = (clock.minute+clock.second/60)/60
            return values[clock.hour]*(1-part)+values[min(clock.hour+1, 23)]*part
        values, activity, sleep = [], [], []
        for timestamp in range(start, end, 60000):
            values.extend((HealthValue(timestamp, HealthMetric.HEART_RATE, shape(HEART, timestamp), "bpm", HealthQuality.VALID, HealthSource.ANDROID),
                           HealthValue(timestamp, HealthMetric.HRV, shape(HRV, timestamp), "ms", HealthQuality.VALID, HealthSource.ANDROID)))
            clock = local(timestamp)
            if clock.minute % 10 == 0:
                values.append(HealthValue(timestamp, HealthMetric.SPO2, 97.+(clock.minute//10 % 3)*.5, "%", HealthQuality.VALID, HealthSource.ANDROID))
        for a in range(start, end, 3600000):
            b = min(end, a+3600000)
            count, steps = (b-a)//60000, STEPS[local(a).hour]
            for i in range(count):
                value = steps//count+int(i < steps % count)
                t = a+i*60000
                activity.append(HealthActivity(t, 60000, value, value, .9 if value > 0 else .05, HealthQuality.VALID, f"demo:{t}"))
        for timestamp in range(start, bed_end, 300000):
            index = min(len(SLEEP)-1, (timestamp-start)*len(SLEEP)//(bed_end-start))
            stage = {"D": "DEEP", "R": "REM", "W": "AWAKE"}.get(SLEEP[index], "LIGHT")
            sleep.append(HealthSleepEpoch(timestamp, stage, None, False, False, HealthQuality.VALID, min(timestamp+300000, bed_end)-timestamp))
        report = HealthReport(HealthRecording(1, 1, 0, start-900000, end-start+900000, 7), "demo-complete-day-v1",
            values=values, activity=activity, bedtimes=[bed], sleep=sleep, warnings=["DEMO_DATA"],
            wear=[HealthWearEvent(start, 1)], wear_states=[HealthWearStateEvent(start, 2, 0)], wear_states_available=True, temperature_available=True)
        temperatures = []
        for period, first, until, interval in (("DAY", start, end, 3600000), ("NIGHT", start, bed_end, 300000)):
            for a in range(first, until, interval):
                b = min(until, a+interval)
                minutes = (b-a+59999)//60000
                temperatures.append(HealthTemperaturePoint(a, b, day.isoformat(), period, shape(TEMPERATURE, a), minutes, minutes, minutes, 7, "DEMO", "demo-baseline", "READY", True))
        night = [row for row in temperatures if row.period == "NIGHT"]
        result = AutomaticSyncResult(account_scope="demo", device_address="DEMO", time_zone=time_zone,
            synced_at_utc_ms=None, status="DEMO", device_state=None, sync=SyncSummary(),
            reports=[PublicHealthReport.from_report(report)], vital_history=build_vital_history([report], zone, now),
            daily=build_daily([report], zone, now), loss_ranges=[], errors=[],
            temperature=HealthTemperatureResult(history=temperatures, nightly=[HealthTemperatureNight(day.isoformat(), start, bed_end,
                sum(row.deviation_celsius for row in night)/len(night), sum(row.valid_minutes for row in night), sum(row.sample_count for row in night), 7, "DEMO", "demo-baseline", "READY")]))
        return result.with_page_summary(options or HealthSummaryOptions(body_profile=HealthBodyProfile(170., 65.)), now)


__all__ = ["HealthDemoData"]
