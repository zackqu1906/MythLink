"""macOS retrieval without advertising; native details match pinned Bleak 3.0.2."""
from __future__ import annotations

import asyncio
import logging
import sys
from uuid import UUID

_LOG = logging.getLogger(__name__)


async def _manager(timeout: float):
    from bleak.backends.corebluetooth.CentralManagerDelegate import CentralManagerDelegate

    manager = CentralManagerDelegate()
    await asyncio.wait_for(manager.wait_until_ready(), timeout)
    return manager


def _device(peripheral, manager):
    from bleak.backends.device import BLEDevice

    # Bleak must retain the manager which owns this CBPeripheral to connect it.
    return BLEDevice(str(peripheral.identifier().UUIDString()), peripheral.name(),
                     (peripheral, manager))


async def system_connected_devices(service_uuid: str, *, timeout: float):
    """Retrieve system-connected peripherals; no scan or connection is started."""
    if sys.platform != "darwin":
        return []
    try:
        from CoreBluetooth import CBUUID

        manager = await _manager(timeout)
        peripherals = manager.central_manager.retrieveConnectedPeripheralsWithServices_(
            [CBUUID.UUIDWithString_(service_uuid)])
        return [_device(peripheral, manager) for peripheral in peripherals]
    except Exception as error:
        _LOG.warning("CoreBluetooth system-connected retrieval failed: %s", error)
        return []


async def retrieve_device(address: str, *, timeout: float):
    """Resolve a cached macOS UUID before Bleak's advertisement-scan fallback."""
    if sys.platform != "darwin":
        return None
    try:
        identifier = str(UUID(address))
    except ValueError:
        return None
    try:
        from Foundation import NSUUID

        manager = await _manager(timeout)
        peripherals = manager.central_manager.retrievePeripheralsWithIdentifiers_(
            [NSUUID.alloc().initWithUUIDString_(identifier)])
        return _device(peripherals[0], manager) if peripherals else None
    except Exception as error:
        _LOG.warning("CoreBluetooth known-device retrieval failed for %s: %s", address, error)
        return None
