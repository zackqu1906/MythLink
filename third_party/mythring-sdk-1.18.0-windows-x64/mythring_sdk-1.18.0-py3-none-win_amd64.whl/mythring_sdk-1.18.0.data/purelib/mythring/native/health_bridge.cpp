// C ABI adaptation of the delivered HealthNative JNI entry points.
#include "hrv.h"
#include <vector>
#include <cmath>
#include <algorithm>
#include <cstdint>
extern "C" {
#include "sleep_observations.h"
#include "so_locomotion20.h"
}
#ifdef _WIN32
#define API extern "C" __declspec(dllexport)
#else
#define API extern "C" __attribute__((visibility("default")))
#endif
API int ring_hrv(const int32_t* green,const int32_t* acc,int n,double* out,int capacity) {
 if(n<1||n>6000)return -1;ring_health::Hrv h;int written=0;
 for(int i=0;i<n;i++)if(h.process(ring_health::Hrv::encode(green[i]),{acc[i*3],acc[i*3+1],acc[i*3+2]})&&h.output_values[4]>=50)
  for(int j=0;j<h.output_values[5]&&j<4;j++){if(h.beat_samples[j]<0||h.output_values[j]<=0)continue;if(written+3>capacity)return -2;out[written++]=h.beat_samples[j]*10;out[written++]=h.output_values[j];out[written++]=h.output_values[4];}
 return written;
}
API int ring_hrv_reference(const int32_t* raw,const int32_t* acc,int n,int32_t* out){
 if(n<1||n>12000)return -1;ring_health::Hrv h;
 for(int i=0;i<n;i++){out[i*10]=h.process(raw[i],{acc[i*3],acc[i*3+1],acc[i*3+2]});for(int k=0;k<9;k++)out[i*10+k+1]=h.output_values[k];}return n*10;
}
API int ring_activity(const int16_t* a,int n,float* out){
 if(n!=1000)return -1;std::vector<float> magnitude(1000);std::vector<double> scratch(1295);
 for(int i=0;i<1000;i++){double x=a[3*i],y=a[3*i+1],z=a[3*i+2];magnitude[i]=std::sqrt(x*x+y*y+z*z)/2048*9.80665;}
 so_locomotion20_features(magnitude.data(),out,scratch.data());out[13]=so_locomotion20_count(magnitude.data());return 14;
}
API int ring_motion(const int16_t* a,int n,float* out){
 if(n!=1500)return -1;so_workspace w{};so_motion(reinterpret_cast<const int16_t(*)[3]>(a),n,(n-1)*20,out,&w);
 int moving=0;double sum=0,square=0;
 for(int sec=0;sec<30;sec++){double sums[3]={},squares=0;for(int i=0;i<50;i++){double norm=0;for(int k=0;k<3;k++){double v=a[3*(sec*50+i)+k];sums[k]+=v;squares+=v*v;norm+=v*v;}double r=std::sqrt(norm)/2048;sum+=r;square+=r*r;}double energy=50*squares;for(double v:sums)energy-=v*v;if(energy*625>1048576.0*50*50)moving++;}
 out[6]=moving;out[7]=std::sqrt(std::max(0.0,square/n-(sum/n)*(sum/n)));return 8;
}
API int ring_ppg(const int32_t* raw,int n,float motion,float* out){
 if(n<800||n>3000)return -1;std::vector<int32_t> decimated;
 for(int i=0;i+3<n;i+=4){int64_t sum=0;for(int k=0;k<4;k++)sum+=raw[i+k];decimated.push_back(int32_t(sum/4));}
 so_workspace w{};so_burst burst{};so_ppg(decimated.data(),decimated.size(),(decimated.size()-1)*40,motion,&burst,&w);std::copy(burst.stats,burst.stats+18,out);return 18;
}
API int ring_motion_lowrate(const int16_t* a,int n,int span,float* out){
 if(n<2||n>SO_ACC_MAX||span<24000)return -1;so_workspace w{};std::fill(out,out+8,0);
 if(so_motion(reinterpret_cast<const int16_t(*)[3]>(a),n,span,out,&w))return -1;
 double sum=0,square=0;for(int i=0;i<n;i++){double x=a[3*i],y=a[3*i+1],z=a[3*i+2];double r=std::sqrt(x*x+y*y+z*z)/2048;sum+=r;square+=r*r;}
 out[7]=std::sqrt(std::max(0.0,square/n-(sum/n)*(sum/n)));return 8;
}
API int ring_ppg_lowrate(const int32_t* raw,const int64_t* times,int n,float sd,double* out){
 if(n<100||n>SO_PPG_MAX)return -1;float stats[18];unsigned written=0;
 if(so_ppg_lowrate(raw,times,n,sd,stats,out+18,&written))return -1;for(unsigned i=0;i<18;i++)out[i]=stats[i];return 18+written;
}

// Same rounded DF-II cascade as SDK 1.15.1 oura_biquad_cascade.
API int ring_biquad(const float* sos, int sections, const float* input, int count, float* output) {
    if (sections < 0 || sections > 1000 || count < 0) return -1;
    std::vector<float> state(sections * 2, 0.0f);
    for (int i=0;i<count;i++) {
        float x=input[i];
        for (int j=0;j<sections;j++) {
            const float* b=sos+j*6;
            const double v=x;
            x=(float)std::fma(v,(double)b[0],(double)state[j*2]);
            const float a1=(float)(-(double)b[4]*(double)x);
            const float a2=(float)(-(double)b[5]*(double)x);
            state[j*2]=(float)std::fma(v,(double)b[1],(double)a1)+state[j*2+1];
            state[j*2+1]=(float)std::fma(v,(double)b[2],(double)a2);
        }
        output[i]=x;
    }
    return count;
}
