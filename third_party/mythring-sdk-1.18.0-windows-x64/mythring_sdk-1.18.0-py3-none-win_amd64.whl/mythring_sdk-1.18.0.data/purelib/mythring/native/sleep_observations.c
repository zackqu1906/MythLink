#include "sleep_observations.h"
#include "so_ibi_quality.h"
#include <math.h>
#include <complex.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

#define PI 3.14159265358979323846
static int compare(const void *a,const void *b) {
    double x=*(const double *)a,y=*(const double *)b;
    return (x>y)-(x<y);
}
static double quantile(const double *x,unsigned n,double q) {
    double z=(n-1)*q; unsigned i=(unsigned)z;
    return x[i]+(x[i+(i+1<n)]-x[i])*(z-i);
}
static double median(double *x,unsigned n) {
    if (!n) return NAN;
    qsort(x,n,sizeof(*x),compare);return quantile(x,n,.5);
}
static void statistics(double *x,unsigned n,float *out) {
    out[0]=out[1]=out[2]=NAN;
    if (!n) return;
    qsort(x,n,sizeof(*x),compare);
    out[0]=(float)(quantile(x,n,.75)-quantile(x,n,.25));out[1]=(float)x[n-1];
    double lo=n*.1,hi=n*.9,total=0;
    for(unsigned i=0;i<n;i++)total+=x[i]*fmax(0,fmin(i+1,hi)-fmax(i,lo));
    out[2]=(float)(total/(hi-lo));
}
int so_motion(const int16_t (*xyz)[3],unsigned n,uint32_t span,float out[6],struct so_workspace *w) {
    for(unsigned k=0;k<6;k++)out[k]=NAN;
    if(!xyz || !w || n<2 || n>SO_ACC_MAX || span<1000)return -1;
    double fs=1000.0*(n-1)/span;
    unsigned size=(unsigned)nearbyint(fs*5);
    if(size<1 || size>SO_PPG_MAX)return -1;
    double mad[6],angles[6],changes[5];unsigned bins[6]={0},nm=0,nc=0,used[6];
    double sum[6]={0},sum_angle[6]={0};
    for(unsigned i=0;i<n;i++) {
        unsigned b=(unsigned)((double)i*span/(n-1)/5000);
        if(b>=6)continue;
        double r=sqrt((double)xyz[i][0]*xyz[i][0]+(double)xyz[i][1]*xyz[i][1]+(double)xyz[i][2]*xyz[i][2])/2048;
        sum[b]+=r;bins[b]++;
        double sm[3];
        for(unsigned axis=0;axis<3;axis++) {
            for(unsigned j=0;j<size;j++) {
                int k=(int)i+(int)j-(int)(size/2);
                if(k<0)k=0;if(k>=(int)n)k=(int)n-1;
                w->motion_scratch[j]=xyz[k][axis];
            }
            sm[axis]=median(w->motion_scratch,size);
        }
        sum_angle[b]+=atan2(sm[2],hypot(sm[0],sm[1]))*180/PI;
    }
    double dev[6]={0};
    for(unsigned i=0;i<n;i++) {
        unsigned b=(unsigned)((double)i*span/(n-1)/5000);if(b>=6)continue;
        double r=sqrt((double)xyz[i][0]*xyz[i][0]+(double)xyz[i][1]*xyz[i][1]+(double)xyz[i][2]*xyz[i][2])/2048;
        dev[b]+=fabs(r-sum[b]/bins[b]);
    }
    for(unsigned b=0;b<6;b++)if(bins[b]>=.8*fs*5) {
        mad[nm]=dev[b]/bins[b];angles[nm]=sum_angle[b]/bins[b];used[nm++]=b;
    }
    for(unsigned i=1;i<nm;i++)if(used[i]==used[i-1]+1)changes[nc++]=fabs(angles[i]-angles[i-1]);
    statistics(mad,nm,out);statistics(changes,nc,out+3);return 0;
}

/* 25 Hz, third-order Butterworth bandpass .5..4 Hz, SciPy SOS order.
 * Odd reflection (21 samples) and steady-state initial conditions reproduce
 * sosfiltfilt. No filtering or adjacent interval crosses a powered-off gap. */
static const double sos[3][5]={
 {.041876828234771755,.08375365646954351,.041876828234771755,-.842898146053723,.49397710799123395},
 {1,0,-1,-1.2690874792376394,.3600221530957565},
 {1,-2,1,-1.882140396438565,.8983732290144412}};
static const double zi[3][2]={{.21539966621777665,-.08521187044902086},{-.2572764944525486,-.25727649445254835},{0,0}};
/* Bilinear transform of the third-order Butterworth prototype, with the
 * same pole pairing/order as SciPy zpk2sos. Only the observed sample span
 * determines fs; samples are neither decimated nor interpolated. */
static void rate_sos(double fs,double out[3][5],double state[3][2]) {
    double low=4*tan(PI*.5/fs),high=4*tan(PI*fmin(4,.4*fs)/fs);
    double bw=high-low,wo=sqrt(low*high);
    double complex proto[3]={-.5+I*sqrt(3)/2,-1,-.5-I*sqrt(3)/2},poles[6];
    double complex product=1;
    for(unsigned i=0;i<3;i++){
        double complex a=bw*proto[i]/2,b=csqrt(a*a-wo*wo);
        double complex pa[2]={a+b,a-b};
        for(unsigned j=0;j<2;j++){product*=4-pa[j];poles[2*i+j]=(4+pa[j])/(4-pa[j]);}
    }
    double complex pairs[2];double realp[2];unsigned nc=0,nr=0;
    for(unsigned i=0;i<6;i++){if(cimag(poles[i])>1e-10)pairs[nc++]=poles[i];else if(fabs(cimag(poles[i]))<=1e-10)realp[nr++]=creal(poles[i]);}
    if(cabs(pairs[0])>cabs(pairs[1])){double complex t=pairs[0];pairs[0]=pairs[1];pairs[1]=t;}
    double gain=creal(64*bw*bw*bw/product),scale=1;
    for(unsigned k=0;k<3;k++){
        double *c=out[k];double g=k==0?gain:1;
        c[0]=g;c[1]=k==0?2*g:k==1?0:-2*g;c[2]=k==1?-g:g;
        c[3]=k==1?-(realp[0]+realp[1]):-2*creal(pairs[k==0?0:1]);
        c[4]=k==1?realp[0]*realp[1]:pow(cabs(pairs[k==0?0:1]),2);
        double dc=(c[0]+c[1]+c[2])/(1+c[3]+c[4]);
        state[k][0]=(dc-c[0])*scale;state[k][1]=(c[2]-c[4]*dc)*scale;scale*=dc;
    }
}
static void filter(double *y,unsigned n,bool reverse,const double coeff[3][5],const double initial_state[3][2]) {
    double initial=y[reverse?n-1:0],state[3][2];
    for(unsigned s=0;s<3;s++)for(unsigned j=0;j<2;j++)state[s][j]=initial*initial_state[s][j];
    for(unsigned i=0;i<n;i++) {
        unsigned k=reverse?n-1-i:i;double x=y[k];
        for(unsigned s=0;s<3;s++) {
            const double *c=coeff[s];double v=c[0]*x+state[s][0];
            state[s][0]=c[1]*x-c[3]*v+state[s][1];state[s][1]=c[2]*x-c[4]*v;x=v;
        }
        y[k]=x;
    }
}
static double autocorr(const double *y,unsigned n,unsigned lag,double mean,double energy) {
    double sum=0;for(unsigned i=lag;i<n;i++)sum+=(y[i]-mean)*(y[i-lag]-mean);
    return energy>0?sum/energy:0;
}
static int ppg_core(const int32_t *raw,unsigned n,uint32_t span,float sd,struct so_burst *o,struct so_workspace *w,bool local,const int64_t *times) {
    memset(o,0,sizeof(*o));for(unsigned i=0;i<18;i++)o->stats[i]=NAN;
    if(!raw || !w || n<(times?100U:local?200U:600U) || n>SO_PPG_MAX || !span)return -1;
    double fs=1000.0*(n-1)/span;
    /* This revision deliberately refuses a rate it has not been validated for. */
    if(times ? (fs<10 || fs>15) : fabs(fs-25)>.01)return -2;
    double coeff[3][5],initial_state[3][2];
    if(times)rate_sos(fs,coeff,initial_state);else{memcpy(coeff,sos,sizeof(coeff));memcpy(initial_state,zi,sizeof(initial_state));}
    double *z=w->filtered,*y=z+21;
    for(unsigned i=0;i<21;i++)z[i]=2.0*raw[0]-raw[21-i];
    for(unsigned i=0;i<n;i++)y[i]=raw[i];
    for(unsigned i=0;i<21;i++)y[n+i]=2.0*raw[n-1]-raw[n-2-i];
    filter(z,n+42,false,coeff,initial_state);filter(z,n+42,true,coeff,initial_state);
    double mean=0,energy=0,m3=0,m4=0,rawmean=0;
    for(unsigned i=0;i<n;i++){mean+=y[i];rawmean+=raw[i];}mean/=n;rawmean/=n;
    for(unsigned i=0;i<n;i++){double v=y[i]-mean;energy+=v*v;m3+=v*v*v;m4+=v*v*v*v;}
    double std=sqrt(energy/n),period=-INFINITY;unsigned lag=(unsigned)nearbyint(fs);
    unsigned lo=(unsigned)ceil(fs*.35),hi=(unsigned)floor(fs*1.8);
    /* Find peaks on the WHOLE autocorrelation, then restrict the lag range. */
    for(unsigned j=lo;j<=hi;j++) {
        double v=autocorr(y,n,j,mean,energy);
        if(v>autocorr(y,n,j-1,mean,energy) && v>autocorr(y,n,j+1,mean,energy) && v>period){lag=j;period=v;}
    }
    if(!isfinite(period))period=autocorr(y,n,lag,mean,energy);
    /* Day/spot HR only: prefer a strongly supported fundamental over a
     * slightly stronger two-beat repeat. Frozen sleep features stay unchanged. */
    if(local && isfinite(period))for(unsigned j=lo;j<lag;j++){
        double v=autocorr(y,n,j,mean,energy);
        if(v>=.80*period && v>=.40 && v>autocorr(y,n,j-1,mean,energy) && v>autocorr(y,n,j+1,mean,energy)){
            lag=j;period=v;break;
        }
    }
    unsigned np=0;
    for(unsigned i=1;i+1<n;i++)if(y[i]>y[i-1]) {
        unsigned end=i;while(end+1<n && y[end+1]==y[i])end++;
        if(end+1<n && y[end+1]<y[i]) {
            if(np==SO_PEAK_MAX)return -3;
            w->peaks[np++]=(uint16_t)((i+end)/2);
        }i=end;
    }
    /* SciPy removes neighbours by peak height BEFORE prominence filtering. */
    unsigned distance=(unsigned)(lag*.65);if(distance<1)distance=1;
    for(unsigned j=0;j<np;j++)w->prominence[j]=0;
    for(unsigned k=0;k<np;k++) {
        int best=-1;
        for(unsigned j=0;j<np;j++)if(w->prominence[j]==0 && (best<0 || y[w->peaks[j]]>=y[w->peaks[best]]))best=(int)j;
        if(best<0)break;w->prominence[best]=1;
        for(unsigned j=0;j<np;j++)if(j!=(unsigned)best && abs((int)w->peaks[j]-(int)w->peaks[best])<(int)distance && w->prominence[j]==0)w->prominence[j]=-1;
    }
    unsigned kept=0;
    for(unsigned j=0;j<np;j++)if(w->prominence[j]>0) {
        unsigned p=w->peaks[j];double left=y[p],right=y[p];
        for(int i=(int)p;i>=0 && y[i]<=y[p];i--)left=fmin(left,y[i]);
        for(unsigned i=p;i<n && y[i]<=y[p];i++)right=fmin(right,y[i]);
        double prominence=y[p]-fmax(left,right);
        if(prominence>=fmax(1,std*.35)){w->peaks[kept]=(uint16_t)p;w->prominence[kept++]=prominence;}
    }
    double last=0,intervals[SO_BEAT_MAX];
    for(unsigned j=0;j<kept;j++) {
        unsigned p=w->peaks[j];double den=y[p-1]-2*y[p]+y[p+1];
        double delta=fabs(den)>1e-12?fmax(-.5,fmin(.5,.5*(y[p-1]-y[p+1])/den)):0;
        double t=times?(double)times[p]+delta*1000/fs:(p+delta)*1000/fs;
        /* Round the timestamp in double precision before narrowing. Narrowing
         * first can move a half-ms tie by 1 ms; IBI retains sub-sample precision. */
        if(j){o->beats[j-1].offset_ms=(uint16_t)(times?nearbyint(t)-times[0]:nearbyint(t));o->beats[j-1].ibi_ms=(float)(t-last);intervals[j-1]=t-last;w->scratch[j-1]=times?intervals[j-1]:o->beats[j-1].ibi_ms;}last=t;
    }
    o->count=kept?kept-1:0;double med=median(w->scratch,o->count);
    unsigned good=0,valid=0,pairs=0;double sum=0,sum2=0,diff2=0,sx=0,sy=0,sxx=0,sxy=0;
    bool previous=false;
    for(unsigned j=0;j<o->count;j++) {
        double ibi=o->beats[j].ibi_ms;bool plausible=ibi>=350 && ibi<=1800 && ibi>=med*.65 && ibi<=med*1.35;
        double precise=times?intervals[j]:ibi;
        bool valid_range=precise>=350 && precise<=1800 && precise>=med*.65 && precise<=med*1.35;
        o->beats[j].valid=valid_range && period>=.55 && sd<.03 && o->count>=12 && med>=350 && med<=1800 && j>0 && j+1<o->count;
        valid+=o->beats[j].valid;
        if(plausible) {
            w->scratch[good++]=ibi;sum+=ibi;sum2+=ibi*ibi;
            double x=o->beats[j].offset_ms/1000.0,yhr=60000/ibi;sx+=x;sy+=yhr;sxx+=x*x;sxy+=x*yhr;
            if(previous){double d=ibi-o->beats[j-1].ibi_ms;diff2+=d*d;pairs++;}
        }previous=plausible;
    }
    float values[SO_BEAT_MAX];uint8_t screened[SO_BEAT_MAX];
    for(unsigned j=0;j<o->count;j++){values[j]=o->beats[j].ibi_ms;screened[j]=o->beats[j].valid;}
    o->rejected=times?0:so_ibi_screen(values,screened,o->count);
    if(o->rejected){valid=0;pairs=0;diff2=0;previous=false;
    for(unsigned j=0;j<o->count;j++){
        o->beats[j].valid=screened[j];valid+=screened[j];
        if(screened[j]&&previous){double delta=values[j]-values[j-1];diff2+=delta*delta;pairs++;}
        previous=screened[j];
    }}
    float *v=o->stats;
    v[0]=span/1000.f;v[1]=(float)fs;v[2]=sd;v[3]=(float)period;
    /* Periodogram boxcar, detrend constant; common density factor cancels. */
    double total=0,band=0;
    for(unsigned k=1;!local && k<=n/2;k++) {
        double f=k*fs/n;if(f<.1 || f>fmin(10,fs/2))continue;
        double step=2*PI*k/n,cs=cos(step),sn=sin(step),c=1,s=0,re=0,im=0;
        for(unsigned j=0;j<n;j++){double x=raw[j]-rawmean;re+=x*c;im-=x*s;double next=c*cs-s*sn;s=s*cs+c*sn;c=next;}
        double power=(re*re+im*im)*(2*k==n?1:2);total+=power;if(f>=.5 && f<=fmin(4,.4*fs))band+=power;
    }
    v[4]=total>0?(float)(band/total):NAN;
    v[6]=(float)o->count;v[7]=(float)valid;v[8]=o->count?(float)valid/o->count:0;
    if(good){v[9]=(float)median(w->scratch,good);if(good>1){double avg=sum/good;v[10]=(float)sqrt(fmax(0,sum2/good-avg*avg));v[11]=(float)(quantile(w->scratch,good,.75)-quantile(w->scratch,good,.25));}}
    if(pairs>=3)v[12]=(float)sqrt(diff2/pairs);
    if(good>=5 && good*sxx>sx*sx)v[13]=(float)((good*sxy-sx*sy)/(good*sxx-sx*sx));
    if(std>0){double variance=std*std;v[14]=(float)(m3/n/(variance*std));v[15]=(float)(m4/n/(variance*variance)-3);}
    if(kept>2){double ps=0,ps2=0;for(unsigned j=0;j<kept;j++){double a=y[w->peaks[j]];ps+=a;ps2+=a*a;}double avg=ps/kept;v[16]=(float)(sqrt(fmax(0,ps2/kept-avg*avg))/fmax(fabs(avg),1));}
    if(kept){for(unsigned j=0;j<kept;j++)w->scratch[j]=w->prominence[j];v[17]=(float)(median(w->scratch,kept)/fmax(std,1));}
    /* Filtered waveform is dead here; reuse it for the raw median. */
    for(unsigned i=0;i<n;i++)w->filtered[i]=raw[i];
    v[5]=(float)(std/fmax(fabs(median(w->filtered,n)),1));return 0;
}
int so_ppg(const int32_t *raw,unsigned n,uint32_t span,float sd,struct so_burst *o,struct so_workspace *w) {
    return ppg_core(raw,n,span,sd,o,w,false,NULL);
}
static float local_motion(const int16_t (*acc)[3],unsigned n,uint32_t span,int32_t from,unsigned duration) {
    if(n<2 || !span || from<0 || (uint32_t)from+duration>span+21U)return NAN;
    double sum=0,sum2=0;unsigned used=0;
    for(unsigned i=0;i<n;i++) {
        uint32_t t=(uint64_t)i*span/(n-1);
        if(t<(uint32_t)from || t>=(uint32_t)from+duration)continue;
        double r=sqrt((double)acc[i][0]*acc[i][0]+(double)acc[i][1]*acc[i][1]+(double)acc[i][2]*acc[i][2])/2048;
        sum+=r;sum2+=r*r;used++;
    }
    if(used<duration*45U/1000U)return NAN;
    double avg=sum/used;return (float)sqrt(fmax(0,sum2/used-avg*avg));
}
static struct so_vital local_value(struct so_burst *b,struct so_workspace *w,bool hrv,float sd,unsigned from,unsigned n) {
    struct so_vital v={.value=NAN,.periodicity=b->stats[3],.motion_sd=sd,
                      .start_ms=from*40,.duration_ms=n*40,.samples=n};
    if(!isfinite(v.periodicity)||v.periodicity<(hrv?.55f:.40f))v.reason|=SO_VITAL_PERIOD;
    float med=b->stats[9],last=0,offset=0;bool previous=false;double ss=0,sum=0,sum2=0;
    for(unsigned i=0;i<b->count;i++) {
        struct so_beat *beat=&b->beats[i];float x=beat->ibi_ms;
        bool good=i>0 && i+1<b->count && isfinite(x) && x>=350 && x<=1800 && x>=med*.65f && x<=med*1.35f && (!hrv||beat->valid);
        if(good){
            unsigned j=v.intervals++;while(j && w->scratch[j-1]>x){w->scratch[j]=w->scratch[j-1];j--;}w->scratch[j]=x;
            sum+=x;sum2+=(double)x*x;
            float dt=beat->offset_ms-offset;
            if(previous && dt>0 && dt<=2000 && fabsf(dt-x)<=150){double delta=x-last;ss+=delta*delta;v.pairs++;}
        }
        previous=good;last=x;offset=beat->offset_ms;
    }
    if(v.intervals<(hrv?12:5) || (hrv && v.pairs<10))v.reason|=SO_VITAL_BEATS;
    if(hrv&&b->rejected*5U>v.intervals+b->rejected)v.reason|=SO_VITAL_INTERVALS;
    if(v.intervals){
        double avg=sum/v.intervals,cv=sqrt(fmax(0,sum2/v.intervals-avg*avg))/avg;
        if(cv>(hrv?.20:.25) || v.intervals*4U<(b->count>2?b->count-2:0)*3U)v.reason|=SO_VITAL_INTERVALS;
        /* Reject sparse surviving intervals; apparent stability after dropping
         * most of a recording is not evidence of an accurate pulse rate. */
        if(!hrv && sum<n*40*.65)v.reason|=SO_VITAL_INTERVALS;
    }
    if(!v.reason)v.value=hrv?(float)sqrt(ss/v.pairs):(float)(60000/((w->scratch[(v.intervals-1)/2]+w->scratch[v.intervals/2])/2));
    return v;
}
struct so_vital so_spot_hr(const int32_t *raw,unsigned n,float sd,struct so_burst *burst,struct so_workspace *work){
    struct so_vital v={.value=NAN,.reason=SO_VITAL_SAMPLES};
    if(n<225||n>250)return v;
    if(!isfinite(sd)||sd>=.03f){v.reason=SO_VITAL_MOTION;return v;}
    if(ppg_core(raw,n,(n-1)*40,sd,burst,work,true,NULL))return v;
    v=local_value(burst,work,false,sd,0,n);
    if(v.periodicity<.55f){v.reason|=SO_VITAL_PERIOD;v.value=NAN;}
    return v;
}
void so_day_select(const int32_t *raw,unsigned n,const int16_t (*acc)[3],unsigned na,uint32_t acc_span,int32_t first,
                   struct so_day_vitals *out,struct so_burst *burst,struct so_workspace *work) {
    *out=(struct so_day_vitals){.hr={.value=NAN,.periodicity=NAN,.motion_sd=NAN},.hrv={.value=NAN,.periodicity=NAN,.motion_sd=NAN}};
    if(!raw || n<200 || n>SO_PPG_MAX){out->hr.reason=out->hrv.reason=SO_VITAL_SAMPLES;return;}
    if(!acc || na<2 || na>SO_ACC_MAX || !acc_span){out->hr.reason=out->hrv.reason=SO_VITAL_ACC;return;}
    /* Longest eligible duration first; within it choose maximum periodicity.
     * Fixed 2-second grid, bounded work, no stitching across movement or OFF. */
    const unsigned lengths[2][3]={{500,300,200},{600,500,0}};
    for(unsigned metric=0;metric<2;metric++) {
        bool hrv=metric!=0;struct so_vital *best=hrv?&out->hrv:&out->hr;
        uint16_t rejected=0;
        for(unsigned scale=0;scale<3 && !isfinite(best->value);scale++) {
            unsigned len=lengths[metric][scale];if(!len)continue;
            if(len>n){rejected|=SO_VITAL_SAMPLES;continue;}
            for(unsigned from=0;from+len<=n;from+=50) {
                float sd=local_motion(acc,na,acc_span,first+(int32_t)(from*40),len*40);
                if(!isfinite(sd)){rejected|=SO_VITAL_ACC;continue;}
                if(sd>=(hrv?.03f:.08f)){rejected|=SO_VITAL_MOTION;continue;}
                if(ppg_core(raw+from,len,(len-1)*40,sd,burst,work,true,NULL)){rejected|=SO_VITAL_SAMPLES;continue;}
                struct so_vital candidate=local_value(burst,work,hrv,sd,from,len);
                rejected|=candidate.reason;
                if(!candidate.reason && (!isfinite(best->value)||candidate.periodicity>best->periodicity))*best=candidate;
            }
        }
        if(!isfinite(best->value))best->reason=rejected?rejected:SO_VITAL_BEATS;
    }
}

int so_ppg_lowrate(const int32_t *raw,const int64_t *times,unsigned n,float sd,float stats[18],double *beats,unsigned *written) {
    if(!times || !raw || !stats || !beats || !written || n<100 || n>SO_PPG_MAX)return -1;
    int64_t span=times[n-1]-times[0];if(span<=0 || span>31000)return -1;
    for(unsigned i=1;i<n;i++)if(times[i]<=times[i-1] || times[i]-times[i-1]>120)return -1;
    struct so_workspace work;struct so_burst burst;
    int result=ppg_core(raw,n,(uint32_t)span,sd,&burst,&work,false,times);
    if(result)return result;
    memcpy(stats,burst.stats,18*sizeof(float));*written=burst.count*3;
    for(unsigned i=0;i<burst.count;i++){beats[3*i]=(double)times[0]+burst.beats[i].offset_ms;beats[3*i+1]=burst.beats[i].ibi_ms;beats[3*i+2]=burst.beats[i].valid;}
    return 0;
}
