#pragma once
#include <array>
#include <cstdint>
#include <deque>
#include <vector>
namespace ring_health {
struct Pulse {
    float position=0,rise=0,fall=0,rise_time=0,fall_time=0,interval=0;
    int kind=2,ignored=0;
    float amplitude() const {return rise+fall;}
    float width() const {return rise_time+fall_time;}
};
class Hrv {
public:
    std::array<int32_t,9> previous{}, output_values{};
    std::array<double,4> beat_samples{{-1,-1,-1,-1}};
    std::deque<float> filtered;
    std::vector<Pulse> pulses;
    uint32_t process(int32_t green,const std::array<int32_t,3>& acceleration);
    static int32_t encode(int32_t sample);
private:
    std::deque<float> dc,ac,amplitudes,widths,intervals,acc,confidences;
    std::vector<float> acc_batch;
    int count=0,direction=2,bad_count=0,average_count=0,last_update=0,seconds=0,output_count=0,last_interval=0;
    bool have_valley=false,locked=false,artifact=false;
    float valley_position=0,valley_value=0,peak_position=0,peak_value=0,rise=0,fall=0,rise_time=0,fall_time=0;
    float average_amplitude=0,average_width=1,average_interval=1;
    float cv=0,measured_amplitude=0,measured_width=0,measured_interval=0;
    void filter(int32_t value);
    bool detect(int index,Pulse& pulse);
    void append(Pulse pulse);
    void update_average(float amplitude,float width,float interval);
    void measure(const Pulse& pulse,float delta);
    void replace_last(Pulse pulse);
    void redistribute(Pulse& a,Pulse& b);
    void track(Pulse c);
    uint32_t output(bool bad_sample);
};
}
