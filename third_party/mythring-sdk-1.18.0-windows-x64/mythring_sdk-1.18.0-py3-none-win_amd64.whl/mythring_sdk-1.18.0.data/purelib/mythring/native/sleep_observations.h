#ifndef SLEEP_OBSERVATIONS_H
#define SLEEP_OBSERVATIONS_H
#include <stdbool.h>
#include <stdint.h>

/* Protocol v1, preprocessing candidate v1. No raw waveform leaves this API.
 * This is NOT the classifier and is not yet qualified against recorded nights. */
#define SO_COMMAND 0x39U
#define SO_MODE 3U
#define SO_VERSION 1U
#define SO_PPG_MAX 768U
#define SO_ACC_MAX 1536U
#define SO_BEAT_MAX 192U
#define SO_PEAK_MAX (SO_PPG_MAX/2U)
#define SO_PERIOD_MS 150000U
#define SO_ON_MS 30000U
/* Local timestamps are already rounded to integer ms, always below 30720. */
struct so_beat { float ibi_ms; uint16_t offset_ms; uint8_t valid; };
struct so_burst { float stats[18]; uint16_t count,rejected; struct so_beat beats[SO_BEAT_MAX]; };
struct so_workspace {
    union {
        struct {double filtered[SO_PPG_MAX+42];double scratch[SO_PEAK_MAX];};
        double motion_scratch[SO_PPG_MAX];
        double locomotion[1295]; /* Sequential reuse, never concurrent with PPG. */
    };
    float prominence[SO_PEAK_MAX];
    uint16_t peaks[SO_PEAK_MAX];
};
static inline bool so_duty_on(uint32_t elapsed_ms) {
    return elapsed_ms % SO_PERIOD_MS < SO_ON_MS;
}
int so_motion(const int16_t (*xyz)[3], unsigned count, uint32_t span_ms,
              float out[6], struct so_workspace *work);
int so_ppg(const int32_t *raw, unsigned count, uint32_t span_ms, float acc_sd_g,
           struct so_burst *out, struct so_workspace *work);
int so_ppg_lowrate(const int32_t *raw,const int64_t *times,unsigned count,float motion_sd,
    float stats[18],double *beats,unsigned *written);
enum so_vital_reason {
    SO_VITAL_SAMPLES=1, SO_VITAL_TIME=2, SO_VITAL_ACC=4,
    SO_VITAL_MOTION=8, SO_VITAL_PERIOD=16, SO_VITAL_BEATS=32, SO_VITAL_INTERVALS=64
};
struct so_vital {
    float value,periodicity,motion_sd;
    uint16_t intervals,pairs,start_ms,duration_ms,reason,samples;
};
struct so_day_vitals { struct so_vital hr,hrv; };
struct so_vital so_spot_hr(const int32_t *raw,unsigned count,float sd,struct so_burst *burst,struct so_workspace *work);
/* Experimental day-only quality policy. No classifier observations are changed.
 * first_ppg_ms is relative to the first ACC sample, not callback arrival time.
 * Caller excludes timestamp gaps; work/burst are reused after staging emission. */
void so_day_select(const int32_t *raw,unsigned count,const int16_t (*acc)[3],
                   unsigned acc_count,uint32_t acc_span_ms,int32_t first_ppg_ms,
                   struct so_day_vitals *out,struct so_burst *burst,struct so_workspace *work);
#endif
