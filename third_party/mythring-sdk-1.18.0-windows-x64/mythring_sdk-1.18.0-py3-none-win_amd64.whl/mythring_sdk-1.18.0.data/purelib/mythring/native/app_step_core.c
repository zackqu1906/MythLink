#include "app_step_core.h"

#include <math.h>
#include <stddef.h>
#include <string.h>

/* Seven-tap half-band low-pass, Q15. The coefficients sum to 32768 exactly.
 * Filtering before 2:1 decimation prevents 25-50 Hz energy folding into the
 * model's 0-25 Hz input band. */
static const int16_t step_fir_q15[APP_STEP_FIR_TAPS] = {
    -1495, 0, 9687, 16384, 9687, 0, -1495,
};

static int16_t step_saturate_i16(int64_t value) {
  if (value > INT16_MAX) {
    return INT16_MAX;
  }
  if (value < INT16_MIN) {
    return INT16_MIN;
  }
  return (int16_t)value;
}

void app_step_downsampler_init(struct app_step_downsampler *state) {
  if (state != NULL) {
    memset(state, 0, sizeof(*state));
  }
}

static int16_t step_fir_axis(const int16_t values[APP_STEP_FIR_TAPS],
                             uint8_t head) {
  int64_t sum = 0;

  for (uint8_t tap = 0U; tap < APP_STEP_FIR_TAPS; ++tap) {
    uint8_t index = (uint8_t)((head + APP_STEP_FIR_TAPS - tap) %
                              APP_STEP_FIR_TAPS);
    sum += (int32_t)values[index] * step_fir_q15[tap];
  }
  return step_saturate_i16((sum + (1 << 14)) >> 15);
}

bool app_step_downsampler_push(struct app_step_downsampler *state,
                               const struct app_step_sample *input,
                               struct app_step_sample *output) {
  uint32_t delta;
  uint32_t gaps;

  if ((state == NULL) || (input == NULL) || (output == NULL)) {
    return false;
  }
  if (state->have_time) {
    delta = input->uptime_ms - state->last_uptime_ms;
    if ((delta >= 17U) && (delta <= 23U)) {
      if ((state->input_hz != 0U) &&
          (state->input_hz != APP_STEP_OUTPUT_HZ)) {
        state->gap_count++;
      }
      state->input_hz = APP_STEP_OUTPUT_HZ;
      state->last_uptime_ms = input->uptime_ms;
      *output = *input;
      return true;
    }
    if ((delta >= 7U) && (delta <= 13U)) {
      if ((state->input_hz != 0U) &&
          (state->input_hz != APP_STEP_INPUT_HZ)) {
        gaps = state->gap_count + 1U;
        app_step_downsampler_init(state);
        state->gap_count = gaps;
      }
      state->input_hz = APP_STEP_INPUT_HZ;
    } else {
      uint32_t estimated_hz = delta == 0U ? UINT8_MAX :
          (1000U + delta / 2U) / delta;

      if (estimated_hz > UINT8_MAX) {
        estimated_hz = UINT8_MAX;
      }
      gaps = state->gap_count;
      if (state->input_hz != (uint8_t)estimated_hz) {
        gaps++;
      }
      app_step_downsampler_init(state);
      state->gap_count = gaps;
      state->input_hz = (uint8_t)estimated_hz;
    }
  }
  state->last_uptime_ms = input->uptime_ms;
  state->have_time = true;
  state->head = state->count == 0U
                    ? 0U
                    : (uint8_t)((state->head + 1U) % APP_STEP_FIR_TAPS);
  state->x[state->head] = input->x;
  state->y[state->head] = input->y;
  state->z[state->head] = input->z;
  if (state->count < APP_STEP_FIR_TAPS) {
    state->count++;
    if (state->count < APP_STEP_FIR_TAPS) {
      return false;
    }
    state->phase = 0U;
  } else {
    state->phase ^= 1U;
    if (state->phase != 0U) {
      return false;
    }
  }

  output->uptime_ms = input->uptime_ms;
  output->x = step_fir_axis(state->x, state->head);
  output->y = step_fir_axis(state->y, state->head);
  output->z = step_fir_axis(state->z, state->head);
  return true;
}

void app_oxford_init(struct app_oxford_counter *counter) {
  if (counter != NULL) {
    memset(counter, 0, sizeof(*counter));
  }
}

static void step_shift_points(struct app_oxford_point *points, uint8_t count) {
  if (count > 1U) {
    memmove(points, &points[1], (count - 1U) * sizeof(points[0]));
  }
}

uint32_t app_oxford_push(struct app_oxford_counter *counter,
                         uint32_t uptime_ms, float magnitude_mps2) {
  const float motion_threshold = (500.0f / 2048.0f) * 9.80665f;
  struct app_oxford_point candidate;
  struct app_oxford_point gated;
  float minimum;
  float maximum;
  float score;
  float old_mean;

  if (counter == NULL) {
    return 0U;
  }
  if (counter->motion_count == APP_STEP_OXFORD_MOTION_POINTS) {
    step_shift_points(counter->motion, counter->motion_count);
    counter->motion_count--;
  }
  counter->motion[counter->motion_count++] =
      (struct app_oxford_point){uptime_ms, magnitude_mps2};
  if (counter->motion_count < APP_STEP_OXFORD_MOTION_POINTS) {
    return 0U;
  }

  minimum = counter->motion[0].value;
  maximum = minimum;
  for (uint8_t i = 1U; i < 12U; ++i) {
    minimum = fminf(minimum, counter->motion[i].value);
    maximum = fmaxf(maximum, counter->motion[i].value);
  }
  if ((maximum - minimum) <= motion_threshold) {
    return 0U;
  }

  gated = counter->motion[0];
  step_shift_points(counter->motion, counter->motion_count);
  counter->motion_count--;
  counter->scoring[counter->scoring_count++] = gated;
  if (counter->scoring_count < APP_STEP_OXFORD_SCORE_POINTS) {
    return 0U;
  }

  score = 10.0f * counter->scoring[5].value;
  for (uint8_t i = 0U; i < APP_STEP_OXFORD_SCORE_POINTS; ++i) {
    score -= counter->scoring[i].value;
  }
  score /= 9.0f;
  candidate = (struct app_oxford_point){counter->scoring[5].uptime_ms, score};
  step_shift_points(counter->scoring, counter->scoring_count);
  counter->scoring_count--;

  old_mean = counter->score_mean;
  counter->score_count++;
  if (counter->score_count == 1U) {
    counter->score_mean = score;
    counter->score_deviation = 0.0f;
  } else if (counter->score_count == 2U) {
    counter->score_mean = (counter->score_mean + score) / 2.0f;
    counter->score_deviation =
        sqrtf((score - counter->score_mean) * (score - counter->score_mean) +
              (old_mean - counter->score_mean) *
                  (old_mean - counter->score_mean)) /
        2.0f;
  } else {
    float part1 = counter->score_deviation * counter->score_deviation /
                  (float)(counter->score_count - 1U) *
                  (float)(counter->score_count - 2U);
    float part2 = (old_mean - counter->score_mean) *
                  (old_mean - counter->score_mean);
    float part3;

    counter->score_mean =
        (score + (float)(counter->score_count - 1U) * counter->score_mean) /
        (float)counter->score_count;
    part2 = (old_mean - counter->score_mean) *
            (old_mean - counter->score_mean);
    part3 = (score - counter->score_mean) * (score - counter->score_mean) /
            (float)counter->score_count;
    counter->score_deviation = sqrtf(fmaxf(0.0f, part1 + part2 + part3));
  }
  if ((counter->score_count <= 15U) ||
      ((score - counter->score_mean) <= counter->score_deviation / 6.0f)) {
    return 0U;
  }
  if (!counter->have_peak) {
    counter->last_peak = candidate;
    counter->have_peak = true;
    return 0U;
  }
  if ((uint32_t)(candidate.uptime_ms - counter->last_peak.uptime_ms) > 300U) {
    counter->last_peak = candidate;
    return 1U;
  }
  if (candidate.value > counter->last_peak.value) {
    counter->last_peak = candidate;
  }
  return 0U;
}
