#ifndef APP_ALGORITHM_APP_STEP_CORE_H_
#define APP_ALGORITHM_APP_STEP_CORE_H_

#include <stdbool.h>
#include <stdint.h>

#define APP_STEP_INPUT_HZ 100U
#define APP_STEP_OUTPUT_HZ 50U
#define APP_STEP_FIR_TAPS 7U
#define APP_STEP_OXFORD_MOTION_POINTS 15U
#define APP_STEP_OXFORD_SCORE_POINTS 10U

struct app_step_sample {
  uint32_t uptime_ms;
  int16_t x;
  int16_t y;
  int16_t z;
};

struct app_step_downsampler {
  int16_t x[APP_STEP_FIR_TAPS];
  int16_t y[APP_STEP_FIR_TAPS];
  int16_t z[APP_STEP_FIR_TAPS];
  uint32_t last_uptime_ms;
  uint32_t gap_count;
  uint8_t head;
  uint8_t count;
  uint8_t phase;
  uint8_t input_hz;
  bool have_time;
};

struct app_oxford_point {
  uint32_t uptime_ms;
  float value;
};

struct app_oxford_counter {
  struct app_oxford_point motion[APP_STEP_OXFORD_MOTION_POINTS];
  struct app_oxford_point scoring[APP_STEP_OXFORD_SCORE_POINTS];
  struct app_oxford_point last_peak;
  uint32_t score_count;
  float score_mean;
  float score_deviation;
  uint8_t motion_count;
  uint8_t scoring_count;
  bool have_peak;
};

void app_step_downsampler_init(struct app_step_downsampler *state);
bool app_step_downsampler_push(struct app_step_downsampler *state,
                               const struct app_step_sample *input,
                               struct app_step_sample *output);

void app_oxford_init(struct app_oxford_counter *counter);
uint32_t app_oxford_push(struct app_oxford_counter *counter,
                         uint32_t uptime_ms, float magnitude_mps2);

#endif
