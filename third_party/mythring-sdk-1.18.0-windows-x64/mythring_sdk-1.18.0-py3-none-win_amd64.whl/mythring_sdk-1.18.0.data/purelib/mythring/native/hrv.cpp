// Scalar port of health_algo/hrv.py. Disable contraction/fast-math: operation
// boundaries, float32 rounding and retained-state semantics are observable.
#include "hrv.h"
#include <algorithm>
#include <cmath>
#include <limits>
namespace ring_health {
static float add(float a,float b){return a+b;}
static float sub(float a,float b){return a-b;}
static float mul(float a,float b){return a*b;}
static float div(float a,float b){return a/b;}
static int rnd(float x){return int(double(x)+(x>0?0.5:-0.5));}
template<class T> static float mean(const T& a){float v=0;for(float x:a)v=add(v,x);return a.empty()?0:div(v,a.size());}
template<class T> static float sd(const T& a){if(a.size()<2)return 0;float m=mean(a),v=0;for(float x:a)v=add(v,mul(sub(x,m),sub(x,m)));return float(std::sqrt(double(div(v,a.size()-1))));}
template<class T> static float median(const T& a){std::vector<float> v(a.begin(),a.end());std::sort(v.begin(),v.end());size_t n=v.size();return n%2?v[n/2]:mul(add(v[n/2-1],v[n/2]),0.5f);}
static void push(std::deque<float>& a,float v,size_t max){a.push_back(v);if(a.size()>max)a.pop_front();}
static void merge(Pulse& a,const Pulse& b,bool later){
 if(later){a.rise=add(a.rise,std::max(0.f,sub(b.rise,a.fall)));a.fall=b.fall;a.rise_time=add(add(a.rise_time,a.fall_time),b.rise_time);a.fall_time=b.fall_time;a.interval=sub(add(a.interval,b.position),a.position);a.position=b.position;}
 else {a.fall=add(b.fall,std::max(0.f,sub(a.fall,b.rise)));a.fall_time=add(add(a.fall_time,b.rise_time),b.fall_time);}
}
static std::array<float,2> cubic(const std::deque<float>& values,bool maximum){
 static const float matrix[4][4]={{-.5f,1.5f,-1.5f,.5f},{1,-2.5f,2,-.5f},{-.5f,0,.5f,0},{0,1,0,0}};
 std::array<float,2> best{};
 for(int i=0;i<11;i++){float t=mul(i,.1f),t2=mul(t,t),p[]={mul(t2,t),t2,t,1},x=0,y=0;
  for(int j=0;j<4;j++){float w=0;for(int k=0;k<4;k++)w=add(w,mul(p[k],matrix[k][j]));x=add(x,mul(w,j+1));y=add(y,mul(w,values[j]));}
  if(!i||(maximum?y>best[1]:y<best[1]))best={x,y};
 }return best;
}
int32_t Hrv::encode(int32_t v){static const uint32_t keys[]={0x6b851eb7,0x4147ae13,0x28f5c28f,0x15c28f5b};uint32_t u=uint32_t(v);return int32_t((u&~1u)|(__builtin_popcount(((u&0xffffff)>>1)^keys[(u&7)>>1])&1));}
void Hrv::filter(int32_t value){
 static const float coefficients[]={
#include "hrv_coefficients.inc"
 };
 push(dc,float(value),151);if(dc.size()<151)return;
 push(ac,sub(dc[75],mean(dc)),65);float v=0;for(size_t i=0;i<ac.size();i++)v=add(v,mul(ac[ac.size()-1-i],coefficients[i]));push(filtered,v,4);
}
bool Hrv::detect(int index,Pulse& pulse){
 if(filtered.size()<4)return false;
 if(index%100==0){valley_position=sub(valley_position,100);peak_position=sub(peak_position,100);}
 float previous_value=filtered[2],current=filtered[3],position=float(300+index%100-1);
 if(direction==2){if(current!=previous_value)direction=current>previous_value;return false;}
 if(direction==1&&current<previous_value){direction=0;if(!have_valley)return false;peak_position=position;peak_value=previous_value;
  if(current<filtered[1]){auto a=cubic(filtered,true);peak_position=add(position,sub(a[0],3));peak_value=a[1];}
  rise=sub(peak_value,valley_value);rise_time=sub(peak_position,valley_position);
 }else if(direction==0&&current>previous_value){direction=1;valley_position=position;valley_value=previous_value;bool found=have_valley;
  if(found){if(current>filtered[1]){auto a=cubic(filtered,false);valley_position=add(position,sub(a[0],3));valley_value=a[1];}
   fall=sub(peak_value,valley_value);fall_time=sub(valley_position,peak_position);pulse={peak_position,rise,fall,rise_time,fall_time,add(rise_time,fall_time),2,0};peak_position=rise=fall=rise_time=fall_time=0;
  }have_valley=true;return found;
 }return false;
}
void Hrv::append(Pulse p){pulses.push_back(p);if(pulses.size()>20)pulses.erase(pulses.begin());}
void Hrv::replace_last(Pulse p){pulses.pop_back();append(p);}
void Hrv::update_average(float amplitude,float width,float interval){average_count=std::min(16,average_count+1);int n=average_count;average_amplitude=div(add(amplitude,mul(n-1,average_amplitude)),n);average_width=div(add(width,mul(n-1,average_width)),n);average_interval=div(add(interval,mul(n-1,average_interval)),n);last_update=seconds;}
void Hrv::measure(const Pulse& p,float delta){
 push(amplitudes,p.amplitude(),10);push(widths,p.width(),10);push(intervals,delta,10);
 if(amplitudes.size()==10){float m=median(amplitudes);std::vector<float> deviations,selected;for(float v:amplitudes)deviations.push_back(std::abs(sub(v,m)));float mad=mean(deviations);for(float v:amplitudes)if(std::abs(sub(v,m))<=double(mad)*1.4826*2)selected.push_back(v);measured_amplitude=mean(selected);cv=measured_amplitude?std::abs(mul(div(sd(selected),measured_amplitude),100)):200;measured_width=mean(widths);measured_interval=mean(intervals);}
 else cv=measured_amplitude=measured_width=measured_interval=0;
}
void Hrv::redistribute(Pulse& a,Pulse& b){float avg=average_interval,tolerance=mul(avg,.2f),summed=add(a.interval,b.interval);
 if(std::abs(sub(mul(summed,.5f),avg))<tolerance&&std::abs(sub(a.interval,avg))>=tolerance&&std::abs(sub(b.interval,avg))>=tolerance&&average_count>=16&&a.kind==1){a.interval=avg;b.interval=sub(summed,avg);pulses.pop_back();pulses.pop_back();append(a);}else pulses.pop_back();append(b);
}
void Hrv::track(Pulse c){
 if(pulses.size()<2){append(c);return;}Pulse a=pulses[pulses.size()-2],b=pulses.back();
 float aa=a.amplitude(),ab=b.amplitude(),acv=c.amplitude(),wa=a.width(),wb=b.width(),wc=c.width(),d1=sub(b.position,a.position),d2=sub(c.position,b.position);
 measure(c,d2);
 if(locked&&div(c.rise,b.rise)<.05f&&div(c.fall,b.fall)<.05f){c.ignored=1;b.kind=1;replace_last(b);append(c);return;}
 if(b.ignored&&div(b.rise,c.rise)<.05f&&div(b.fall,c.fall)<.05f){pulses.pop_back();c.interval=sub(c.position,a.position);c.kind=1;append(c);return;}
 if(bad_count>9)bad_count=0;
 if(!locked){
  if(div(std::min({aa,ab,acv}),std::max({aa,ab,acv}))>.8f&&div(std::min({wa,wb,wc}),std::max({wa,wb,wc}))>.8f&&div(std::min(d1,d2),std::max(d1,d2))>.8f){
   float interval=mul(add(d1,d2),.5f),width=mul(add(std::min({wa,wb,wc}),std::max({wa,wb,wc})),.5f);
   if(width>mul(interval,.6f)){b.kind=1;b.interval=d1;replace_last(b);update_average(mul(add(std::min({aa,ab,acv}),std::max({aa,ab,acv})),.5f),width,interval);locked=true;}
   else{append(c);return;}
  }else{if(acv<=mul(ab,.5f)||wc<=mul(wb,.5f)){if(d2>200)pulses.clear();return;}append(c);return;}
 }
 if(d1>200||d2>200){append(c);return;}
 if(seconds-last_update>20&&cv>0&&cv<30){average_amplitude=measured_amplitude;average_width=measured_width;average_interval=measured_interval;}
 float hi=mul(average_amplitude,3),lo=mul(average_amplitude,.3f),avg=average_interval,tolerance=mul(avg,.2f),span=sub(c.position,a.position);int oldkind=b.kind;
 if(a.kind==1){
  if(acv>lo&&std::abs(sub(d1,avg))>std::abs(sub(span,avg))&&std::abs(sub(span,avg))<tolerance){merge(b,c,true);replace_last(b);return;}
  if(std::abs(sub(avg,a.interval))<tolerance&&ab<hi&&std::abs(sub(d1,avg))<tolerance){b.kind=1;b.interval=d1;redistribute(a,b);c.interval=sub(c.position,b.position);append(c);update_average(ab,wb,b.interval);return;}
 }
 float ratio=div(b.fall,b.rise),r1=div(b.rise,a.fall),r2=div(b.fall,c.rise),ra=div(a.fall,a.rise),rc=div(c.fall,c.rise);
 bool anomaly=ab>hi;
 if(ab>lo)anomaly|=ra>.5f&&((r1>2&&rc<.5f)||(r2>2&&rc<2&&(r1>2||ra>2))||(ra>2&&ratio<.5f&&rc<2));
 if(anomaly){if(!artifact){artifact=true;pulses[pulses.size()-2].kind=5;}b.kind=4;replace_last(b);c.interval=sub(c.position,b.position);append(c);bad_count++;return;}
 bool consistent=(div(std::max(wb,d1),std::min(wb,d1))<1.5f||div(std::max(wb,d2),std::min(wb,d2))<1.5f)&&std::min({wb,d1,d2})>25;
 bool width_close=std::abs(sub(wb,average_width))<mul(average_width,.3f),times_close=sub(d1,wb)<tolerance||sub(d1,wa)<tolerance;
 bool accept=(width_close&&times_close)||(mul(add(aa,acv),.25f)<ab&&consistent&&((.5f<ratio&&ratio<2)||!artifact));
 if(accept){b.kind=artifact?5:1;artifact=false;bad_count=0;redistribute(a,b);
  bool exceptional=a.kind==1&&oldkind==2&&(std::abs(sub(b.interval,wa))<mul(b.interval,.2f)||std::abs(sub(b.interval,wb))<mul(b.interval,.2f))&&.5f<=r1&&r1<=2&&.5f<=ratio&&ratio<=2;
  if(std::abs(sub(b.interval,avg))>=tolerance&&!exceptional){b.kind=4;replace_last(b);}c.interval=sub(c.position,b.position);append(c);if(b.kind==1)update_average(ab,wb,b.interval);return;
 }
 bad_count++;
 if(artifact){b.kind=4;replace_last(b);}
 else if(ratio<=2&&(ratio<.5f||std::abs(sub(add(wb,wc),avg))<=std::abs(sub(add(wa,wb),avg)))){
  bool earlier=add(acv,acv)<ab||r2>2||((std::abs(sub(add(wb,wc),d1))<std::abs(sub(add(wb,wc),span))||std::abs(sub(avg,d1))<std::abs(sub(avg,span)))&&std::abs(sub(avg,a.interval))<tolerance&&mul(acv,.5f)<ab&&r2>.5f);
  merge(b,c,!earlier);b.kind=3;replace_last(b);return;
 }else{
  bool earlier=add(ab,ab)<aa||((std::abs(sub(add(wa,wb),a.interval))<std::abs(sub(add(wa,wb),add(a.interval,d1)))||std::abs(sub(avg,a.interval))<std::abs(sub(avg,add(a.interval,d1))))&&std::abs(sub(avg,a.interval))<tolerance);
  merge(a,b,!earlier);pulses.pop_back();pulses.pop_back();append(a);b.position=a.position;
 }c.interval=sub(c.position,b.position);append(c);
}
uint32_t Hrv::output(bool bad_sample){
 output_count++;float lower=25,upper=200;if(average_count>=16){lower=std::max(lower,mul(average_interval,.5f));upper=std::min(upper,mul(average_interval,3));}
 struct Pick{float interval;int kind;float position;};std::vector<Pick> picked;
 for(int i=int(pulses.size())-1;i>=0;i--){auto p=pulses[i];if(p.position<100){if(picked.empty()&&p.position<0)picked.push_back({p.interval,7,-1});break;}if(p.position>=200||p.ignored||picked.size()==4)continue;
  int kind=i==0||pulses[i-1].kind==1?p.kind:pulses[i-1].kind;float interval=p.interval;
  if(interval>upper){interval=upper;kind=8;}else if(interval<lower){interval=lower;kind=8;}
  picked.push_back({interval,kind,p.position});
 }
 std::reverse(picked.begin(),picked.end());picked.erase(std::remove_if(picked.begin(),picked.end(),[](Pick p){return p.interval<=0;}),picked.end());
 std::array<int32_t,4> rri{};beat_samples.fill(-1);int good=0,bad=0;
 for(size_t i=0;i<picked.size();i++){auto p=picked[i];rri[i]=rnd(div(mul(p.interval,1000),100));good+=p.kind==1;bad+=p.kind==7||p.kind==8;
  // 151-point DC + 65-tap FIR group delay = 107 samples. Never synthesize a beat from held output.
  if(p.kind==1&&p.position>=0)beat_samples[i]=((count-1)/100)*100+double(p.position)-300-107;
 }
 int other=int(picked.size())-good-bad,whole=0,recent=0;float avg=mean(acc),threshold=std::min(21.f,std::max(10.f,mul(3,sd(acc))));
 for(size_t i=0;i<acc.size();i++){bool motion=std::abs(sub(acc[i],avg))>threshold;whole+=motion;if(i>=100)recent+=motion;}
 int confidence=0;
 if(good){if(good==int(picked.size()))confidence=whole<=3&&recent<=3?100:recent<=3?90:80;else if(other)confidence=whole>3?60:70;else if(bad)confidence=whole>3?40:50;}
 else if(other)confidence=whole>3?20:30;else if(bad)confidence=whole>3?0:10;
 if(rri[0]>0){push(confidences,confidence,11);if(confidences.size()==11)confidence=int(median(confidences));}if(bad_sample)confidence=25;
 auto out=previous;if(!picked.empty()){for(int i=0;i<4;i++)out[i]=rri[i];out[4]=confidence;out[5]=picked.size();out[6]=out[7]=out[8]=0;}
 int reference=rnd(div(mul(average_interval,1000),100));auto local=rri;
 if(locked){
  if((std::abs(sub(div(out[0],reference),1))>0.2||!rri[0])&&output_count>5){local[0]=int(mul(add(last_interval,reference),.5f));out[0]=local[0];if(!local[0]){out[1]=out[2]=out[3]=0;out[5]=1;}}
  if(std::abs(sub(div(out[1],reference),1))>0.2&&output_count>4&&rri[1]){local[1]=int(div(add(add(local[0],reference),last_interval),3));out[1]=int(div(add(add(out[0],reference),last_interval),3));if(local[0]>999&&local[1]>999)local[1]=out[1]=0;}
  if(std::abs(sub(div(out[2],reference),1))>0.2&&output_count>4&&rri[2]){local[2]=int(div(add(local[1]+local[0],reference),3));out[2]=int(div(add(out[1]+out[0],reference),3));if(local[0]>999&&local[1]>999)local[1]=out[1]=0;}
 }
 for(int v:local)if(v)last_interval=v;
 if(!picked.empty())previous=out;
 // Held result is still returned at an update event, matching the reference.
 output_values=out;
 return 0x10000006;
}
uint32_t Hrv::process(int32_t green,const std::array<int32_t,3>& acceleration){
 int index=count++;bool valid=green==encode(green);float x=acceleration[0],y=acceleration[1],z=acceleration[2];float norm=float(std::sqrt(double(add(add(mul(y,y),mul(x,x)),mul(z,z)))));
 acc_batch.push_back(norm);if(acc_batch.size()==4){push(acc,mean(acc_batch),125);acc_batch.clear();}
 filter(valid?green:0);Pulse p;bool detected=detect(index,p);if(index%100==0)for(auto& pulse:pulses)pulse.position=sub(pulse.position,100);
 if(detected)track(p);beat_samples.fill(-1);output_values=previous;
 if(count>500&&count%100==0){seconds=count/100;return output(!valid);}return 0;
}
}
#ifdef HEALTH_HRV_HOST
#include <iostream>
#include <iomanip>
int main(){ring_health::Hrv h;int32_t green,x,y,z;std::cout<<std::setprecision(17);while(std::cin>>green>>x>>y>>z){auto r=h.process(green,{x,y,z});std::cout<<"{\"return\":"<<r<<",\"result\":[";for(int i=0;i<9;i++){if(i)std::cout<<',';std::cout<<h.output_values[i];}std::cout<<"],\"filtered\":[";bool comma=false;for(auto v:h.filtered){if(comma)std::cout<<',';comma=true;std::cout<<v;}std::cout<<"],\"pulses\":[";comma=false;for(auto p:h.pulses){if(comma)std::cout<<',';comma=true;std::cout<<'['<<p.position<<','<<p.rise<<','<<p.fall<<','<<p.rise_time<<','<<p.fall_time<<','<<p.interval<<','<<p.kind<<','<<p.ignored<<']';}std::cout<<"]}\n";}}
#endif
