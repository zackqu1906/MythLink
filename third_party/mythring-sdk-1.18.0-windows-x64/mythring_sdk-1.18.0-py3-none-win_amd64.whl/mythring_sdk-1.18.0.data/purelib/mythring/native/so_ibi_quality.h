#ifndef SO_IBI_QUALITY_H
#define SO_IBI_QUALITY_H
#include <stdint.h>
#include <math.h>
/* Conservative engineering screen, not ectopic diagnosis. No interpolation.
 * Scratch bounded to SO_BEAT_MAX. Invalid neighbors are never joined. */
static inline float so_ibi_median(float*a,unsigned n){for(unsigned i=1;i<n;i++){float v=a[i];unsigned j=i;while(j&&a[j-1]>v){a[j]=a[j-1];j--;}a[j]=v;}return (a[(n-1)/2]+a[n/2])*.5f;}
static inline unsigned so_ibi_screen(const float*x,uint8_t*valid,unsigned n){
 if(n>192)return 0;float a[192];unsigned count=0;
 for(unsigned i=0;i<n;i++)if(valid[i]&&isfinite(x[i]))a[count++]=x[i];
 if(count<12)return 0;float med=so_ibi_median(a,count);
 for(unsigned i=0,j=0;i<n;i++)if(valid[i]&&isfinite(x[i]))a[j++]=fabsf(x[i]-med);
 float mad=so_ibi_median(a,count),limit=fmaxf(120,fminf(.20f*med,4*1.4826f*mad));unsigned rejected=0;
 for(unsigned i=0;i<n;i++)if(valid[i]&&(!isfinite(x[i])||fabsf(x[i]-med)>limit)){valid[i]=0;rejected++;}
 return rejected;
}
#endif
