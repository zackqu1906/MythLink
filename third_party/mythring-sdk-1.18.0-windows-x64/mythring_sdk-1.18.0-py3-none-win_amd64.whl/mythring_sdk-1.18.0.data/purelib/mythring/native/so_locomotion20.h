#ifndef SO_LOCOMOTION20_H
#define SO_LOCOMOTION20_H
#include <stdint.h>
#define SO_LOCOMOTION_MODEL 0x20261001U
/* Input magnitude in m/s^2, 1000 samples at 50 Hz. Scratch is caller-owned,
 * serialized with other DSP. No heap, sensor operations, or raw persistence. */
int so_locomotion20_features(const float magnitude[1000],float out[13],double scratch[1295]);
double so_locomotion20_score(const float features[13]);
unsigned so_locomotion20_count(const float magnitude[1000]);
#endif
