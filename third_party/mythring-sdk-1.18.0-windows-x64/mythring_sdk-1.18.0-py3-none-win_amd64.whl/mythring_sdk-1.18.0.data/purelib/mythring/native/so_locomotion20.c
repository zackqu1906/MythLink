#include "so_locomotion20.h"
#include "app_step_core.h"
#include <math.h>
#include <stddef.h>

int so_locomotion20_features(const float *x,float *out,double *w){
 if(!x||!out||!w)return -1;
 double mean=0,total=0,center=0,width=0,entropy=0,cumulative=0;
 for(unsigned i=0;i<1000;i++){if(!isfinite(x[i]))return -1;mean+=x[i];}mean/=1000;
 for(unsigned i=0;i<1000;i++)w[i]=(x[i]-mean)*(.5-.5*cos(6.2831853071795864769*i/999));
 double *p=w+1000;
 for(unsigned j=0;j<295;j++){
  double c=2*cos(6.2831853071795864769*(j+6)/1000),q1=0,q2=0;
  for(unsigned i=0;i<1000;i++){double q=w[i]+c*q1-q2;q2=q1;q1=q;}
  p[j]=fmax(0,q1*q1+q2*q2-c*q1*q2);total+=p[j];
 }
 if(total<=0)total=0x0.0000000000001p-1022;
 unsigned peak=0,roll=294;bool rolled=false;
 for(unsigned j=0;j<295;j++){
  double q=p[j]/total,f=(j+6)/20.;center+=f*q;
  if(j<=194&&p[j]>p[peak])peak=j;
  if(q>0)entropy-=q*log(q);
  cumulative+=q;if(!rolled&&cumulative>=.85){roll=j;rolled=true;}
 }
 for(unsigned j=0;j<295;j++){double d=(j+6)/20.-center;width+=d*d*p[j]/total;}
 out[0]=log10(total);out[1]=(peak+6)/20.;out[2]=p[peak]/total;out[3]=center;
 out[4]=sqrt(fmax(0,width));out[5]=entropy/log(295.);out[6]=(roll+6)/20.;
 const unsigned edge[]={6,20,40,60,100,200,300};
 for(unsigned b=0;b<6;b++){double sum=0;for(unsigned k=edge[b];k<edge[b+1];k++)sum+=p[k-6];out[7+b]=sum/total;}
 return 0;
}
unsigned so_locomotion20_count(const float *x){
 struct app_oxford_counter c;app_oxford_init(&c);unsigned total=0;
 for(unsigned i=0;i<1000;i++)total+=app_oxford_push(&c,i*20,x[i]);return total;
}
