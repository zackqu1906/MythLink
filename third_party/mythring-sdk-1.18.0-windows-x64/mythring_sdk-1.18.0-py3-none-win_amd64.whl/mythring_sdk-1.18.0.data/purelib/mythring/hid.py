"""Firmware HID gesture mapping, ported from HidClient.kt (not USB key codes)."""
from __future__ import annotations

import asyncio
import struct
from dataclasses import dataclass
from enum import IntEnum
from collections.abc import Awaitable, Callable


class HidGesture(IntEnum):
    LEFT = 3
    RIGHT = 4
    INDEX_SINGLE = 8
    INDEX_DOUBLE = 0x88
    MIDDLE_SINGLE = 9
    MIDDLE_DOUBLE = 0x89
    SNAP = 6
    CLOCKWISE = 12
    COUNTERCLOCKWISE = 13


class HidKey(IntEnum):
    DISABLED = 0
    ENTER = 28
    BACK = 158
    F3 = 61
    F6 = 64
    F9 = 148
    LEFT = 105
    RIGHT = 106
    VOLUME_UP = 115
    VOLUME_DOWN = 114


@dataclass(frozen=True)
class HidMapping:
    gesture: HidGesture
    key: HidKey
    error_code: int = 0


class HidError(Exception):
    def __init__(self, reason: str, device_code: int | None = None):
        self.reason, self.device_code = reason, device_code
        super().__init__(reason if device_code is None else f"{reason} ({device_code})")


def parse_mapping(packet: bytes) -> HidMapping | None:
    if len(packet) != 7 or packet[:2] != b"\x30\x05":
        return None
    gesture, key, error = struct.unpack_from("<BHh", packet, 2)
    try:
        return HidMapping(HidGesture(gesture), HidKey(key), error)
    except ValueError:
        return None


class HidClient:
    """Serialize unsequenced replies; uncertain requests require reconnection."""

    def __init__(self, send: Callable[[bytes], Awaitable[None]], timeout: float = 3.0):
        self._send, self._timeout = send, timeout
        self._lock = asyncio.Lock()
        self._epoch = 0
        self._ready = self._supported = self._quarantined = False
        self._probe_before_save = False
        self._pending: tuple[HidGesture, asyncio.Future] | None = None

    def disconnected(self) -> None:
        self._epoch += 1
        self._ready = self._supported = self._quarantined = False
        if self._pending and not self._pending[1].done():
            self._pending[1].set_exception(HidError("disconnected"))
        self._pending = None

    def connected(self, supported: bool, *, probe_before_save: bool = False) -> None:
        self.disconnected()
        self._ready, self._supported = True, supported
        self._probe_before_save = probe_before_save

    def accept(self, packet: bytes) -> bool:
        if packet[:2] != b"\x30\x05":
            return False
        reply = parse_mapping(packet)
        if reply and self._pending:
            gesture, future = self._pending
            if reply.gesture == gesture and not future.done():
                future.set_result(reply)
        return True

    def _admission(self) -> int:
        if not self._ready:
            raise HidError("disconnected")
        if not self._supported:
            raise HidError("unsupported")
        if self._quarantined:
            raise HidError("result_unknown")
        return self._epoch

    async def read(self, gesture: HidGesture) -> HidMapping:
        epoch = self._admission()
        async with self._lock:
            return await self._request(HidGesture(gesture), None, epoch)

    async def save(self, gesture: HidGesture, key: HidKey) -> HidMapping:
        epoch = self._admission()
        gesture, key = HidGesture(gesture), HidKey(key)
        async with self._lock:
            if self._probe_before_save:
                await self._request(gesture, None, epoch)
            await self._request(gesture, key, epoch)
            result = await self._request(gesture, None, epoch)
            if result.key != key:
                raise HidError("readback_mismatch")
            return result

    async def _request(self, gesture: HidGesture, key: HidKey | None, epoch: int) -> HidMapping:
        if self._admission() != epoch:
            raise HidError("disconnected")
        future = asyncio.get_running_loop().create_future()
        self._pending = gesture, future
        packet = (bytes((0x30, 4, gesture)) if key is None
                  else struct.pack("<BBBH", 0x30, 3, gesture, key))

        async def operation():
            await self._send(packet)
            return await future

        try:
            reply = await asyncio.wait_for(operation(), self._timeout)
            if self._epoch != epoch or not self._ready:
                raise HidError("disconnected")
            if reply.error_code:
                reason = ("unsupported_item" if reply.error_code in (-95, -22)
                          else "busy" if reply.error_code == -16 else "device_error")
                raise HidError(reason, reply.error_code)
            return reply
        except HidError:
            raise
        except BaseException as error:
            if epoch == self._epoch:
                self._quarantined = True
            if isinstance(error, asyncio.CancelledError):
                raise
            if not isinstance(error, Exception):
                raise
            raise HidError("result_unknown") from error
        finally:
            if self._pending and self._pending[1] is future:
                self._pending = None
            if not future.done():
                future.cancel()
            elif not future.cancelled():
                future.exception()


__all__ = ["HidClient", "HidGesture", "HidKey", "HidMapping", "HidError", "parse_mapping"]
