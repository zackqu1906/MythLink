"""Read-only compatibility explanations; querying them never probes the ring.

Support describes the SDK/device protocol combination, not current readiness,
successful model negotiation, hardware test coverage or an OTA recommendation.
"""

from dataclasses import asdict, dataclass
from typing import Literal

from .models import DeviceInfo


FEATURES = (
    "battery", "rssi", "gesture", "gesture_low_power", "gesture_config", "imu",
    "touchpad", "touchpad_raw", "health", "hid", "ota", "owner_unbind", "audio",
)

# These identify delivered protocol variants, not a claim that every operation
# has been exercised on hardware. Board and bootloader compatibility is separate.
_EXACT_RULES = {
    (1, "1.2.122.public"): ("ringo.legacy.1.2.122.public", (1, 2, 122, 0)),
    (1, "1.2.133.public"): ("ringo.legacy.1.2.133.public", (1, 2, 133, 0)),
    (1, "2.1.6-dev.touchpad.9.debug"): ("ringo.touchpad.dev9", (2, 1, 6, 0)),
    (1, "2.1.6-dev.touchpad.15.debug"): ("ringo.touchpad.dev15", (2, 1, 6, 0)),
    (2, "2.1.6-dev.hz.6.release"): ("r1.health.hz6", (2, 1, 6, 0)),
}


@dataclass(frozen=True)
class FeatureSupport:
    feature: str
    state: Literal["supported", "unsupported", "unknown"]
    reason_code: str
    reason: str
    profile: str | None
    rule_id: str | None
    source: str

    def to_dict(self) -> dict:
        """Return plain JSON-serializable values."""
        return asdict(self)


@dataclass(frozen=True)
class CompatibilitySnapshot:
    product_id: str | None
    board_revision: str | None
    legacy_hardware_code: int | None
    firmware_version: str | None
    firmware_text_version: str | None
    firmware_numeric_version: tuple[int, int, int, int] | None
    firmware_version_source: str | None
    profile: str | None
    rule_id: str | None
    source: str
    features: tuple[FeatureSupport, ...]

    def feature_support(self, feature: str) -> FeatureSupport:
        for support in self.features:
            if support.feature == feature:
                return support
        return FeatureSupport(feature, "unknown", "unknown_feature",
                              "This SDK does not define this feature name.",
                              self.profile, self.rule_id, "sdk")

    def to_dict(self) -> dict:
        """Return an independent JSON value, with features indexed by name."""
        result = asdict(self)
        if self.firmware_numeric_version is not None:
            result["firmware_numeric_version"] = list(self.firmware_numeric_version)
        result["features"] = {item.feature: item.to_dict() for item in self.features}
        return result


def compatibility_snapshot(info: DeviceInfo | None, profile: str | None,
                           capabilities: dict[str, bool]) -> CompatibilitySnapshot:
    """Explain existing gates without changing them or performing I/O."""
    rule_id, source, conflict = None, "not_connected", False
    if info is not None:
        source = "legacy_profile" if profile != "unknown" else "unknown_firmware"
        rule = _EXACT_RULES.get((info.legacy_hardware_code, info.firmware_text_version))
        if rule:
            rule_id, expected_numeric = rule
            conflict = info.firmware_numeric_version != expected_numeric
            source = "identity_conflict" if conflict else "exact_rule"
        elif profile != "unknown":
            rule_id = f"legacy.{profile}"

    def explain(feature: str) -> FeatureSupport:
        def result(state, code, reason, evidence=source):
            return FeatureSupport(feature, state, code, reason, profile, rule_id, evidence)

        if info is None:
            return result("unknown", "not_connected", "Connect and read INFO to establish device identity.")
        if feature == "audio":
            if info.product_id == "r1":
                return result("unsupported", "hardware_not_supported",
                              "R1 has no microphone audio hardware.", "hardware_identity")
            if conflict:
                return result("unknown", "identity_conflict",
                              "INFO text and numeric versions do not match the known audio release.")
            if capabilities.get(feature):
                if rule_id == "ringo.touchpad.dev9":
                    return result("supported", "device_protocol_verified",
                                  "Ringo44FA verified ADPCM decoding on dev9; continuous throughput remains unverified.")
                return result("supported", "documented_protocol",
                              "The SDK implements this Ringo firmware's audio protocol; start is explicit.")
            if rule_id in ("ringo.legacy.1.2.133.public", "ringo.touchpad.dev9") and source == "exact_rule":
                return result("unsupported", "component_not_available",
                              "INFO does not report a present microphone component.", "info_component")
            return result("unknown", "firmware_unverified",
                          "Audio has not been established for this hardware and firmware combination.")
        if feature in ("battery", "rssi"):
            return result("supported", "basic_protocol",
                          "The SDK provides this basic operation; platform availability and live state still apply.",
                          "sdk")
        if conflict:
            return result("unknown", "identity_conflict",
                          "INFO text and numeric versions do not match the known release; legacy gates are unchanged.")
        if profile == "unknown":
            return result("unknown", "firmware_unverified",
                          "This firmware combination has no known protocol profile.")
        if not capabilities.get(feature, False):
            if ((feature == "gesture" and not info.swipe_available) or
                    (feature == "imu" and profile == "legacy_v1" and
                     not any(row.id == 1 and row.present for row in info.components))):
                return result("unsupported", "component_not_available",
                              "INFO does not report the component needed by this operation.", "info_component")
            return result("unsupported", "sdk_not_implemented",
                          "The SDK does not enable this operation for this protocol profile; this is not an OTA recommendation.")
        if rule_id == "ringo.touchpad.dev15":
            if feature in ("touchpad", "touchpad_raw"):
                return result("supported", "firmware_model_match",
                              "The firmware image contains the SDK's Raw2 model descriptor. "
                              "Start still requires a matching STATUS and first reset token.", "firmware_image")
            return result("unknown", "firmware_unverified",
                          "The SDK permits this operation, but it has not been verified on dev15.")
        if source != "exact_rule":
            return result("unknown", "firmware_unverified",
                          "The existing profile permits this operation, but this exact firmware combination is unverified.")
        return result("supported", "documented_protocol",
                      "The SDK implements this known firmware protocol; module negotiation and live readiness still apply.")

    return CompatibilitySnapshot(
        product_id=info.product_id if info else None,
        board_revision=info.board_revision if info else None,
        legacy_hardware_code=info.legacy_hardware_code if info else None,
        firmware_version=info.firmware_version if info else None,
        firmware_text_version=info.firmware_text_version if info else None,
        firmware_numeric_version=info.firmware_numeric_version if info else None,
        firmware_version_source=info.firmware_version_source if info else None,
        profile=profile, rule_id=rule_id, source=source,
        features=tuple(explain(feature) for feature in FEATURES),
    )


__all__ = ["FeatureSupport", "CompatibilitySnapshot"]
