"""Durable, account/device-scoped health archive with CRC-boundary recovery."""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
import struct
import zlib
from dataclasses import asdict, replace
from pathlib import Path

from .health_models import HealthBedtime, HealthReport
from .health_protocol import MAX_FILE, HealthRecording, read_block, read_blocks


class HealthStore:
    def __init__(self, base: str | Path, address: str, account: str = "local-default", *, read_only: bool = False):
        if not account.strip() or len(account) > 1024 or not address.strip():
            raise ValueError("A nonempty account and device identity are required")
        self.base, self.address, self.account = Path(base).expanduser(), address, account
        digest = lambda value: hashlib.sha256(value.encode("utf-8")).hexdigest()
        self.root = self.base / digest(account) / digest(address.upper())
        if not read_only:
            self.root.mkdir(parents=True, exist_ok=True)

    def atomic(self, name: str, value) -> None:
        target = self.root / name
        text = json.dumps(value, allow_nan=False, separators=(",", ":"), ensure_ascii=False)
        fd, temporary = tempfile.mkstemp(prefix=f".{name}.", dir=self.root)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as out:
                out.write(text)
                out.flush()
                os.fsync(out.fileno())
            os.replace(temporary, target)
            if os.name != "nt":
                directory = os.open(self.root, os.O_RDONLY)
                try:
                    os.fsync(directory)
                finally:
                    os.close(directory)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def read_json(self, name: str, default=None):
        try:
            return json.loads((self.root / name).read_text("utf-8"))
        except FileNotFoundError:
            return default

    def raw(self, record_id: int) -> Path:
        if not isinstance(record_id, int) or record_id <= 0:
            raise ValueError("Invalid recording ID")
        return self.root / f"{record_id}.raw"

    def save(self, record: HealthRecording) -> None:
        previous = self.recording(record.id)
        if previous is not None and previous.start_utc_ms != record.start_utc_ms:
            raise ValueError("Device reused a recording ID; retain/export existing archive before resetting it")
        self.atomic(f"{record.id}.json", asdict(record))

    def recording(self, record_id: int) -> HealthRecording | None:
        data = self.read_json(f"{record_id}.json")
        if data is None:
            return None
        record = self.decode_recording(data)
        if record.id != record_id:
            raise ValueError("Archive metadata identity mismatch")
        return record

    @staticmethod
    def decode_recording(data):
        if "start" in data:
            return HealthRecording(data["id"], data["status"], data["bytes"], data["start"], data["duration"], data["mode"])
        return HealthRecording(**data)

    def recordings(self) -> list[HealthRecording]:
        return sorted((self.recording(int(path.stem)) for path in self.root.glob("*.json") if path.stem.isdecimal()), key=lambda row: row.id)

    def append(self, record_id: int, offset: int, data: bytes) -> None:
        if offset < 0 or offset + len(data) > MAX_FILE:
            raise ValueError("Health recording exceeds maximum size")
        path = self.raw(record_id)
        with path.open("r+b" if path.exists() else "w+b") as out:
            if out.seek(0, os.SEEK_END) != offset:
                raise ValueError("Local health sync cursor changed")
            out.write(data)
            out.flush()
            os.fsync(out.fileno())

    def truncate(self, record_id: int, size: int) -> None:
        with self.raw(record_id).open("r+b") as file:
            file.truncate(size)
            file.flush()
            os.fsync(file.fileno())

    def recover(self, record_id: int) -> int:
        """Truncate only damaged/incomplete trailing bytes, retaining verified RH blocks."""
        path = self.raw(record_id)
        if not path.exists():
            return 0
        valid, sequence, schema, ended = 0, 0, None, False
        with path.open("rb") as file:
            while True:
                try:
                    block = read_block(file)
                    if block is None:
                        break
                    if ended or block.sequence != sequence or (sequence == 0) != (block.kind == 1) or (schema is not None and block.schema != schema):
                        break
                    schema = block.schema
                    sequence += 1
                    valid += block.stored_bytes
                    ended = block.kind == 7
                except (ValueError, OSError):
                    break
        if path.stat().st_size != valid:
            self.truncate(record_id, valid)
        return valid

    def require_verified(self, record_id: int) -> HealthRecording:
        record = self.recording(record_id)
        if record is None or record.status not in (1, 2, 3) or self.recover(record_id) != record.bytes:
            raise ValueError("Complete locally committed recording required")
        tuple(read_blocks(self.raw(record_id).read_bytes(), require_end=record.complete))
        return record

    def is_verified(self, record: HealthRecording) -> bool:
        if self.recording(record.id) != record:
            return False
        try:
            return self.require_verified(record.id) == record
        except ValueError:
            return False

    def report(self, record_id: int) -> HealthReport | None:
        data = self.read_json(f"{record_id}.report")
        return None if data is None else self.apply_resets(HealthReport.from_dict(data))

    def save_report(self, report: HealthReport) -> HealthReport:
        report = self.apply_resets(report)
        self.atomic(f"{report.recording.id}.report", report.to_dict())
        return report

    def reports(self) -> list[HealthReport]:
        return [report for record in self.recordings() if (report := self.report(record.id)) is not None]

    def save_clock(self, boot_id: int, offset: int) -> None:
        if boot_id == 0 or not 0 < offset < 2**63 - 8589934592:
            raise ValueError("Invalid health clock calibration")
        self.atomic(f"boot-{boot_id}.clock", offset)

    def clock(self, boot_id: int) -> int | None:
        return self.read_json(f"boot-{boot_id}.clock")

    def is_acknowledged(self, record: HealthRecording) -> bool:
        ack = self.read_json(f"{record.id}.ack")
        if ack is not None and self.decode_recording(ack) == record:
            return True
        receipt = self.receipts().get(str(record.id))
        return receipt is not None and receipt["record"] == asdict(record)

    def receipts(self):
        rows = self.read_json("sync-progress-v1", {}).get("confirmed", {})
        rows = rows.values() if isinstance(rows, dict) else rows
        return {str(record.id): {"record": asdict(record), "reclaimed": row.get("reclaimed", False)}
                for row in rows for record in (self.decode_recording(row["record"]),)}

    def mark_acknowledged(self, record: HealthRecording) -> None:
        self.atomic(f"{record.id}.ack", asdict(record))

    def pending_batch(self) -> list[HealthRecording]:
        return [self.decode_recording(row) for row in self.read_json("pending-batch-v1", [])]

    def cached_refusal(self, record, boot, flags, revision):
        data = self.read_json(f"{record.id}.refusal")
        if data is not None and boot != 0 and data["boot"] == boot and data["flags"] == flags and data["revision"] == revision and self.decode_recording(data["record"]) == record and data["code"] in (-134, -95):
            return data["code"]
        return None

    def save_refusal(self, record, boot, flags, revision, code):
        if code not in (-134, -95):
            raise ValueError("Not a permanent firmware read refusal")
        self.atomic(f"{record.id}.refusal", {"boot": boot, "flags": flags, "revision": revision, "record": asdict(record), "code": code})

    def has_recovered_source(self, source):
        """Verify a preserved schema-5 original and its separately analyzed replay."""
        try:
            manifest = self.read_json(f"{source.id}.recovered.json")
            if manifest is None or source.mode != 7 or source.status not in (1, 2, 3) or manifest["schema"] != 1 or self.decode_recording(manifest["source"]) != source:
                return False
            identity = manifest["derivedId"]
            report = self.report(identity)
            if identity <= 0 or identity == source.id or report is None or report.recording.mode != 7 or report.recording.status not in (1, 2, 3) or report.recording.duration_ms != source.duration_ms or "OFFLINE_SCHEMA5_REPLAY" not in report.warnings or f"OFFLINE_SOURCE_RECORD_{source.id}" not in report.warnings:
                return False
            def checked(path, size, digest):
                if not 0 < size <= MAX_FILE or path.stat().st_size != size or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
                    raise ValueError("Invalid preserved source metadata")
                data = path.read_bytes()
                if hashlib.sha256(data).hexdigest() != digest:
                    raise ValueError("Preserved source checksum mismatch")
                return data
            original = checked(self.root/f"{source.id}.source.rh", source.bytes, manifest["sourceSha256"])
            analyzed = checked(self.raw(identity), report.recording.bytes, manifest["derivedSha256"])
            offset, sequence, ended = 0, 0, False
            while offset < len(original):
                if ended or len(original)-offset < 24:
                    return False
                magic, schema, kind, size, _, observed = struct.unpack_from("<HBBHHI", original, offset)
                if magic != 0x4852 or schema != 5 or size > 1800 or offset+24+size > len(original) or observed != sequence:
                    return False
                payload = original[offset+24:offset+24+size]
                invalid = (kind != 1 or size != 48 or payload[:2] != b"\x07\x05") if sequence == 0 else kind not in (4, 6, 7, 14, 15)
                if invalid:
                    return False
                if zlib.crc32(payload, zlib.crc32(original[offset:offset+20])) != struct.unpack_from("<I", original, offset+20)[0]:
                    return False
                ended = kind == 7
                if ended and (size != 8 or payload[0] not in (1, 2, 3)):
                    return False
                sequence += 1
                offset += 24+size
            if not ended or sequence < 2:
                return False
            tuple(read_blocks(analyzed, require_end=report.recording.complete))
            return True
        except (OSError, KeyError, TypeError, ValueError, struct.error):
            return False

    def save_pending_batch(self, records: list[HealthRecording]) -> None:
        self.atomic("pending-batch-v1", [asdict(row) for row in records])

    def save_sync_progress(self, observed: list[HealthRecording], confirmed: list[HealthRecording] = (), reclaimed: bool = False) -> None:
        previous = self.read_json("sync-progress-v1", {})
        receipts = self.receipts()
        seen = {row["id"]: asdict(self.decode_recording(row)) for row in previous.get("observed", [])}
        for row in observed:
            if row.status in (1, 2, 3):
                seen[row.id] = asdict(row)
        for row in confirmed:
            receipts[str(row.id)] = {"record": asdict(row), "reclaimed": reclaimed or receipts.get(str(row.id), {}).get("reclaimed", False)}
        ordered = sorted(seen.values(), key=lambda row: row["id"])
        pending, cursor, contiguous = [], 0, True
        for row in ordered:
            done = receipts.get(str(row["id"]), {}).get("record") == row or self.is_acknowledged(HealthRecording(**row))
            if not done:
                pending.append(row["id"])
                contiguous = False
            if contiguous:
                cursor = row["id"]
        self.atomic("sync-progress-v1", {"schema": 1, "contiguousThrough": cursor, "pending": pending, "observed": ordered, "confirmed": receipts})

    def reset_bedtime_steps(self, from_utc_ms: int, until_utc_ms: int) -> None:
        if from_utc_ms <= 0 or until_utc_ms <= from_utc_ms:
            raise ValueError("Invalid reset interval")
        ranges = self.read_json("bed-step-reset-v1", [])
        ranges.append([from_utc_ms, until_utc_ms])
        self.atomic("bed-step-reset-v1", ranges)

    def apply_resets(self, report: HealthReport) -> HealthReport:
        ranges = self.read_json("bed-step-reset-v1", [])
        legacy = self.root / "bed-step-reset-v1.tsv"
        if legacy.exists():
            for line in legacy.read_text("utf-8").splitlines():
                if line.strip():
                    start, until = map(int, line.split("\t"))
                    if start <= 0 or until <= start:
                        raise ValueError("Invalid archived reset interval")
                    ranges.append([start, until])
        for start, until in ranges:
            def keep(a, b):
                if b <= start or a >= until:
                    return [(a, b)]
                return [(x, y) for x, y in ((a, min(b, start)), (max(a, until), b)) if y > x]
            report = replace(report,
                activity=[row for row in report.activity if not start <= row.start_utc_ms < until],
                bedtimes=[HealthBedtime(a, b) for row in report.bedtimes for a, b in keep(row.start_utc_ms, row.end_utc_ms)],
                sleep=[replace(row, start_utc_ms=a, duration_ms=b - a) for row in report.sleep for a, b in keep(row.start_utc_ms, row.start_utc_ms + row.duration_ms)])
        return report

    def analysis_activation(self, initial_utc_ms: int) -> int:
        """Preserve the original install-wide cutoff for legacy raw recordings."""
        path = self.base / "lowrate-activation.utc"
        try:
            descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            value = int(path.read_text("ascii"))
            if value <= 0:
                raise ValueError("Invalid legacy analysis activation time")
            return value
        with os.fdopen(descriptor, "w", encoding="ascii") as output:
            output.write(str(initial_utc_ms))
            output.flush()
            os.fsync(output.fileno())
        return initial_utc_ms
