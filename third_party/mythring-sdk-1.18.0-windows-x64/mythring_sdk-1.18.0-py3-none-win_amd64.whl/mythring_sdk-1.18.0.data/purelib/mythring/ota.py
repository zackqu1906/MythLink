"""R1 MCUboot package handling and SMP upload, reboot and verified recovery.

The default TEST_ONLY flow matches Android 1.15.1: firmware confirms its own
successful boot. Explicit ``confirm=True`` first checks the running image and
identity before sending confirmation. Package parsing does not verify a vendor
signature; MCUboot enforces that on-device.
"""

from __future__ import annotations

import hashlib
import asyncio
import io
import json
import logging
import math
import re
import struct
import time
import zipfile
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable

from .smp import SmpCommandError, SmpError, SmpTransport, _with_timeout, encode_request, parse_hardware_address
from .errors import UnsupportedFeatureError

MAX_FIRMWARE_BYTES = 64 * 1024 * 1024
_IMAGE_MAGIC = 0x96F3B83D
_ROM_FIXED = 0x100
_ENCRYPTED = 0x04 | 0x08
_DIGEST_TYPES = {0x10: ("sha256", 32), 0x11: ("sha384", 48), 0x12: ("sha512", 64)}


class FirmwarePackageError(ValueError):
    """The firmware package is malformed or has an incompatible image layout."""


class OtaUnsupportedError(NotImplementedError):
    """An offline check requires plaintext that is unavailable for an encrypted image."""


@dataclass(frozen=True)
class FirmwarePackage:
    image_bytes: bytes
    version: str
    load_addr: int
    flags: int
    header_size: int
    image_size: int
    protected_tlv_size: int
    runtime_version: str | None = None

    @classmethod
    def from_file(cls, path: str | Path) -> FirmwarePackage:
        source = Path(path)
        if not source.is_file():
            raise FirmwarePackageError(f"Firmware file does not exist: {source}")
        if not 1 <= source.stat().st_size <= MAX_FIRMWARE_BYTES:
            raise FirmwarePackageError("Firmware file must be between 1 byte and 64 MiB")
        with source.open("rb") as stream:
            return cls.parse(stream.read(MAX_FIRMWARE_BYTES + 1))

    @classmethod
    def parse(cls, data: bytes) -> FirmwarePackage:
        if not 1 <= len(data) <= MAX_FIRMWARE_BYTES:
            raise FirmwarePackageError("Firmware package must be between 1 byte and 64 MiB")
        data = bytes(data)
        runtime = None
        if data[:2] == b"PK":
            data, runtime = _extract_zip(data)
        if len(data) < 32:
            raise FirmwarePackageError("MCUboot image must contain a 32-byte header")
        magic, load_addr, header_size, protected_size, image_size, flags, major, minor, revision, build = (
            struct.unpack_from("<IIHHIIBBHI", data)
        )
        if magic != _IMAGE_MAGIC:
            raise FirmwarePackageError(f"Bad image magic 0x{magic:08x}; expected an MCUboot signed image")
        if header_size < 32 or image_size == 0:
            raise FirmwarePackageError("Invalid MCUboot image sizes")
        if header_size + image_size > len(data):
            raise FirmwarePackageError("Truncated MCUboot image")
        if load_addr != 0 or flags & _ROM_FIXED:
            raise FirmwarePackageError("Incompatible R1 layout: load_addr must be 0 and ROM_FIXED must be clear")
        return cls(data, f"{major}.{minor}.{revision}+{build}", load_addr, flags,
                   header_size, image_size, protected_size, runtime)

    def _digest(self) -> tuple[str, bytes]:
        offset = self.header_size + self.image_size
        if self.protected_tlv_size:
            end, _ = _read_tlvs(self.image_bytes, offset, 0x6908)
            if end - offset != self.protected_tlv_size:
                raise FirmwarePackageError("Protected MCUboot TLV size differs from the image header")
            offset = end
        _, records = _read_tlvs(self.image_bytes, offset, 0x6907)
        digests = [(kind, value) for kind, value in records if kind in _DIGEST_TYPES]
        if len(digests) != 1:
            raise FirmwarePackageError("Expected exactly one MCUboot image digest")
        kind, digest = digests[0]
        algorithm, length = _DIGEST_TYPES[kind]
        if len(digest) != length:
            raise FirmwarePackageError(f"Invalid {algorithm} MCUboot digest length")
        return algorithm, digest

    def verification_hash(self) -> bytes:
        """Return the embedded plaintext digest, not the hash of the encrypted file.

        This only extracts the MCUboot TLV used for device image identification.
        It does not verify that the embedded digest or signature is trustworthy.
        """
        return self._digest()[1]

    def verify_integrity(self) -> bool:
        """Check a plaintext image against its embedded digest; no signature check.

        Encrypted images need the vendor decryption path and are unsupported.
        """
        if self.flags & _ENCRYPTED:
            raise OtaUnsupportedError("Cannot hash the plaintext of an encrypted MCUboot image")
        algorithm, expected = self._digest()
        end = self.header_size + self.image_size + self.protected_tlv_size
        actual = hashlib.new(algorithm, self.image_bytes[:end]).digest()
        if actual != expected:
            raise FirmwarePackageError("MCUboot image digest mismatch")
        return True


def _read_tlvs(data: bytes, offset: int, expected_magic: int) -> tuple[int, list[tuple[int, bytes]]]:
    if offset + 4 > len(data):
        raise FirmwarePackageError("Missing MCUboot TLV header")
    magic, length = struct.unpack_from("<HH", data, offset)
    if magic != expected_magic or length < 4 or offset + length > len(data):
        raise FirmwarePackageError("Invalid MCUboot TLV header or length")
    cursor, end = offset + 4, offset + length
    records: list[tuple[int, bytes]] = []
    while cursor < end:
        if cursor + 4 > end:
            raise FirmwarePackageError("Truncated MCUboot TLV record")
        kind, size = struct.unpack_from("<HH", data, cursor)
        cursor += 4
        if cursor + size > end:
            raise FirmwarePackageError("Truncated MCUboot TLV value")
        records.append((kind, data[cursor:cursor + size]))
        cursor += size
    return end, records


def _extract_zip(data: bytes) -> tuple[bytes, str | None]:
    image: bytes | None = None
    metadata: dict | None = None
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            for entry in archive.infolist():
                if entry.is_dir():
                    continue
                name = entry.filename.rsplit("/", 1)[-1].lower()
                if name.endswith(".signed.bin"):
                    if image is not None:
                        raise FirmwarePackageError("Firmware ZIP contains multiple *.signed.bin files")
                    image = _read_entry(archive, entry, MAX_FIRMWARE_BYTES)
                elif name == "build-info.json":
                    if metadata is not None:
                        raise FirmwarePackageError("Firmware ZIP contains multiple build-info.json files")
                    value = json.loads(_read_entry(archive, entry, 64 * 1024).decode("utf-8"))
                    if not isinstance(value, dict):
                        raise FirmwarePackageError("Firmware metadata must be a JSON object")
                    metadata = value
    except (zipfile.BadZipFile, UnicodeDecodeError, json.JSONDecodeError, RuntimeError) as error:
        raise FirmwarePackageError(f"Invalid firmware ZIP: {error}") from error
    if image is None:
        raise FirmwarePackageError("No *.signed.bin found inside firmware ZIP")
    runtime = None
    if metadata is not None:
        display, variant, info = (metadata.get(key) for key in ("displayVersion", "variant", "infoVersion"))
        if isinstance(display, str) and display.strip() and variant in ("release", "debug"):
            runtime = f"{display}.{variant}"
        elif isinstance(info, str) and info.strip():
            runtime = info
    return image, runtime


def _read_entry(archive: zipfile.ZipFile, entry: zipfile.ZipInfo, limit: int) -> bytes:
    if entry.file_size > limit:
        raise FirmwarePackageError(f"Firmware ZIP entry exceeds its size limit: {entry.filename}")
    with archive.open(entry) as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise FirmwarePackageError(f"Firmware ZIP entry exceeds its size limit: {entry.filename}")
    return data


class FirmwareUpdateState(str, Enum):
    VALIDATING = "validating"
    UPLOADING = "uploading"
    TESTING = "testing"
    RESETTING = "resetting"
    WAITING_FOR_ADVERTISE = "waiting_for_advertise"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"


class OtaError(RuntimeError):
    """A firmware update or its post-boot verification did not complete."""


@dataclass(frozen=True)
class OtaImageState:
    slot: int
    version: str
    hash: bytes
    active: bool
    bootable: bool
    confirmed: bool
    pending: bool
    image: int = 0


@dataclass(frozen=True)
class OtaVerifiedFirmware:
    runtime_version: str
    image_version: str
    hash: bytes


@dataclass
class FirmwareUpdateTarget:
    """An INFO/MAC verified, single-use maintenance permit valid for 60 seconds.

    Obtain via ``RingOtaUpdater.prepare_target`` while the sensor Ring is still
    connected. ``device`` is the platform BLE locator; on macOS it is not a MAC.
    """
    ring: Any = field(repr=False)
    device: Any = field(repr=False)
    hardware_address: str
    generation: int
    created_at: float
    _consumed: bool = field(default=False, init=False, repr=False)

    def consume(self, ring: Any) -> None:
        age = time.monotonic() - self.created_at
        if (self._consumed or ring is not self.ring or not ring.is_connected
                or ring._generation != self.generation or not 0 <= age <= 60):
            raise OtaError("Expired, consumed or stale firmware maintenance target")
        self._consumed = True


def parse_image_states(response: dict) -> tuple[OtaImageState, ...]:
    values = response.get("images")
    if not isinstance(values, list):
        raise OtaError("MCUboot response has no image list")
    images = []
    identities = set()
    for value in values:
        if not isinstance(value, dict):
            raise OtaError("Malformed MCUboot image state")
        slot, image = value.get("slot"), value.get("image", 0)
        version, digest = value.get("version"), value.get("hash", b"")
        flags = tuple(value.get(name, False) for name in ("active", "bootable", "confirmed", "pending"))
        if (type(slot) is not int or slot not in (0, 1) or type(image) is not int or image < 0
                or not isinstance(version, str) or not isinstance(digest, bytes)
                or any(type(flag) is not bool for flag in flags) or (image, slot) in identities):
            raise OtaError("Malformed or duplicate MCUboot image state")
        identities.add((image, slot))
        images.append(OtaImageState(slot, version, digest, *flags, image))
    return tuple(images)


def _normalize_version(version: str) -> str:
    match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:[.+](\d+))?", version)
    if match is None:
        raise OtaError(f"Invalid MCUboot version: {version}")
    major, minor, revision, build = match.groups()
    return f"{major}.{minor}.{revision}+{build or '0'}"


def verify_firmware(runtime_version: str, firmware: FirmwarePackage,
                    images: tuple[OtaImageState, ...], *, require_confirmed: bool = True) -> OtaVerifiedFirmware:
    """Apply the Android policy: identity, active slot, digest, versions and boot state."""
    active = [image for image in images if image.active]
    if len(active) != 1:
        raise OtaError("Expected exactly one active MCUboot image")
    image = active[0]
    if image.image != 0 or image.slot != 0 or not image.bootable:
        raise OtaError("Active MCUboot image is not bootable image 0, slot 0")
    if image.hash != firmware.verification_hash():
        raise OtaError("Active image hash differs from selected firmware (old image or rollback)")
    if _normalize_version(image.version) != _normalize_version(firmware.version):
        raise OtaError(f"Active MCUboot version mismatch: {image.version}")
    if firmware.runtime_version is not None:
        if runtime_version != firmware.runtime_version:
            raise OtaError(f"R1 INFO version mismatch: {runtime_version}; expected {firmware.runtime_version}")
    else:
        numeric = re.fullmatch(r"(\d+\.\d+\.\d+)(?:[.+-].*)?", runtime_version)
        if numeric is None or numeric.group(1) != _normalize_version(firmware.version).split("+")[0]:
            raise OtaError(f"R1 INFO version mismatch: {runtime_version}")
    if require_confirmed and (not image.confirmed or any(item.pending for item in images)):
        raise OtaError("Selected image is running but MCUboot boot confirmation is still pending")
    return OtaVerifiedFirmware(runtime_version, image.version, bytes(image.hash))


_LOG = logging.getLogger(__name__)


class RingOtaUpdater:
    """Own the sensor-to-maintenance handoff and one OTA operation at a time.

    ``update`` leaves the normal Ring disconnected. Reconnect explicitly after
    completion. Cancelling cannot undo bytes already uploaded or a reboot already
    accepted; use ``verify_installed`` before deciding whether to retry.
    """
    def __init__(self, ring: Any, *, on_state: Callable | None = None,
                 on_progress: Callable | None = None, on_log: Callable | None = None,
                 on_completed: Callable | None = None, on_failed: Callable | None = None,
                 recovery_timeout: float = 120.0, upload_timeout: float = 600.0,
                 request_timeout: float = 10.0, swap_delay: float = 8.0,
                 retry_delay: float = 3.0, transport_factory=None, scanner_factory=None):
        for name, value in (("recovery_timeout", recovery_timeout), ("upload_timeout", upload_timeout),
                            ("request_timeout", request_timeout)):
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be positive and finite")
        if not all(math.isfinite(value) and value >= 0 for value in (swap_delay, retry_delay)):
            raise ValueError("OTA delays must be nonnegative and finite")
        self.ring = ring
        self.on_state, self.on_progress, self.on_log = on_state, on_progress, on_log
        self.on_completed, self.on_failed = on_completed, on_failed
        self.recovery_timeout, self.upload_timeout = recovery_timeout, upload_timeout
        self.request_timeout, self.swap_delay, self.retry_delay = request_timeout, swap_delay, retry_delay
        self._transport_factory, self._scanner_factory = transport_factory, scanner_factory
        self.state: FirmwareUpdateState | None = None
        self._task: asyncio.Task | None = None
        self._last_target: FirmwareUpdateTarget | None = None
        self._maintenance_generation: int | None = None

    @property
    def is_running(self) -> bool:
        return self._task is not None and not self._task.done()

    def _callback(self, callback, *args):
        if callback is not None:
            try:
                callback(*args)
            except Exception:
                _LOG.exception("OTA callback failed")

    def _state(self, state: FirmwareUpdateState) -> None:
        self.state = state
        self._callback(self.on_state, state)

    def _log(self, message: str) -> None:
        self._callback(self.on_log, message)

    async def prepare_target(self) -> FirmwareUpdateTarget:
        self._check_capability()
        ring = self.ring
        if getattr(ring, "_firmware_maintenance", False):
            raise OtaError("Firmware maintenance is already active")
        if not ring.is_connected or ring.device_info is None or ring.device_info.hardware_revision != 2:
            raise OtaError("A connected INFO-verified R1 is required")
        generation = ring._generation
        packet = await ring._request(b"\x2d\x01", b"\x2d\x02", 5.0, generation)
        address = parse_hardware_address(packet)
        if not ring.is_connected or ring._generation != generation:
            raise OtaError("R1 connection changed while preparing firmware maintenance")
        return FirmwareUpdateTarget(ring, ring._device, address, generation, time.monotonic())

    async def update(self, firmware_file: str | Path, *, target: FirmwareUpdateTarget | None = None,
                     confirm: bool = False, min_battery: int | None = None) -> OtaVerifiedFirmware:
        """Upload, select test boot, reset, then verify the installed firmware.

        No battery percentage threshold is imposed by Android 1.15.1. A caller
        may opt into one with ``min_battery``; its reading is taken before handoff.
        """
        return await self._run(firmware_file, "update", target, confirm, min_battery)

    async def update_target(self, target_id: str, *, confirm: bool = False,
                            min_battery: int | None = None) -> OtaVerifiedFirmware:
        """Update a bundled target only when its catalog constraints are established."""
        from .catalog import bundled_firmware_path, evaluate_target
        assessment = evaluate_target(self.ring, target_id)
        if not assessment["can_update"]:
            raise OtaError(assessment["reason"])
        path = await asyncio.to_thread(bundled_firmware_path, target_id)
        return await self.update(path, confirm=confirm, min_battery=min_battery)

    async def verify_target(self, target_id: str) -> OtaVerifiedFirmware:
        """Read-only identity/active-image check of an attached target; no flashing."""
        from .catalog import bundled_firmware_path, evaluate_target
        assessment = evaluate_target(self.ring, target_id)
        if not assessment["can_verify"]:
            raise OtaError(assessment["reason"])
        path = await asyncio.to_thread(bundled_firmware_path, target_id)
        return await self.verify_installed(path)

    async def verify_installed(self, firmware_file: str | Path, *,
                               target: FirmwareUpdateTarget | None = None) -> OtaVerifiedFirmware:
        """Read-only recovery verification; never uploads, resets or confirms an image."""
        return await self._run(firmware_file, "verify", target, False, None)

    async def confirm_installed(self, firmware_file: str | Path, *,
                                target: FirmwareUpdateTarget | None = None) -> OtaVerifiedFirmware:
        """Explicitly confirm only after running identity, digest and versions match."""
        return await self._run(firmware_file, "confirm", target, True, None)

    def cancel(self) -> None:
        if self.is_running:
            self._task.cancel()

    def _check_capability(self) -> None:
        if getattr(self.ring, "capabilities", {}).get("ota") is False:
            raise UnsupportedFeatureError("ota", getattr(self.ring, "protocol_profile", None))

    async def _run(self, path, mode, target, confirm, min_battery):
        self._check_capability()
        if (self.is_running or getattr(self.ring, "_firmware_maintenance", False)
                or getattr(self.ring, "_firmware_update_owner", None) is not None):
            raise OtaError("OTA already in progress")
        self.ring._firmware_update_owner = self
        self._task = asyncio.current_task()
        failed_at = FirmwareUpdateState.VALIDATING
        self._state(failed_at)
        try:
            firmware = await asyncio.to_thread(FirmwarePackage.from_file, path)
            firmware.verification_hash()
            if not firmware.flags & _ENCRYPTED:
                firmware.verify_integrity()
            from .catalog import check_known_package_product
            if self.ring.is_connected:
                check_known_package_product(firmware, self.ring.device_info)
            else:
                # A disconnected recovery permit can only have been prepared for an R1.
                check_known_package_product(firmware, hardware_code=2)
            if mode == "update" or self.ring.is_connected:
                target = target or await self.prepare_target()
                if min_battery is not None:
                    if type(min_battery) is not int or not 0 <= min_battery <= 100:
                        raise ValueError("min_battery must be between 0 and 100")
                    battery = await self.ring.get_battery_level()
                    if battery < min_battery:
                        raise OtaError(f"R1 battery is {battery}%, below required {min_battery}%")
                if mode == "update":
                    audio = getattr(self.ring, "audio", None)
                    if audio is not None and audio.active:
                        await audio.stop()
                    if getattr(self.ring, "_imu_active", False):
                        await self.ring.stop_imu_tokens()
                    touchpad = getattr(self.ring, "touchpad", None)
                    if touchpad is not None and touchpad.stage.value in ("starting", "running"):
                        await self.ring.stop_touchpad()
                target.consume(self.ring)
            else:
                target = target or self._last_target
                if target is None or target.ring is not self.ring:
                    raise OtaError("Reconnect the R1 once to establish its INFO and hardware address")
            self._last_target = target
            self.ring._firmware_maintenance = self
            await self.ring.disconnect()
            self._maintenance_generation = self.ring._generation
            self._check_maintenance()
            self._log(f"INFO-verified R1 {target.hardware_address}; image={firmware.version}, bytes={len(firmware.image_bytes)}")
            if mode == "update":
                await asyncio.sleep(0.5)
                self._check_maintenance()
                await _with_timeout(self._upload_and_test(target, firmware), self.upload_timeout)
                if self.swap_delay:
                    await asyncio.sleep(self.swap_delay)
            self._state(FirmwareUpdateState.WAITING_FOR_ADVERTISE)
            result = await _with_timeout(self._recover(target, firmware, confirm), self.recovery_timeout)
            self._state(FirmwareUpdateState.SUCCESS)
            self._callback(self.on_completed, result.image_version)
            return result
        except asyncio.CancelledError:
            self._state(FirmwareUpdateState.CANCELLED)
            self._callback(self.on_failed, FirmwareUpdateState.CANCELLED, OtaError("OTA cancelled; verify installed firmware before retrying"))
            raise
        except Exception as error:
            failed_at = self.state or failed_at
            self._state(FirmwareUpdateState.FAILED)
            self._callback(self.on_failed, failed_at, error)
            raise
        finally:
            if getattr(self.ring, "_firmware_maintenance", None) is self:
                self.ring._firmware_maintenance = False
            if getattr(self.ring, "_firmware_update_owner", None) is self:
                self.ring._firmware_update_owner = None
            self._maintenance_generation = None
            self._task = None

    def _check_maintenance(self) -> None:
        if (getattr(self.ring, "_firmware_maintenance", None) is not self or self.ring.is_connected
                or getattr(self.ring, "_client", None) is not None
                or self.ring._generation != self._maintenance_generation):
            raise OtaError("Sensor GATT reopened or changed during firmware maintenance")

    def _transport(self, target):
        self._check_maintenance()
        if self._transport_factory is not None:
            return self._transport_factory(target.device)
        return SmpTransport(target.device, timeout=self.request_timeout)

    async def _images(self, transport):
        return parse_image_states(await transport.request(0, 1, 0))

    async def _upload_and_test(self, target, firmware):
        expected_hash = firmware.verification_hash()
        # A disconnected upload is resumed with the full-file SHA and off=0 handshake.
        for attempt in range(4):
            try:
                async with self._transport(target) as transport:
                    await transport.identity(target.hardware_address)
                    images = await self._images(transport)
                    active = [image for image in images if image.active]
                    if len(active) != 1 or active[0].slot != 0 or active[0].image != 0 or not active[0].bootable:
                        raise OtaError("Cannot establish the currently active MCUboot slot")
                    if active[0].hash == expected_hash:
                        self._log("Selected firmware is already active; verifying its boot state")
                        return
                    if any(image.pending and image.hash != expected_hash for image in images):
                        raise OtaError("A different firmware image is pending; verify its boot state before another update")
                    if not active[0].confirmed:
                        raise OtaError("Current running firmware is unconfirmed; confirm or recover it before updating")
                    secondary = [image for image in images if image.slot == 1 and image.image == 0 and image.hash == expected_hash]
                    if not secondary:
                        self._state(FirmwareUpdateState.UPLOADING)
                        await self._upload(transport, firmware)
                        images = await self._images(transport)
                        secondary = [image for image in images if image.slot == 1 and image.image == 0 and image.hash == expected_hash]
                    if len(secondary) != 1 or not secondary[0].bootable:
                        raise OtaError("Uploaded image digest is absent from bootable MCUboot slot 1")
                    if _normalize_version(secondary[0].version) != _normalize_version(firmware.version):
                        raise OtaError("Uploaded image version differs from the selected firmware")
                    self._state(FirmwareUpdateState.TESTING)
                    selected = parse_image_states(await transport.request(2, 1, 0, {"hash": expected_hash, "confirm": False}))
                    if not any(image.image == 0 and image.slot == 1 and image.hash == expected_hash and image.pending for image in selected):
                        raise OtaError("MCUboot did not mark the selected secondary image pending")
                    self._state(FirmwareUpdateState.RESETTING)
                    try:
                        await transport.request(2, 0, 5)
                    except (ConnectionError, asyncio.TimeoutError):
                        self._log("Reset acknowledgement was lost; verifying reboot outcome without resending reset")
                    return
            except (ConnectionError, asyncio.TimeoutError):
                if attempt == 3:
                    raise
                self._log(f"SMP upload connection interrupted; resuming attempt {attempt + 2}/4")
                await asyncio.sleep(self.retry_delay)

    async def _upload(self, transport, firmware):
        maximum = 244
        try:
            parameters = await transport.request(0, 0, 6)
            if type(parameters.get("buf_size")) is int and parameters["buf_size"] >= 128:
                maximum = min(parameters["buf_size"], 512)
        except SmpCommandError:
            pass  # Older MCUmgr servers do not implement the optional parameters command.
        data = firmware.image_bytes
        digest = hashlib.sha256(data).digest()
        offset, stalls = 0, 0
        while offset < len(data):
            self._check_maintenance()
            metadata = {"off": offset}
            if offset == 0:
                metadata.update({"len": len(data), "sha": digest, "image": 0})
            size = min(len(data) - offset, maximum)
            while size and len(encode_request(2, 1, 1, 0, {**metadata, "data": data[offset:offset + size]})) > maximum:
                size -= 1
            if size == 0:
                raise OtaError("MCUmgr buffer is too small for upload metadata")
            response = await transport.request(2, 1, 1, {**metadata, "data": data[offset:offset + size]})
            next_offset = response.get("off")
            if type(next_offset) is not int or not 0 <= next_offset <= len(data):
                raise OtaError("MCUmgr returned an invalid upload offset")
            if offset and next_offset > offset + size:
                raise OtaError("MCUmgr acknowledged bytes beyond the submitted upload chunk")
            if response.get("match") is False:
                raise OtaError("Device rejected the uploaded file SHA-256")
            stalls = stalls + 1 if next_offset <= offset else 0
            if stalls > 3:
                raise OtaError("MCUmgr upload repeatedly made no progress")
            offset = next_offset
            self._callback(self.on_progress, offset, len(data))

    async def _probe(self, target, firmware, confirm):
        async with self._transport(target) as transport:
            images = await self._images(transport)
            info = await transport.identity(target.hardware_address)
            if confirm:
                verify_firmware(info.firmware_version, firmware, images, require_confirmed=False)
                active = next(image for image in images if image.active)
                if not active.confirmed:
                    # Revalidate before every write, including retry after a lost confirmation ACK.
                    await transport.request(2, 1, 0, {"hash": firmware.verification_hash(), "confirm": True})
                    images = await self._images(transport)
            return verify_firmware(info.firmware_version, firmware, images)

    async def _recover(self, target, firmware, confirm):
        scanner = None
        last_error = None
        began = time.monotonic()
        try:
            try:
                factory = self._scanner_factory
                if factory is None:
                    from bleak import BleakScanner
                    factory = BleakScanner
                def detected(device, _advertisement):
                    locator = getattr(target.device, "address", str(target.device))
                    if device.address.lower() == locator.lower():
                        self._log("R1 advertisement seen; INFO, hardware address and image still require verification")
                scanner = factory(detection_callback=detected)
                await scanner.start()
            except Exception as error:
                self._log(f"Continuous scan unavailable; using verified device locator: {error}")
            while time.monotonic() - began < self.recovery_timeout:
                self._check_maintenance()
                try:
                    return await _with_timeout(self._probe(target, firmware, confirm), 15.0)
                except asyncio.CancelledError:
                    raise
                except Exception as error:
                    last_error = error
                    self._log(f"Firmware verification not ready: {error}")
                await asyncio.sleep(self.retry_delay)
            raise asyncio.TimeoutError(f"Post-update firmware verification timed out: {last_error or 'device unavailable'}")
        finally:
            if scanner is not None:
                try:
                    await _with_timeout(scanner.stop(), 3.0)
                except Exception:
                    _LOG.warning("OTA recovery scan cleanup failed", exc_info=True)


async def update_firmware(ring: Any, firmware_file: str | Path, *, confirm: bool = False,
                          min_battery: int | None = None, **callbacks) -> OtaVerifiedFirmware:
    """Convenience entry; retain a RingOtaUpdater instance when cancellation/recovery is needed."""
    return await RingOtaUpdater(ring, **callbacks).update(firmware_file, confirm=confirm, min_battery=min_battery)
