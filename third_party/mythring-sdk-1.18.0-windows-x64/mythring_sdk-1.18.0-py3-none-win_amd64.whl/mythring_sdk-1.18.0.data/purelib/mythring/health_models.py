"""Portable health report models; wire names retain the Android 1.15.1 schema."""
from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field, fields, replace
from enum import Enum, IntEnum
from typing import Any

from .health_protocol import HealthCapabilities, HealthRecording, HealthState


class HealthMetric(IntEnum):
    HRV = 1
    HEART_RATE = 2
    SPO2 = 3


class HealthSource(str, Enum):
    FIRMWARE = "FIRMWARE"
    ANDROID = "ANDROID"  # Kept for compatibility: host-side analysis in the original schema.


class HealthQuality(str, Enum):
    VALID = "VALID"
    INSUFFICIENT_DATA = "INSUFFICIENT_DATA"
    NON_WEAR = "NON_WEAR"
    GAP = "GAP"
    PROVISIONAL = "PROVISIONAL"


@dataclass(frozen=True)
class HealthValue:
    time_utc_ms: int
    metric: HealthMetric
    value: float | None
    unit: str
    quality: HealthQuality
    source: HealthSource
    confidence: int | None = None
    measurement_id: int | None = None
    rejection_reason: int | None = None


@dataclass(frozen=True)
class HealthRri:
    time_utc_ms: int
    milliseconds: float
    confidence: int
    segment: int


@dataclass(frozen=True)
class HealthActivity:
    start_utc_ms: int
    duration_ms: int
    candidate_steps: int
    steps: int
    locomotion_probability: float | None
    quality: HealthQuality
    window_key: str | None = None


@dataclass(frozen=True)
class HealthSleepEpoch:
    start_utc_ms: int
    stage: str | None
    probabilities: list[float] | None
    estimated: bool
    provisional: bool
    quality: HealthQuality
    duration_ms: int = 300000


@dataclass(frozen=True)
class HealthBedtime:
    start_utc_ms: int
    end_utc_ms: int


@dataclass(frozen=True)
class HealthWearEvent:
    time_utc_ms: int
    state: int


@dataclass(frozen=True)
class HealthWearStateEvent:
    time_utc_ms: int
    state: int
    retry_level: int


@dataclass(frozen=True)
class HealthTemperatureSample:
    time_utc_ms: int
    celsius: float | None
    quality: HealthQuality
    sensor_error: int


@dataclass(frozen=True)
class HealthLossRange:
    first_sequence: int
    last_sequence: int
    compacted: bool


@dataclass(frozen=True)
class HealthSyncProgress:
    recording_id: int
    received: int
    total: int
    verified: bool = False


@dataclass(frozen=True)
class HealthTiming:
    stage: str
    calls: int
    milliseconds: float


@dataclass(frozen=True)
class HealthCoverage:
    duration_ms: int
    accel_samples: int
    expected_accel_samples: int
    green_samples: int
    valid_beats: int
    valid_activity_ms: int
    observed_sleep_ms: int


@dataclass(frozen=True)
class HealthHrvSummary:
    start_utc_ms: int
    end_utc_ms: int
    beats: int
    mean_nn_ms: float
    sdnn_ms: float | None
    rmssd_ms: float | None
    pnn50_percent: float | None


@dataclass(frozen=True)
class HealthSleepSummary:
    observed_stage_minutes: dict[str, int]
    estimated_minutes: int
    provisional_minutes: int
    non_wear_minutes: int
    insufficient_minutes: int


def summarize_sleep(epochs: list[HealthSleepEpoch]) -> HealthSleepSummary:
    stages: dict[str, int] = {}
    for e in epochs:
        if not e.estimated and not e.provisional and e.quality == HealthQuality.VALID and e.stage is not None:
            stages[e.stage] = stages.get(e.stage, 0) + e.duration_ms
    return HealthSleepSummary({key: value // 60000 for key, value in stages.items()},
                              sum(e.duration_ms for e in epochs if e.estimated) // 60000,
                              sum(e.duration_ms for e in epochs if e.provisional) // 60000,
                              sum(e.duration_ms for e in epochs if e.quality == HealthQuality.NON_WEAR) // 60000,
                              sum(e.duration_ms for e in epochs if e.quality == HealthQuality.INSUFFICIENT_DATA) // 60000)


@dataclass(frozen=True)
class HealthReport:
    recording: HealthRecording
    algorithm_version: str
    values: list[HealthValue] = field(default_factory=list)
    rri: list[HealthRri] = field(default_factory=list)
    activity: list[HealthActivity] = field(default_factory=list)
    bedtimes: list[HealthBedtime] = field(default_factory=list)
    sleep: list[HealthSleepEpoch] = field(default_factory=list)
    observed_accel_samples: int = 0
    observed_green_samples: int = 0
    warnings: list[str] = field(default_factory=list)
    wear: list[HealthWearEvent] = field(default_factory=list)
    accelerometer_period_ms: int = 20
    green_period_ms: int = 10
    activity_available: bool = True
    nightly_hrv_available: bool = True
    wear_states: list[HealthWearStateEvent] = field(default_factory=list)
    wear_states_available: bool = False
    temperature: list[HealthTemperatureSample] = field(default_factory=list)
    temperature_available: bool = False

    @property
    def coverage(self) -> HealthCoverage:
        return HealthCoverage(self.recording.duration_ms, self.observed_accel_samples,
            self.recording.duration_ms // self.accelerometer_period_ms, self.observed_green_samples, len(self.rri),
            sum(row.quality == HealthQuality.VALID for row in self.activity)*20000,
            sum(row.duration_ms for row in self.sleep if row.quality == HealthQuality.VALID and not row.estimated and not row.provisional and row.stage in ("LIGHT", "DEEP", "REM")))

    @property
    def sleep_summary(self) -> HealthSleepSummary:
        return summarize_sleep(self.sleep)

    @property
    def hrv_summary(self) -> list[HealthHrvSummary]:
        if not self.nightly_hrv_available:
            return []
        groups: dict[int, list[HealthRri]] = {}
        for beat in self.rri:
            groups.setdefault(beat.segment, []).append(beat)
        output = []
        for beats in groups.values():
            mean = sum(b.milliseconds for b in beats) / len(beats)
            diffs = [b.milliseconds - a.milliseconds for a, b in zip(beats, beats[1:]) if b.time_utc_ms - a.time_utc_ms <= 2000]
            output.append(HealthHrvSummary(beats[0].time_utc_ms, beats[-1].time_utc_ms, len(beats), mean,
                math.sqrt(sum((b.milliseconds - mean) ** 2 for b in beats) / (len(beats) - 1)) if len(beats) > 1 else None,
                math.sqrt(sum(d * d for d in diffs) / len(diffs)) if len(diffs) >= 10 else None,
                100 * sum(abs(d) > 50 for d in diffs) / len(diffs) if len(diffs) >= 10 else None))
        return output

    def to_dict(self) -> dict[str, Any]:
        return _json_value(asdict(self))

    @classmethod
    def from_dict(cls, source: dict[str, Any]) -> HealthReport:
        if source.get("schema") == 1 and "algorithm" in source:
            record = source["recording"]
            def optional(row, index):
                return row[index] if len(row) > index else None
            return cls(HealthRecording(record["id"], record["status"], record["bytes"], record["start"], record["duration"], record["mode"]), source["algorithm"],
                values=[HealthValue(row[0], HealthMetric[row[1]], row[2], row[3], HealthQuality(row[4]), HealthSource(row[5]), optional(row, 6), optional(row, 7), optional(row, 8)) for row in source["values"]],
                rri=[HealthRri(*row) for row in source["rri"]],
                activity=[HealthActivity(*row[:5], HealthQuality(row[5]), optional(row, 6)) for row in source["activity"]],
                bedtimes=[HealthBedtime(*row) for row in source["bedtimes"]],
                sleep=[HealthSleepEpoch(*row[:5], HealthQuality(row[5]), row[6] if len(row) > 6 else 300000) for row in source["sleep"]],
                observed_accel_samples=source["acc"], observed_green_samples=source["green"], warnings=source["warnings"],
                wear=[HealthWearEvent(*row) for row in source.get("wear", [])],
                accelerometer_period_ms=source.get("accPeriod", 20), green_period_ms=source.get("greenPeriod", 10),
                activity_available=source.get("activityAvailable", True), nightly_hrv_available=source.get("nightlyHrvAvailable", True),
                wear_states=[HealthWearStateEvent(*row) for row in source.get("wearStates", [])], wear_states_available=source.get("wearStatesAvailable", False),
                temperature=[HealthTemperatureSample(row[0], row[1], HealthQuality(row[2]), row[3]) for row in source.get("temperature", [])],
                temperature_available=source.get("temperatureAvailable", False))
        data = dict(source)
        data["recording"] = HealthRecording(**data["recording"])
        models = {"values": HealthValue, "rri": HealthRri, "activity": HealthActivity,
                  "bedtimes": HealthBedtime, "sleep": HealthSleepEpoch, "wear": HealthWearEvent,
                  "wear_states": HealthWearStateEvent, "temperature": HealthTemperatureSample}
        for key, model in models.items():
            rows = []
            for row in data.get(key, []):
                row = dict(row)
                for attr, enum in (("quality", HealthQuality), ("source", HealthSource), ("metric", HealthMetric)):
                    if attr in row:
                        row[attr] = enum[row[attr]] if attr == "metric" and isinstance(row[attr], str) else enum(row[attr])
                rows.append(model(**row))
            data[key] = rows
        return cls(**data)


def _json_value(value):
    if isinstance(value, Enum):
        return value.name
    if isinstance(value, dict):
        return {key: _json_value(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_json_value(item) for item in value]
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


@dataclass(frozen=True)
class HealthDailySummary:
    date: str
    time_zone: str
    steps: int
    walking_seconds: int
    values: list[HealthValue]
    sleep: list[HealthSleepEpoch]
    activity_available: bool = True

    @property
    def sleep_summary(self):
        return summarize_sleep(self.sleep)
