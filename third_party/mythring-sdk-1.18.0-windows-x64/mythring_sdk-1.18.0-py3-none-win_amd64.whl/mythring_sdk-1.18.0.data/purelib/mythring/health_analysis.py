"""Health recording analysis ported from the Android 1.15.1 algorithms."""
from __future__ import annotations

import bisect
import math
import struct
from dataclasses import replace

from .health_models import *
from .health_protocol import HealthFeature, read_blocks
from .health_inference import HealthDayModel
from .health_sleep import BedtimeDetector, HealthSleepModel, bridge_boundary_gaps, cover_session, extend_edges

FEATURE_VERSION = "r1-auto-features14-v14-heart-candidates"
DAY_VERSION = "r1-auto-features16-v14-heart-candidates"
RF12_VERSION = "r1-auto-features18-v1-rf12-fp16"
RAW_VERSION = "r1-mobile-v6-temperature-independent"
CURRENT_VERSION = "r1-current-steps15-v1-rf625-ble"
CURRENT_RF12_VERSION = "r1-current-steps18-v1-rf12-fp16"
ANALYSIS_VERSIONS = {FEATURE_VERSION, DAY_VERSION, RF12_VERSION, RAW_VERSION, CURRENT_VERSION, CURRENT_RF12_VERSION}
_DAY_MODEL, _SLEEP_MODEL = HealthDayModel(), HealthSleepModel()


def _u32(data, offset=0):
    return struct.unpack_from("<I", data, offset)[0]


def _i32(data, offset=0):
    return struct.unpack_from("<i", data, offset)[0]


def _u16(data, offset=0):
    return struct.unpack_from("<H", data, offset)[0]


def _float(data, offset=0):
    return struct.unpack_from("<f", data, offset)[0]


def policy_block(blocks):
    if not blocks or blocks[0].kind != 1:
        return None
    found = [block for block in blocks if block.kind == 6 and block.sequence == 1 and block.uptime_ms == blocks[0].uptime_ms and len(block.payload) == 5 and block.payload[0] == 30]
    return found[0] if len(found) == 1 else None


def record_mask(blocks):
    block = policy_block(blocks)
    mask = _u32(block.payload, 1) if block else 31
    if mask & ~31:
        raise ValueError("Unknown health record feature mask")
    return mask


class HealthFeatureSegment:
    def __init__(self, data: bytes, recovery_duration_ms: int | None = None, calibrated_offset: int | None = None):
        self.blocks = tuple(read_blocks(data))
        if self.blocks[0].schema != 4 or (self.blocks[-1].kind != 7 and recovery_duration_ms is None):
            raise ValueError("Incomplete feature segment")
        header = self.blocks[0].payload
        self.boot = struct.unpack_from("<Q", header, 24)[0]
        self.index, self.start, self.origin = _u32(header, 32), _u32(header, 12), _u32(header, 40)
        self.end = self.blocks[-1].uptime_ms if self.blocks[-1].kind == 7 else self.start+recovery_duration_ms
        if self.boot == 0 or not self.origin <= self.start <= self.end or self.end-self.start > 1980000:
            raise ValueError("Invalid feature segment identity/duration")
        utc = struct.unpack_from("<q", header, 4)[0]
        offset = None
        if header[38] == 1:
            if not 86400000 <= utc < 2**63-8589934592:
                raise ValueError("Invalid feature segment clock")
            offset = utc-self.start
        for block in self.blocks:
            if block.kind == 6 and len(block.payload) == 13 and block.payload[0] == 7:
                utc = struct.unpack_from("<q", block.payload, 1)[0]
                if not 86400000 <= utc < 2**63-8589934592:
                    raise ValueError("Invalid feature clock event")
                offset = utc-_u32(block.payload, 9)
        if calibrated_offset is not None:
            if not 0 < calibrated_offset < 2**63-8589934592:
                raise ValueError("Invalid calibrated health clock")
            offset = calibrated_offset
        self.utc_offset = offset
        self.feature_mask = record_mask(self.blocks)

    def control_boundary(self, start):
        return policy_block(self.blocks) is not None and any(block.kind == 6 and len(block.payload) == 5 and block.payload[0] == 31 and _i32(block.payload, 1) == int(start) for block in self.blocks)

    @staticmethod
    def contiguous(segments):
        return bool(segments) and all(a.boot == segments[0].boot and b.boot == a.boot and b.index == a.index+1 and b.start == a.end and b.origin == a.origin and b.feature_mask == a.feature_mask and not a.control_boundary(False) and not b.control_boundary(True) for a, b in zip(segments, segments[1:]))


def day_activity(block, offset, boot, power_test=False, predict=None):
    p = block.payload
    identity, start, duration, candidate = struct.unpack_from("<IIIi", p, 8)
    if block.kind != 13 or block.schema != 4 or start != block.uptime_ms or duration != 20000 or not 0 <= candidate <= 2000:
        raise ValueError("Invalid day-step window")
    key = f"{boot}:{identity}"
    if power_test:
        return HealthActivity(offset+start, 20000, candidate, 0, None, HealthQuality.GAP, key)
    if block.flags != 0 or p[6] != 0:
        return HealthActivity(offset+start, 20000, candidate, 0, None, HealthQuality.INSUFFICIENT_DATA, key)
    features = list(struct.unpack_from("<12e" if len(p) == 48 else "<42f", p, 24))
    if not all(math.isfinite(value) for value in features) or (len(features) == 12 and not all(0 <= value <= 1 for value in features)):
        raise ValueError("Invalid RF step features")
    if len(features) == 42:
        features[0], features[12] = -features[0], -features[12]
    probability = (predict or _DAY_MODEL.predict)(features)
    if not math.isfinite(probability) or not 0 <= probability <= 1:
        raise ValueError("Invalid RF prediction")
    return HealthActivity(offset+start, 20000, candidate, candidate if probability > .5 else 0, probability, HealthQuality.VALID, key)


def decode_heart_candidates(payload, time):
    extended = len(payload) == 26
    identity = _u32(payload, 14) if 0 < payload[13] < 128 else None
    heart, reason = _float(payload), _u16(payload, 8)
    candidate = _float(payload, 18) if extended else math.nan
    confidence = payload[22] if extended and math.isfinite(candidate) else None
    candidate_reason = _u16(payload, 24) if extended else 0
    result = []
    if reason == 0 and math.isfinite(heart) and heart > 0:
        result.append(HealthValue(time, HealthMetric.HEART_RATE, heart, "bpm", HealthQuality.VALID, HealthSource.FIRMWARE, confidence if candidate == heart else None, identity, 0 if extended else None))
    elif extended:
        result.append(HealthValue(time, HealthMetric.HEART_RATE, candidate if math.isfinite(candidate) else None, "bpm", HealthQuality.PROVISIONAL if math.isfinite(candidate) else HealthQuality.INSUFFICIENT_DATA, HealthSource.FIRMWARE, confidence, identity, reason | candidate_reason))
    hrv = _float(payload, 4)
    if _u16(payload, 10) == 0 and math.isfinite(hrv) and hrv >= 0:
        result.append(HealthValue(time, HealthMetric.HRV, hrv, "ms", HealthQuality.VALID, HealthSource.FIRMWARE, measurement_id=identity))
    return result


def reconcile_wear(segments):
    offset = next((segment.utc_offset for segment in reversed(segments) if segment.utc_offset is not None), 0)
    beds, motion, temperatures, events, removed = {}, {}, {}, {}, set()
    for segment in segments:
        if segment.blocks[0].payload[39]:
            continue
        for block in segment.blocks:
            p, t = block.payload, block.uptime_ms
            if block.kind == 12:
                beds[t] = block
            elif block.kind == 8:
                motion[t] = block
                if _u16(p, 28) > 0:
                    removed.add(t)
            elif block.kind == 4 and block.flags == 0 and _i32(p, 4) == 0:
                temperatures[t] = _i32(p)
            elif block.kind == 6:
                if p[0] == 19:
                    events[t] = _i32(p, 1)
                    if events[t] & 255 == 0:
                        removed.add(t)
                elif p[0] == 3 and _i32(p, 1) == 2:
                    removed.add(t)
    promoted, derived, provisional = set(), dict(events), None
    bed_times, temp_times = sorted(beds), sorted(temperatures)
    for time, value in sorted(events.items()):
        if value & 255 == 0:
            provisional = None
        elif value & 255 == 1 and provisional is None:
            provisional = time
        elif value & 255 == 2:
            begin, provisional = provisional, None
            if begin is None or not 1 <= time-begin <= 1800000 or any(begin <= point <= time for point in removed):
                continue
            index = bisect.bisect_right(bed_times, time-30000)-1
            if index < 0:
                continue
            next_time = bed_times[index]
            if time-(next_time+30000) > 30000:
                continue
            accepted = []
            while next_time >= begin:
                bed, movement = beds.get(next_time), motion.get(next_time)
                temp_index = bisect.bisect_right(temp_times, next_time+30000)-1
                if bed is None or movement is None or temp_index < 0:
                    break
                p, mp, temperature_time = bed.payload, movement.payload, temp_times[temp_index]
                if bed.flags != 0 or p[3] not in (1, 2) or not 0 <= p[12] <= 30 or not 27 <= p[13] <= 30 or p[14] != 30 or _u16(p, 18) != 0 or not 37 <= _u16(p, 16) <= 800 or movement.flags not in (0, 1) or not all(math.isfinite(value) for value in struct.unpack_from("<6f", mp)) or _u16(mp, 28) != 0 or next_time+30000-temperature_time > 30000 or not 26000 <= temperatures[temperature_time] <= 40000:
                    break
                accepted.append(next_time)
                next_time -= 30000
            if accepted:
                promoted.update(accepted)
                derived[accepted[-1]] = 2
    return promoted, [HealthWearStateEvent(offset+time, value & 255, (value >> 8) & 255) for time, value in sorted(derived.items())]


def repair_bedtime(raw, temperatures, eligible):
    result = list(raw)
    for i in range(1, len(raw)-1):
        if raw[i] < 0 and eligible[i] and 0 <= raw[i-1] <= 30 and 0 <= raw[i+1] <= 30:
            values = temperatures[(i-1)//2:(i+1)//2+1]
            if all(2600 <= value <= 4000 for value in values) and max(values)-min(values) <= 100:
                result[i] = max(raw[i-1], raw[i+1])
    return result


def analyze_current_steps(data, record, expected_boot, offset):
    rows = tuple(read_blocks(data))
    header = rows[0].payload
    if record.mode != 7 or record.status != 0 or len(data) != record.bytes or rows[0].schema != 4 or struct.unpack_from("<Q", header, 24)[0] != expected_boot or expected_boot == 0 or not 15 <= _u16(header, 36) <= 18 or struct.unpack_from("<q", header, 4)[0] != record.start_utc_ms:
        raise ValueError("Invalid current-step snapshot")
    enabled, diagnostic = bool(record_mask(rows) & 1), header[39] != 0
    warnings = ["CURRENT_STEP_SNAPSHOT"]
    if not enabled:
        warnings.append("HEALTH_DISABLED_STEPS_ACTIVITY")
    if diagnostic:
        warnings.append("POWER_DIAGNOSTIC")
    if offset is None:
        warnings.append("TIME_UNKNOWN")
    activity = [day_activity(row, offset, expected_boot) for row in rows if row.kind == 13] if enabled and not diagnostic and offset is not None else []
    if len({row.window_key for row in activity}) != len(activity):
        raise ValueError("Duplicate current step window")
    return HealthReport(record, CURRENT_RF12_VERSION if any(row.kind == 13 and len(row.payload) == 48 for row in rows) else CURRENT_VERSION,
        activity=activity, warnings=warnings, accelerometer_period_ms=160,
        activity_available=enabled and not diagnostic and offset is not None, nightly_hrv_available=False)


def _outside_bedtime_awake(epochs, periods, evidence, context_ready, finalized_until):
    if not context_ready:
        return epochs
    boundaries = [point for bed in periods+evidence for point in (bed.start_utc_ms, bed.end_utc_ms)]+[finalized_until]
    result = []
    for epoch in epochs:
        if epoch.stage is not None or epoch.quality != HealthQuality.INSUFFICIENT_DATA or epoch.estimated:
            result.append(epoch)
            continue
        start, end = epoch.start_utc_ms, epoch.start_utc_ms+epoch.duration_ms
        cuts = sorted({start, end, *(point for point in boundaries if start < point < end)})
        for a, b in zip(cuts, cuts[1:]):
            awake = not any(period.start_utc_ms < b and period.end_utc_ms > a for period in periods) and any(row.start_utc_ms <= a and row.end_utc_ms >= b for row in evidence)
            provisional = b > finalized_until if awake else epoch.provisional
            result.append(replace(epoch, start_utc_ms=a, duration_ms=b-a, stage="AWAKE" if awake else epoch.stage,
                probabilities=None if awake else epoch.probabilities, provisional=provisional,
                quality=(HealthQuality.PROVISIONAL if provisional else HealthQuality.VALID) if awake else epoch.quality))
    return result


def analyze_features(segments, record, context=None):
    import numpy as np
    from .health_temperature import TemperatureReading, decode_temperature
    if not HealthFeatureSegment.contiguous(segments):
        raise ValueError("Discontinuous health feature group")
    first, last = segments[0], segments[-1]
    mask = first.feature_mask
    enabled = lambda feature: bool(mask & int(feature))
    sleep_enabled = enabled(HealthFeature.SLEEP)
    if not 0 <= last.end-first.start <= 86400000:
        raise ValueError("Health feature group exceeds 24 hours")
    offset = next((segment.utc_offset for segment in reversed(segments) if segment.utc_offset is not None), None)
    if offset is None:
        return HealthReport(record, FEATURE_VERSION, warnings=["TIME_UNKNOWN"], accelerometer_period_ms=160, green_period_ms=40,
            activity_available=False, nightly_hrv_available=False, wear_states_available=True)
    start, end = offset+first.start, offset+last.end
    if start < 86400000 or end < start:
        raise ValueError("Invalid health UTC interval")
    base = first.origin+(first.start-first.origin)//30000*30000
    count = (last.end-base+29999)//30000
    motion = np.full((count, 6), np.nan, np.float32)
    motion_times = np.asarray([offset+base+(i+1)*30000 for i in range(count)], dtype=np.int64)
    temp = np.full(count, np.nan, np.float32)
    seconds = [-1]*((count+1)//2*2)
    non_wear, eligible = [False]*count, [False]*len(seconds)
    temperatures, beat_times, ibi, bursts, burst_times, activity, readings = {}, [], [], [], [], [], []
    supports_day = any(_u16(segment.blocks[0].payload, 36) >= 15 and segment.blocks[0].payload[39] == 0 for segment in segments)
    values, rri, wear, wear_states = [], [], [], []
    promoted, reconciled_states = reconcile_wear(segments)
    warnings = {f"HEALTH_DISABLED_{feature.name}" for feature in HealthFeature if not enabled(feature)}
    if promoted:
        warnings.add("WEAR_PROVISIONAL_CONFIRMED")
    if context:
        warnings.update(context.warnings)
    complete = context is not None and first.boot in context.finalized_boots
    if complete:
        warnings.add("SLEEP_PREVIOUS_BOOT_FINALIZED")
    greens, burst_index, last_beat = 0, 0, -1
    for segment in segments:
        power_test = segment.blocks[0].payload[39] != 0
        for block in segment.blocks:
            p, t = block.payload, offset+block.uptime_ms
            if power_test:
                warnings.add("POWER_DIAGNOSTIC")
                if block.kind == 13:
                    activity.append(day_activity(block, offset, segment.boot, True))
                continue
            slot = (block.uptime_ms-base)//30000 if block.uptime_ms >= base else -1
            if block.kind == 4:
                mc, error = struct.unpack_from("<ii", p)
                readings.append(TemperatureReading(t, mc, error, block.flags))
                if block.flags == 0 and error == 0 and 1 <= mc <= 60000:
                    temperatures[t] = float(np.float32(mc)/np.float32(1000))
            elif block.kind == 5:
                if 1 <= p[2] <= 100 and p[3] == 1:
                    values.append(HealthValue(t, HealthMetric.SPO2, float(p[2]), "%", HealthQuality.VALID, HealthSource.FIRMWARE,
                                              measurement_id=_u32(p, 8) if p[6] == 1 else None))
            elif block.kind == 6:
                code = p[0]
                if code == 3:
                    wear.append(HealthWearEvent(t, _i32(p, 1)))
                if code == 19:
                    value = _i32(p, 1)
                    if value & 255 in (0, 1, 2):
                        wear_states.append(HealthWearStateEvent(t, value & 255, (value >> 8) & 255))
                if code in (2, 9, 10, 11, 12, 13, 14):
                    warnings.add("FEATURE_GAP")
            elif block.kind == 8 and 0 <= slot < count:
                if block.flags == 0 or block.uptime_ms in promoted:
                    motion[slot] = struct.unpack_from("<6f", p)
                non_wear[slot] = _u16(p, 28) > 0
            elif block.kind == 9:
                if t <= last_beat:
                    raise ValueError("Non-increasing beat timestamps")
                last_beat = t
                value = _float(p)
                valid = p[4] == 1 and math.isfinite(value) and 350 <= value <= 1800
                beat_times.append(t)
                ibi.append([value, math.nan, 1. if valid else 0.])
                if valid:
                    rri.append(HealthRri(t, value, 100, burst_index))
                else:
                    burst_index += 1
            elif block.kind == 10:
                greens += _u16(p, 80)
                burst_index += 1
                burst_times.append(offset+(_u32(p, 72)+_u32(p, 76))//2)
                bursts.append(list(struct.unpack_from("<18f", p)) if block.flags == 0 else [math.nan]*18)
            elif block.kind == 11:
                values.extend(decode_heart_candidates(p, t))
            elif block.kind == 13:
                activity.append(day_activity(block, offset, segment.boot))
            elif block.kind == 12 and 0 <= slot < count:
                if (p[3] & 1 or block.uptime_ms in promoted) and 0 <= p[12] <= 30:
                    seconds[slot] = p[12]
                eligible[slot] = p[3] == 0 and p[14] == 30 and 24 <= p[13] <= 26 and _u16(p, 18) == 0 and 37 <= _u16(p, 16) <= 800
    temp_times = sorted(temperatures)
    for i, t in enumerate(motion_times):
        index = bisect.bisect_right(temp_times, t)-1
        if index >= 0 and t-temp_times[index] <= 30000:
            temp[i] = temperatures[temp_times[index]]
    minute_temperatures = [math.floor(float(np.float32(temp[min(i*2+1, count-1)]*np.float32(100)))+.5) if math.isfinite(temp[min(i*2+1, count-1)]) else 0 for i in range(len(seconds)//2)]
    for i, off in enumerate(non_wear):
        if off:
            seconds[i] = 31
    boundary = repair_bedtime(seconds, minute_temperatures, eligible)
    if bridge_boundary_gaps(boundary, minute_temperatures) != boundary:
        warnings.add("BEDTIME_BOUNDARY_GAP_BRIDGED")
    if not sleep_enabled:
        periods = []
    elif context:
        periods = [HealthBedtime(max(start, p.start_utc_ms), min(end, p.end_utc_ms)) for p in context.periods if min(end, p.end_utc_ms) > max(start, p.start_utc_ms)]
    elif any(value > 0 for value in minute_temperatures):
        periods = [HealthBedtime(max(start, a), min(end, b)) for a, b in BedtimeDetector.detect(offset+base, boundary, minute_temperatures).periods if min(end, b) > max(start, a)]
    else:
        periods = []
    short_candidate = sleep_enabled and not periods and ((context.end-context.start) if context else end-start) < 10800000
    analysis_periods = [HealthBedtime(start, end)] if short_candidate else periods
    def has_non_wear(a, b):
        return any(t-30000 < b and t > a and non_wear[i] for i, t in enumerate(motion_times))
    sleep = _SLEEP_MODEL.run(start, end, motion, motion_times, ibi, beat_times, temp, motion_times, bursts, burst_times, analysis_periods, complete, has_non_wear) if analysis_periods and HealthSleepModel.can_run(start, end, count, len(beat_times), len(temp)) else []
    with_edges = extend_edges(start, end, sleep, periods, has_non_wear)
    if len(with_edges) > len(sleep):
        warnings.add("SLEEP_PARTIAL_EDGE_ESTIMATE")
    sleep = with_edges
    if short_candidate:
        warnings.add("BEDTIME_CONTEXT_PENDING")
        sleep = [replace(epoch, provisional=True, quality=epoch.quality if epoch.stage is None else HealthQuality.PROVISIONAL) for epoch in sleep]
    sleep = cover_session(start, end, sleep, has_non_wear) if sleep_enabled else []
    evidence = []
    for i, t in enumerate(motion_times):
        if seconds[i] >= 0 and math.isfinite(temp[i]) and np.isfinite(motion[i]).all() and not non_wear[i]:
            a, b = max(start, int(t)-30000), min(end, int(t))
            if b <= a:
                continue
            if evidence and evidence[-1].end_utc_ms == a:
                evidence[-1] = HealthBedtime(evidence[-1].start_utc_ms, b)
            else:
                evidence.append(HealthBedtime(a, b))
    sleep = _outside_bedtime_awake(sleep, periods, evidence, not short_candidate, end if complete else end-900000)
    if sleep_enabled and not any(epoch.stage is not None for epoch in sleep):
        warnings.add("SLEEP_DATA_INSUFFICIENT")
    if any(epoch.estimated and epoch.probabilities is not None for epoch in sleep):
        warnings.add("SLEEP_REDUCED_INPUT_ESTIMATE")
    if promoted:
        wear_states = reconciled_states
    temperatures_out = decode_temperature(readings, wear_states, wear, lambda t: has_non_wear(t, t+1))
    version = RF12_VERSION if any(block.kind == 13 and len(block.payload) == 48 for segment in segments for block in segment.blocks) else DAY_VERSION if supports_day else FEATURE_VERSION
    if mask != 31:
        version += "-scenes1"
    includes_heart = lambda t: enabled(HealthFeature.HEART_HRV) or sleep_enabled and any(bed.start_utc_ms <= t < bed.end_utc_ms for bed in periods)
    return HealthReport(record, version,
        values=[value for value in values if (enabled(HealthFeature.SPO2) if value.metric == HealthMetric.SPO2 else includes_heart(value.time_utc_ms))],
        rri=[row for row in rri if includes_heart(row.time_utc_ms)], activity=activity if enabled(HealthFeature.STEPS_ACTIVITY) else [],
        bedtimes=periods, sleep=sleep, observed_green_samples=greens, warnings=sorted(warnings), wear=wear,
        accelerometer_period_ms=160, green_period_ms=40, activity_available=supports_day and enabled(HealthFeature.STEPS_ACTIVITY),
        nightly_hrv_available=sleep_enabled and any(_u16(segment.blocks[0].payload, 36) >= 16 for segment in segments),
        wear_states=list({event.time_utc_ms: event for event in wear_states}.values()), wear_states_available=True,
        temperature=temperatures_out if enabled(HealthFeature.SKIN_TEMPERATURE) else [], temperature_available=True)


def analyze_raw(data, record, manual_hrv=False):
    import numpy as np
    from . import health_native
    from .health_temperature import TemperatureReading, decode_temperature
    blocks = tuple(read_blocks(data, require_end=record.complete))
    header = blocks[0]
    if record.mode != 6 or header.schema not in (2, 3) or header.payload[:4] != bytes((6, header.schema, 16, 1)):
        raise ValueError("Unsupported raw health analysis profile")
    utc, uptime = struct.unpack_from("<qI", header.payload, 4)
    if utc <= 0 or utc != record.start_utc_ms:
        raise ValueError("Raw recording UTC does not match metadata")
    end, acc_count, green_count = utc, 0, 0
    starts, green_starts, temperatures, wear = set(), set(), {}, {}
    readings, raw_vitals, attempted, warnings = [], [], set(), set()
    def timestamp(block):
        relative = (block.uptime_ms-uptime) & 0xFFFFFFFF
        if relative > 57610000:
            raise ValueError("Recording timestamp out of bounds")
        return utc+relative
    for block in blocks:
        p, t = block.payload, timestamp(block)
        end = max(end, t+max(0, block.count-1)*block.period_ms)
        if block.kind == 2:
            acc_count += block.count
        elif block.kind == 3:
            green_count += block.count
        elif block.kind == 4:
            mc, error = struct.unpack_from("<ii", p)
            temperatures[t] = float(np.float32(mc)/np.float32(1000)) if error == 0 and 1 <= mc <= 60000 else math.nan
            readings.append(TemperatureReading(t, mc, error, block.flags))
        elif block.kind == 5:
            raw_vitals.append((t, block))
        elif block.kind == 6:
            code, value = p[0], _i32(p, 1)
            if code == 4:
                starts.add(t)
                if value == 1:
                    green_starts.add(t)
                if value in (1, 2, 3):
                    attempted.add(HealthMetric(value))
            elif code == 3:
                if value not in (0, 1, 2):
                    raise ValueError("Unknown wear state")
                wear[t] = value
            if code in (1, 2):
                warnings.add("SAMPLE_GAP")
            if code == 6:
                warnings.add("CLOCK_CHANGED_SESSION_ANCHOR_RETAINED")
        elif block.kind == 7 and _i32(p, 4) != 0:
            warnings.add("CAPTURE_ERROR")
    ended = blocks[-1].kind == 7
    if not record.complete:
        warnings.add("INCOMPLETE_RECORDING")
    if record.status == 2 and not ended:
        warnings.add("RECOVERED_AFTER_RESTART")
    analysis_wear = dict(wear)
    wear_times = sorted(wear)
    for i, time in enumerate(wear_times[:-1]):
        following = wear_times[i+1]
        if wear[time] == 2 and wear[following] == 0 and following in starts and 0 <= following-time <= 250:
            analysis_wear[time] = 0
    if analysis_wear != wear:
        warnings.add("STARTUP_WEAR_TRANSIENT_IGNORED")
    def wear_at(t):
        index = bisect.bisect_right(wear_times, t)-1
        if index < 0:
            return 0
        previous = wear_times[index]
        value = analysis_wear[previous]
        return value if value == 2 or t-previous <= 30000 else 0
    def non_wear(a, b):
        return wear_at(a) == 2 or any(a <= time < b and value == 2 for time, value in analysis_wear.items())
    acceleration_times, xyz, segments, acc_segment = [], [], [], 0
    for block in blocks:
        if block.kind != 2:
            continue
        base = timestamp(block)
        for i, sample in enumerate(struct.iter_unpack("<hhh", block.payload)):
            t = base+i*block.period_ms
            if acceleration_times:
                if t <= acceleration_times[-1]:
                    raise ValueError("Duplicate accelerometer sample")
                if abs(t-acceleration_times[-1]-640) > 320:
                    acc_segment += 1
            acceleration_times.append(t)
            xyz.append(sample)
            segments.append(acc_segment)
    def window(a, b):
        low, high = bisect.bisect_left(acceleration_times, a), bisect.bisect_left(acceleration_times, b)
        if high-low < 38 or acceleration_times[high-1]-acceleration_times[low] < 24000 or segments[low] != segments[high-1]:
            return None
        return np.asarray(xyz[low:high], dtype=np.int16), acceleration_times[high-1]-acceleration_times[low]
    def sd(a, b):
        selected = window(a, b)
        if selected is None:
            return math.nan
        values = np.sqrt(np.sum(selected[0].astype(np.float64)**2, axis=1))/2048
        return float(np.float32(math.sqrt(max(0., float(np.mean(values*values))-float(np.mean(values))**2))))
    grid = (utc+29999)//30000*30000
    epochs = max(0, (end-grid)//30000+1)
    motion_times = np.asarray([grid+i*30000 for i in range(epochs)], dtype=np.int64)
    motion, temp = np.full((epochs, 6), np.nan, np.float32), np.full(epochs, np.nan, np.float32)
    temp_times = sorted(temperatures)
    for i, t in enumerate(motion_times):
        selected = window(int(t)-30000, int(t))
        if selected is not None:
            motion[i] = health_native.motion_lowrate(selected[0], selected[1])[:6]
        index = bisect.bisect_right(temp_times, t)-1
        if index >= 0 and t-temp_times[index] <= 30000:
            temp[i] = temperatures[temp_times[index]]
    rri, all_beat_times, all_ibi, burst_times, burst_features = [], [], [], [], []
    raw, green_times, last_green, segment, confirmed = [], [], -1, 0, False
    def finish_burst():
        nonlocal segment, confirmed
        if confirmed and len(raw) >= 300 and green_times[-1]-green_times[0] >= 24000:
            deviation = sd(green_times[0], green_times[-1]+80)
            if math.isfinite(deviation):
                output = health_native.ppg_lowrate(raw, green_times, deviation)
                burst_times.append(green_times[0]+len(raw)*40)
                burst_features.append(output[:18].astype(np.float32).tolist())
                for j in range(18, len(output), 3):
                    t = int(output[j])
                    if all_beat_times and t <= all_beat_times[-1]:
                        raise ValueError("Non-increasing extracted beat times")
                    all_beat_times.append(t)
                    all_ibi.append([float(np.float32(output[j+1])), math.nan, float(np.float32(output[j+2]))])
                    if output[j+2] > 0:
                        rri.append(HealthRri(t, float(output[j+1]), 100, segment))
                    else:
                        segment += 1
        segment += 1
        confirmed = False
        raw.clear()
        green_times.clear()
    green_start_times = sorted(green_starts)
    for block in blocks:
        if block.kind != 3:
            continue
        base = timestamp(block)
        for i, (value, _, flag) in enumerate(struct.iter_unpack("<iiB", block.payload)):
            t = base+i*block.period_ms
            begins_run = last_green < 0 or abs(t-last_green-80) > 40
            if begins_run or len(raw) == 375:
                finish_burst()
            if flag & 1 or wear_at(t) == 2:
                finish_burst()
            elif flag & 3 == 2:
                confirmed = True
                raw.append(value)
                green_times.append(t)
            else:
                if confirmed:
                    finish_burst()
                index = bisect.bisect_right(green_start_times, t+80)-1
                startup = index >= 0 and t-green_start_times[index] <= 1000
                if raw or begins_run and startup:
                    raw.append(value)
                    green_times.append(t)
            last_green = t
    finish_burst()
    values, last_updates = [], {}
    for t, block in raw_vitals:
        if block.flags != 1:
            continue
        p, mode, update = block.payload, block.payload[0], _u32(block.payload, 4)
        previous = last_updates.get(mode)
        if update == 0 or previous is not None and previous[0] == update and t-previous[1] < 2000:
            continue
        last_updates[mode] = (update, t)
        v = struct.unpack_from("<"+"i"*((len(p)-8)//4), p, 8)
        if mode == 2 and len(v) == 10:
            valid = wear_at(t) == 1 and v[0] != 0 and v[3] > 0 and v[1] > 0
            values.append(HealthValue(t, HealthMetric.HEART_RATE, float(v[1]) if valid else None, "bpm", HealthQuality.VALID if valid else HealthQuality.NON_WEAR if wear_at(t) == 2 else HealthQuality.INSUFFICIENT_DATA, HealthSource.FIRMWARE, v[4]))
        if mode == 3 and len(v) == 13:
            valid = wear_at(t) == 1 and v[12] != 0 and v[1] > 0 and v[6] == 0 and v[2] >= 35 and 1 <= v[0] <= 1000000
            values.append(HealthValue(t, HealthMetric.SPO2, v[0]/10000 if valid else None, "%", HealthQuality.VALID if valid else HealthQuality.NON_WEAR if wear_at(t) == 2 else HealthQuality.INSUFFICIENT_DATA, HealthSource.FIRMWARE, v[2]))
    if manual_hrv:
        by_segment = {}
        for beat in rri:
            by_segment.setdefault(beat.segment, []).append(beat)
        for beats in by_segment.values():
            differences = [(b.milliseconds-a.milliseconds)**2 for a, b in zip(beats, beats[1:]) if b.time_utc_ms-a.time_utc_ms <= 2000]
            valid = len(differences) >= 10
            values.append(HealthValue(beats[-1].time_utc_ms, HealthMetric.HRV, math.sqrt(sum(differences)/len(differences)) if valid else None, "ms", HealthQuality.VALID if valid else HealthQuality.INSUFFICIENT_DATA, HealthSource.ANDROID, min(beat.confidence for beat in beats)))
    if green_count > 0 and manual_hrv:
        attempted.add(HealthMetric.HRV)
    if not manual_hrv:
        attempted.discard(HealthMetric.HRV)
    for metric in attempted:
        if not any(value.metric == metric for value in values):
            values.append(HealthValue(end, metric, None, {HealthMetric.HEART_RATE: "bpm", HealthMetric.SPO2: "%", HealthMetric.HRV: "ms"}[metric],
                HealthQuality.NON_WEAR if 2 in wear.values() and 1 not in wear.values() else HealthQuality.INSUFFICIENT_DATA,
                HealthSource.ANDROID if metric == HealthMetric.HRV else HealthSource.FIRMWARE))
    bedtimes = [HealthBedtime(utc, end)]
    observed = _SLEEP_MODEL.run(utc, end, motion, motion_times, all_ibi, all_beat_times, temp, motion_times, burst_features, burst_times, bedtimes, record.complete, non_wear)
    sleep = cover_session(utc, end, observed, non_wear)
    if not any(epoch.stage is not None for epoch in sleep):
        warnings.add("SLEEP_DATA_INSUFFICIENT")
    wear_events = [HealthWearEvent(t, value) for t, value in sorted(wear.items())]
    return HealthReport(replace(record, duration_ms=end-utc), RAW_VERSION, values=sorted(values, key=lambda value: value.time_utc_ms),
        rri=rri, bedtimes=bedtimes, sleep=sleep, observed_accel_samples=acc_count, observed_green_samples=green_count,
        warnings=sorted(warnings), wear=wear_events, accelerometer_period_ms=640, green_period_ms=80,
        activity_available=False, nightly_hrv_available=manual_hrv,
        temperature=decode_temperature(readings, [], wear_events), temperature_available=True)


def analyze_recording(store, record, manual_hrv=False):
    if record.mode != 7:
        return analyze_raw(store.raw(record.id).read_bytes(), record, manual_hrv)
    from .health_continuity import detect_context, offset, select
    candidates = []
    for row in store.recordings():
        if row.mode != 7 or row.status not in (1, 2, 3) or not store.is_verified(row):
            continue
        data = store.raw(row.id).read_bytes()
        segment = HealthFeatureSegment(data, row.duration_ms if row.status in (2, 3) else None)
        if store.clock(segment.boot) is not None:
            segment.utc_offset = store.clock(segment.boot)
        candidates.append((row, segment))
    target = next(segment for row, segment in candidates if row.id == record.id)
    chosen = select([segment for _, segment in candidates], target)
    context = detect_context(chosen) if len(chosen) > 1 else None
    by_segment = {segment: row for row, segment in candidates}
    requested = None
    for segments in chosen:
        combined = analyze_features(segments, record, context)
        utc_offset = offset(segments) or 0
        for segment in segments:
            row = by_segment[segment]
            start, end = utc_offset+segment.start, utc_offset+segment.end
            beds = [bed for bed in context.periods if bed.start_utc_ms < end and bed.end_utc_ms > start] if context else [HealthBedtime(max(start, bed.start_utc_ms), min(end, bed.end_utc_ms)) for bed in combined.bedtimes if min(end, bed.end_utc_ms) > max(start, bed.start_utc_ms)]
            report = replace(combined, recording=row,
                activity=[v for v in combined.activity if start <= v.start_utc_ms < end],
                activity_available=bool(segment.feature_mask & 1) and _u16(segment.blocks[0].payload, 36) >= 15 and segment.blocks[0].payload[39] == 0,
                values=[v for v in combined.values if start <= v.time_utc_ms < end],
                temperature=[v for v in combined.temperature if start <= v.time_utc_ms < end],
                rri=[v for v in combined.rri if start <= v.time_utc_ms < end],
                wear=[v for v in combined.wear if start <= v.time_utc_ms < end],
                wear_states=[v for v in combined.wear_states if start <= v.time_utc_ms < end], bedtimes=beds,
                sleep=[replace(v, start_utc_ms=max(start, v.start_utc_ms), duration_ms=min(end, v.start_utc_ms+v.duration_ms)-max(start, v.start_utc_ms)) for v in combined.sleep if min(end, v.start_utc_ms+v.duration_ms) > max(start, v.start_utc_ms)],
                observed_green_samples=sum(_u16(block.payload, 80) for block in segment.blocks if block.kind == 10))
            saved = store.save_report(report)
            if row.id == record.id:
                requested = saved
    if requested is None:
        raise ValueError("Requested health recording was not analyzed")
    return requested
