"""Desktop C ABI for the unchanged 1.15.1 health signal-processing sources."""
from __future__ import annotations

import ctypes as C
from functools import lru_cache
from importlib.resources import files
import sys
import numpy as np


@lru_cache(maxsize=1)
def _library():
    names = {'darwin': 'libhealth_macos.dylib', 'win32': 'health_windows_x64.dll'}
    if sys.platform not in names:
        raise OSError('Native health analysis requires macOS or Windows x64')
    lib = C.CDLL(str(files('mythring').joinpath('native', names[sys.platform])))
    i16, i32, i64, f32, f64 = [np.ctypeslib.ndpointer(dtype=dtype, flags='C_CONTIGUOUS') for dtype in (np.int16,np.int32,np.int64,np.float32,np.float64)]
    signatures = {
        'ring_hrv': [i32,i32,C.c_int,f64,C.c_int],
        'ring_hrv_reference': [i32,i32,C.c_int,i32],
        'ring_activity': [i16,C.c_int,f32],
        'ring_motion': [i16,C.c_int,f32],
        'ring_motion_lowrate': [i16,C.c_int,C.c_int,f32],
        'ring_ppg': [i32,C.c_int,C.c_float,f32],
        'ring_ppg_lowrate': [i32,i64,C.c_int,C.c_float,f64],
    }
    for name, signature in signatures.items():
        fn=getattr(lib,name);fn.argtypes=signature;fn.restype=C.c_int
    return lib


def _integers(value,dtype):
    raw=np.asarray(value)
    bounds=np.iinfo(dtype)
    if not np.isfinite(raw).all() or np.any(raw!=np.trunc(raw)) or np.any(raw<bounds.min) or np.any(raw>bounds.max):
        raise ValueError('Sensor samples must be finite integers within the wire range')
    return np.ascontiguousarray(raw,dtype=dtype).reshape(-1)


def _xyz(value):
    result=_integers(value,np.int16)
    if len(result)%3:raise ValueError('XYZ samples must contain three axes per frame')
    return result


def _finish(result,out):
    if result<0:raise ValueError('Invalid native health input size or timestamp span')
    return out[:result].copy()


def hrv(green,acceleration):
    g=_integers(green,np.int32);a=_integers(acceleration,np.int32)
    if len(a)!=len(g)*3 or not 1<=len(g)<=6000:raise ValueError('Invalid HRV frame batch')
    out=np.empty(len(g)*12,dtype=np.float64)
    return _finish(_library().ring_hrv(g,a,len(g),out,len(out)),out)


def hrv_reference_trace(encoded,acceleration):
    g=_integers(encoded,np.int32);a=_integers(acceleration,np.int32)
    if len(a)!=len(g)*3 or not 1<=len(g)<=12000:raise ValueError('Invalid HRV trace batch')
    out=np.empty(len(g)*10,dtype=np.int32)
    return _finish(_library().ring_hrv_reference(g,a,len(g),out),out)


def activity(xyz):
    a=_xyz(xyz);out=np.empty(14,dtype=np.float32)
    return _finish(_library().ring_activity(a,len(a)//3,out),out)


def motion(xyz):
    a=_xyz(xyz);out=np.empty(8,dtype=np.float32)
    return _finish(_library().ring_motion(a,len(a)//3,out),out)


def motion_lowrate(xyz,span_ms):
    a=_xyz(xyz);out=np.empty(8,dtype=np.float32)
    if not 24000<=span_ms<=0x7fffffff:raise ValueError('Invalid motion span')
    return _finish(_library().ring_motion_lowrate(a,len(a)//3,int(span_ms),out),out)


def ppg(raw,motion_sd):
    a=_integers(raw,np.int32);out=np.empty(18,dtype=np.float32)
    if not np.isfinite(motion_sd):raise ValueError('Invalid motion SD')
    return _finish(_library().ring_ppg(a,len(a),float(motion_sd),out),out)


def ppg_lowrate(raw,times,motion_sd):
    a=_integers(raw,np.int32);t=_integers(times,np.int64);out=np.empty(18+192*3,dtype=np.float64)
    if len(a)!=len(t) or not np.isfinite(motion_sd):raise ValueError('Invalid PPG time array or motion SD')
    return _finish(_library().ring_ppg_lowrate(a,t,len(a),float(motion_sd),out),out)


__all__=['hrv','hrv_reference_trace','activity','motion','motion_lowrate','ppg','ppg_lowrate']
