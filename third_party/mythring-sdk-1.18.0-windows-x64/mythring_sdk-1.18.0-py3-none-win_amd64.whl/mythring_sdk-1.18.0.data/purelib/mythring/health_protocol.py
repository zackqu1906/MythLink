"""Health wire format from Android SDK 1.15.1, without Android/model dependencies."""
from __future__ import annotations

import io
import math
import struct
import zlib
from dataclasses import dataclass
from enum import IntFlag
from typing import BinaryIO, Iterator

COMMAND = 0x3A
MAX_FILE = 16 * 1024 * 1024


def _require(condition: bool, message: str = "Invalid health packet") -> None:
    if not condition:
        raise ValueError(message)


class HealthError(RuntimeError):
    def __init__(self, device_code: int, message: str, operation: int | None = None):
        super().__init__(message)
        self.device_code = device_code
        self.operation = operation


def request_packet(operation: int, transaction: int, payload: bytes = b"") -> bytes:
    _require(0 <= operation < 128 and 1 <= transaction <= 0xFFFFFFFF)
    return struct.pack("<BBBBI", COMMAND, operation, 1, 0, transaction) + payload


@dataclass(frozen=True)
class HealthCapabilities:
    mode: int
    accelerometer_hz: int
    green_hz: int
    recording_duration_ms: int
    max_read_bytes: int
    flags: int
    accelerometer_period_ms: int
    green_period_ms: int
    feature_revision: int = 0
    protocol_version: int = 1

    @property
    def automatic(self) -> bool:
        return self.mode == 7 and bool(self.flags & (1 << 10))

    @property
    def monitoring_settings_supported(self) -> bool:
        return self.automatic and bool(self.flags & (1 << 28))

    @property
    def live_heart_supported(self) -> bool:
        return bool(self.flags & (1 << 18))

    @property
    def swipe_day_concurrent(self) -> bool:
        return self.automatic and bool(self.flags & (1 << 19))

    @property
    def swipe_sleep_concurrent(self) -> bool:
        return self.swipe_day_concurrent and self.feature_revision >= 16 and bool(self.flags & (1 << 20))

    @property
    def retained_history(self) -> bool:
        return self.automatic and ((16 <= self.feature_revision <= 18 and bool(self.flags & (1 << 22))) or
            (self.feature_revision == 15 and bool(self.flags & (1 << 20)) and bool(self.flags & (1 << 21)) and not self.flags & (1 << 19)))

    @property
    def ack_policy_supported(self) -> bool:
        return self.automatic and self.feature_revision >= 16 and bool(self.flags & (1 << 23))

    @property
    def effective_accelerometer_hz(self) -> float:
        return 1000.0 / self.accelerometer_period_ms

    @property
    def effective_green_hz(self) -> float:
        return 1000.0 / self.green_period_ms

    @classmethod
    def decode(cls, data: bytes) -> HealthCapabilities:
        _require(len(data) in (15, 19, 29), "Invalid health capabilities")
        flags, mode, acc_hz, green_hz, duration, maximum = struct.unpack_from("<IBHHIH", data)
        if len(data) >= 19 and flags & 128:
            acc_period, green_period = struct.unpack_from("<HH", data, 15)
        else:
            _require(acc_hz > 0 and green_hz > 0)
            acc_period, green_period = 1000 // acc_hz, 1000 // green_hz
        revision = struct.unpack_from("<H", data, 19)[0] if len(data) == 29 else 0
        value = cls(mode, acc_hz, green_hz, duration, maximum, flags, acc_period, green_period, revision)
        _require((mode == 6 and flags & 0x7F == 0x7F) or
                 (value.automatic and flags & (1 << 9) != 0 and len(data) == 29),
                 "Unsupported health capture capability")
        _require(acc_period in (20, 40, 160, 640) and green_period in (10, 40, 80)
                 and 1 <= maximum <= 180, "Unsupported health capture capability")
        return value


@dataclass(frozen=True)
class HealthState:
    recording: bool = False
    recording_id: int = 0
    optical_mode: int = 0
    manual: bool = False
    manual_done: bool = False
    device_error: int = 0
    monitoring_state: int = 0
    time_known: bool = False
    boot_id: int = 0
    uptime_ms: int = 0

    @classmethod
    def decode(cls, data: bytes) -> HealthState:
        _require(len(data) in (16, 30), "Invalid health state")
        return cls(bool(data[0]), struct.unpack_from("<I", data, 4)[0], data[1], bool(data[2]),
                   bool(data[3]), struct.unpack_from("<i", data, 12)[0],
                   data[16] if len(data) == 30 else 0, len(data) == 30 and data[17] == 1,
                   struct.unpack_from("<Q", data, 18)[0] if len(data) == 30 else 0,
                   struct.unpack_from("<I", data, 26)[0] if len(data) == 30 else 0)


@dataclass(frozen=True)
class HealthRecording:
    id: int
    status: int
    bytes: int
    start_utc_ms: int
    duration_ms: int
    mode: int = 6

    @property
    def complete(self) -> bool:
        return self.status == 1

    @classmethod
    def decode(cls, data: bytes) -> HealthRecording:
        _require(len(data) in (22, 26), "Invalid health directory entry")
        record_id, status, mode, size, start, duration = struct.unpack_from("<IBBIQI", data)
        return cls(record_id, status, size, start, duration, mode)


class HealthFeature(IntFlag):
    STEPS_ACTIVITY = 1
    HEART_HRV = 2
    SPO2 = 4
    SKIN_TEMPERATURE = 8
    SLEEP = 16
    ALL = 31


@dataclass(frozen=True)
class HealthMonitoringSettings:
    enabled: bool = True
    features: HealthFeature = HealthFeature.ALL

    @property
    def feature_mask(self) -> int:
        return int(self.features)

    @property
    def effective_mask(self) -> int:
        return self.feature_mask if self.enabled else 0

    def is_enabled(self, feature: HealthFeature) -> bool:
        return self.enabled and bool(self.features & feature)

    def with_feature(self, feature: HealthFeature, on: bool) -> HealthMonitoringSettings:
        _require(feature in tuple(HealthFeature), "Expected one health feature")
        _require(not (on and feature == HealthFeature.SPO2 and not self.features & HealthFeature.SLEEP),
                 "Enable sleep before blood oxygen")
        selected = self.features | feature if on else self.features & ~feature
        if feature == HealthFeature.SLEEP and not on:
            selected &= ~HealthFeature.SPO2
        return HealthMonitoringSettings(self.enabled, selected)

    def encode(self) -> bytes:
        _require(self.feature_mask & ~31 == 0 and self.feature_mask >= 0, "Unknown health feature")
        _require(not self.features & HealthFeature.SPO2 or bool(self.features & HealthFeature.SLEEP),
                 "Blood oxygen requires sleep")
        return struct.pack("<BI", int(self.enabled), self.feature_mask)

    @classmethod
    def decode(cls, data: bytes) -> HealthMonitoringSettings:
        _require(len(data) == 8, "Invalid health settings reply")
        word, supported = struct.unpack("<II", data)
        _require(word & ~0x11F == 0 and supported == 31, "Unsupported health settings version")
        return cls(bool(word & 0x100), HealthFeature(word & 31))


@dataclass(frozen=True)
class HealthLiveHeart:
    state: int
    light: bool
    reason: int
    elapsed_ms: int
    remaining_ms: int
    value: float | None
    preview: float | None
    sequence: int
    samples: int

    @classmethod
    def decode(cls, data: bytes, token: int) -> HealthLiveHeart:
        _require(len(data) == 32, "Invalid live-heart reply")
        received, state, light, reason, elapsed, remaining, value, preview, sequence, samples, reserved = struct.unpack("<IBBHIIffIHH", data)
        _require(received == token and 1 <= state <= 5 and light in (0, 1) and
                 elapsed <= 20000 and remaining <= 20000 and samples <= 32 and reserved == 0)
        _require((reason == 0 and not light and math.isfinite(value) and 30 <= value <= 240)
                 if state == 3 else math.isnan(value), "Invalid final heart rate")
        _require(math.isnan(preview) or (state == 2 and light == 1 and math.isfinite(preview)
                                       and 30 <= preview <= 240 and sequence > 0), "Invalid heart-rate preview")
        return cls(state, bool(light), reason, elapsed, remaining, None if math.isnan(value) else value,
                   None if math.isnan(preview) else preview, sequence, samples)


@dataclass(frozen=True)
class HealthBlock:
    kind: int
    sequence: int
    uptime_ms: int
    period_ms: int
    count: int
    flags: int
    payload: bytes
    schema: int = 1
    stored_bytes: int = 0


def decode_delta(kind: int, count: int, payload: bytes) -> bytes:
    """Decode canonical DELTA_V1; preserves the PPG per-sample flag byte."""
    _require(kind in (2, 3) and 1 <= count <= 250)
    width, channels, stride = (2, 3, 6) if kind == 2 else (4, 2, 9)
    _require(stride <= len(payload) < count * stride)
    result = bytearray(count * stride)
    result[:stride] = payload[:stride]
    cursor = stride
    format_ = "<h" if width == 2 else "<i"
    for sample in range(1, count):
        for channel in range(channels):
            value, shift = 0, 0
            while True:
                _require(cursor < len(payload) and shift <= 28, "Truncated/overflowing delta")
                byte = payload[cursor]
                cursor += 1
                value |= (byte & 127) << shift
                if not byte & 128:
                    _require(shift == 0 or byte != 0, "Noncanonical delta")
                    _require(value <= (131070 if kind == 2 else 8589934590), "Delta out of range")
                    break
                shift += 7
            previous = struct.unpack_from(format_, result, (sample - 1) * stride + channel * width)[0]
            decoded = previous + (value >> 1) - (value & 1) * (1 + (value >> 1) * 2)
            bits = width * 8
            _require(-(1 << (bits - 1)) <= decoded < (1 << (bits - 1)), "Delta sample out of range")
            struct.pack_into(format_, result, sample * stride + channel * width, decoded)
        if kind == 3:
            _require(cursor < len(payload), "Missing PPG flags")
            result[sample * stride + 8] = payload[cursor]
            cursor += 1
    _require(cursor == len(payload), "Trailing delta bytes")
    return bytes(result)


def _feature_shape(kind: int, count: int, flags: int, p: bytes) -> bool:
    if count != 1:
        return False
    if kind == 1:
        return (len(p) == 48 and flags == 0 and p[:4] == b"\x07\x04\x10\x01" and
                struct.unpack_from("<H", p, 16)[0] in (40, 160, 640) and
                struct.unpack_from("<H", p, 18)[0] in (40, 80) and
                struct.unpack_from("<HH", p, 20) == (2048, 512) and
                struct.unpack_from("<H", p, 36)[0] in (14, 15, 16, 17, 18) and
                p[38] in (0, 1) and struct.unpack_from("<I", p, 44)[0] == 1800000)
    if kind == 4:
        return len(p) == 8 and flags in (0, 1)
    if kind == 5:
        return len(p) == 12 and flags == 0
    if kind == 6:
        return flags == 0 and (len(p) == 5 or (len(p) == 13 and p[0] == 7))
    if kind == 7:
        return len(p) == 8 and flags == 0 and p[0] in (1, 2, 3)
    if kind == 8:
        return len(p) == 32 and flags in (0, 1)
    if kind == 9:
        return len(p) == 8 and flags == 0 and p[4] in (0, 1)
    if kind == 10:
        return len(p) == 84 and flags in (0, 1)
    if kind == 11:
        if flags != 0 or len(p) not in (18, 26):
            return False
        if len(p) == 18:
            return True
        candidate = struct.unpack_from("<f", p, 18)[0]
        return p[23] == 1 and (p[22] == 255 if math.isnan(candidate) else
                              math.isfinite(candidate) and candidate > 0 and p[22] <= 100)
    if kind == 12:
        return len(p) == 20 and flags == 0
    if kind == 13:
        if flags not in (0, 1) or len(p) not in (48, 192):
            return False
        if p[7] != 1 or struct.unpack_from("<I", p, 16)[0] != 20000 or not 0 <= struct.unpack_from("<i", p, 20)[0] <= 2000:
            return False
        return (p[:4] == b"SRW1" and p[4:6] == b"\x06\x04" and p[6] == flags) if len(p) == 192 else (p[:4] == b"SRW2" and p[4:6] == b"\x0c\x02" and p[6] in (0, 1))
    return False


def _read_exact(source: BinaryIO, size: int) -> bytes:
    result = bytearray()
    while len(result) < size:
        chunk = source.read(size - len(result))
        if not chunk:
            raise ValueError("Truncated health record")
        result.extend(chunk)
    return bytes(result)


def read_block(source: BinaryIO) -> HealthBlock | None:
    first = source.read(1)
    if not first:
        return None
    header = first + _read_exact(source, 23)
    magic, schema, kind, length, count, sequence, uptime, period, flags, crc = struct.unpack("<HBBHHIIHHI", header)
    _require(magic == 0x4852 and 1 <= schema <= 4, "Unsupported health record")
    _require(1 <= kind <= (13 if schema == 4 else 7) and length <= 1800, "Invalid health record size/type")
    stored = _read_exact(source, length)
    _require(zlib.crc32(stored, zlib.crc32(header[:20])) == crc, "Health record CRC mismatch")
    compressed = bool(flags & 0x8000)
    _require(not compressed or (schema == 3 and kind in (2, 3) and flags == 0x8000), "Unknown health encoding")
    p = decode_delta(kind, count, stored) if compressed else stored
    if schema == 4:
        valid = _feature_shape(kind, count, flags, p)
    elif kind == 1:
        valid = (len(p) == 24 and flags == 0 and p[:4] == bytes((6, schema, 16, 1)) and
                 struct.unpack_from("<HHHH", p, 16) == (50 if schema == 1 else 640, 100 if schema == 1 else 80, 2048, 512))
    elif kind == 2:
        valid = period == (20 if schema == 1 else 640) and 1 <= count <= 250 and len(p) == count * 6 and flags & 0x7FFF == 0
    elif kind == 3:
        valid = period == (10 if schema == 1 else 80) and 1 <= count <= 200 and len(p) == count * 9 and flags & 0x7FFF == 0
    elif kind == 4:
        valid = length == 8 and flags == 0
    elif kind == 5:
        valid = (length == 12) if flags == 0 else flags == 1 and length in (48, 60)
    elif kind == 6:
        valid = length == 5 and flags == 0
    else:
        valid = length == 8 and flags == 0 and p[0] in (1, 2, 3)
    _require(valid, "Invalid health record shape")
    return HealthBlock(kind, sequence, uptime, period, count, flags, p, schema, 24 + length)


def read_blocks(data: bytes, *, require_end: bool = False) -> Iterator[HealthBlock]:
    """Validate CRC, structure, schema and sequence; yield stored health blocks."""
    _require(len(data) <= MAX_FILE, "Health recording exceeds maximum size")
    source = io.BytesIO(data)
    sequence, schema, ended = 0, 0, False
    while (block := read_block(source)) is not None:
        _require(not ended and block.sequence == sequence and
                 ((sequence == 0 and block.kind == 1) or (sequence > 0 and block.kind != 1)),
                 "Discontinuous health recording")
        if sequence == 0:
            schema = block.schema
        _require(schema == block.schema, "Health schema changed within recording")
        sequence += 1
        ended = block.kind == 7
        yield block
    _require(sequence > 0, "Empty health recording")
    _require(not require_end or ended, "Missing END in complete health recording")


class HealthWindow:
    def __init__(self, record_id: int, offset: int, total: int, cap: int, credits: int = 8, allow_open: bool = False):
        _require(1 <= credits <= 32 and 1 <= cap <= 470)
        self.record_id, self.offset, self.total, self.cap, self.credits = record_id, offset, total, cap, credits
        self.allow_open = allow_open
        self.data = bytearray()
        self.index = 0
        self.status: int | None = None
        self.complete = False

    def consume(self, payload: bytes) -> bytes | None:
        _require(not self.complete and 16 <= len(payload) <= 15 + self.cap and self.index < self.credits)
        record_id, offset, total, state, index, last = struct.unpack_from("<IIIBBB", payload)
        end = self.offset + len(self.data) + len(payload) - 15
        _require(record_id == self.record_id and offset == self.offset + len(self.data) and total == self.total and
                 (state == 0 if self.allow_open else 1 <= state <= 3) and (self.status is None or state == self.status)
                 and index == self.index and last in (0, 1) and end <= total)
        terminal = self.index + 1 == self.credits or end == total
        _require(bool(last) == terminal, "Invalid health window boundary")
        self.data.extend(payload[15:])
        self.status, self.complete = state, terminal
        self.index += 1
        return struct.pack("<IIIB", record_id, self.offset, total, state) + self.data if terminal else None


def decode_compact(encoded: bytes) -> bytes:
    """Restore HC02 transport encoding to byte-identical RH record bytes."""
    _require(len(encoded) >= 20, "Invalid compact health block")
    magic, version, schema, count, raw_size, body_size, first_seq, time = struct.unpack_from("<IBBHHHII", encoded)
    _require(magic == 0x32304348 and version == 1 and 1 <= count <= 21 and 24 <= raw_size <= 512 and body_size == len(encoded) - 20)
    cursor, sequence = 20, (first_seq - 1) & 0xFFFFFFFF
    templates: dict[int, list[int]] = {}
    result = bytearray()

    def uint() -> int:
        nonlocal cursor
        value = 0
        for shift in range(0, 36, 7):
            _require(cursor < len(encoded), "Truncated compact varint")
            byte = encoded[cursor]
            cursor += 1
            value |= (byte & 127) << shift
            if byte < 128:
                _require(shift == 0 or byte != 0, "Noncanonical compact varint")
                return value
        raise ValueError("Oversize compact varint")

    def delta() -> int:
        value = uint()
        return -(value // 2) - 1 if value & 1 else value // 2

    for _ in range(count):
        _require(cursor + 2 <= len(encoded))
        kind, mask = encoded[cursor:cursor + 2]
        cursor += 2
        _require(mask & ~31 == 0)
        values = list(templates.get(kind, [-1] * 4))
        for index in range(4):
            if mask & (1 << index):
                values[index] = uint()
            _require(0 <= values[index] <= 65535)
        sequence = (sequence + 1) & 0xFFFFFFFF
        if mask & 16:
            sequence += delta()
        time += delta()
        _require(0 <= sequence <= 0xFFFFFFFF and 0 <= time <= 0xFFFFFFFF)
        size, samples, period, flags = values
        _require(cursor + size <= len(encoded) and len(result) + 24 + size <= raw_size)
        prefix = struct.pack("<HBBHHIIHH", 0x4852, schema, kind, size, samples, sequence, time, period, flags)
        payload = encoded[cursor:cursor + size]
        result.extend(prefix + struct.pack("<I", zlib.crc32(payload, zlib.crc32(prefix))) + payload)
        cursor += size
        templates[kind] = values
    _require(cursor == len(encoded) and len(result) == raw_size)
    return bytes(result)


class HealthCompactWindow:
    def __init__(self, record_id: int, offset: int, total: int, status: int, cap: int, credits: int):
        _require(0 < record_id <= 0xFFFFFFFF and 0 <= offset < total <= 0xFFFFFFFF and
                 0 <= status <= 3 and 1 <= cap <= 479 and 1 <= credits <= 32)
        self.record_id, self.offset, self.total, self.status = record_id, offset, total, status
        self.cap, self.credits, self.index, self.complete = cap, credits, 0, False
        self.data = bytearray()
        self.fragment = bytearray()
        self.target = 2

    def consume(self, packet: bytes, transaction: int) -> bytes | None:
        _require(not self.complete and self.index < self.credits and 16 <= len(packet) <= 16 + self.cap)
        command, operation, version, flags, tx, error, index, status = struct.unpack_from("<BBBBIhBB", packet)
        _require((command, operation, version, tx) == (COMMAND, 0x93, 2, transaction))
        _require(zlib.crc32(packet[:-4]) == struct.unpack_from("<I", packet, len(packet) - 4)[0], "Compact health CRC mismatch")
        _require(flags & ~1 == 0 and index == self.index)
        if error < 0:
            _require(len(packet) == 16 and flags == 1)
            raise HealthError(error, f"Compact health read failed ({error})", 19)
        _require(error == 0 and status == self.status and len(packet) > 16)
        cursor = 12
        while cursor < len(packet) - 4:
            take = min(self.target - len(self.fragment), len(packet) - 4 - cursor)
            self.fragment.extend(packet[cursor:cursor + take])
            cursor += take
            if len(self.fragment) == 2 and self.target == 2:
                size = struct.unpack("<H", self.fragment)[0] & 32767
                _require(0 < size <= 512)
                self.target = 2 + size
            if len(self.fragment) == self.target:
                block = bytes(self.fragment[2:])
                raw = decode_compact(block) if self.fragment[1] & 128 else block
                _require(0 < len(raw) <= 512 and self.offset + len(self.data) + len(raw) <= self.total and
                         len(self.data) + len(raw) <= self.credits * self.cap * 8)
                self.data.extend(raw)
                self.fragment.clear()
                self.target = 2
        last = bool(flags & 1)
        _require(last == (self.index + 1 == self.credits or self.offset + len(self.data) == self.total))
        _require(not last or (not self.fragment and bool(self.data)))
        self.index += 1
        self.complete = last
        return struct.pack("<IIIB", self.record_id, self.offset, self.total, status) + self.data if last else None
