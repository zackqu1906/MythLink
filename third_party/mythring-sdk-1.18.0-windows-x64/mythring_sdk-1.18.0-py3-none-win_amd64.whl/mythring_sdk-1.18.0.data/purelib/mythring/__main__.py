"""Read-only discovery and device information commands."""
import argparse
import asyncio
import io
import os
import sys

from mythring import Ring, scan


async def run(args):
    if args.command == "scan":
        devices = await scan(args.timeout)
        for device in devices:
            signal = "—" if device.rssi is None else f"{device.rssi} dBm"
            source = "系统已连接" if device.source == "system_connected" else "广播"
            print(f"{device.address}\t{device.name}\t{signal}\t{source}")
        if not devices:
            print("未发现 Ringo / R1。请检查戒指电量、广播状态和系统蓝牙权限。")
        return
    async with Ring(args.address) as ring:
        print("地址:", ring.address)
        print("固件:", ring.device_info.firmware_version)
        print("产品:", getattr(ring.device_info, "product_id", None) or "未知")
        print("板级修订:", getattr(ring.device_info, "board_revision", None) or "未知")
        print("MTU:", ring.mtu_size)
        print("电量:", await ring.get_battery_level(), "%")


def main():
    # Windows pipes can default to a code page that cannot represent CLI messages.
    if sys.platform == "win32" and not os.environ.get("PYTHONIOENCODING"):
        for stream in (sys.stdout, sys.stderr):
            if isinstance(stream, io.TextIOWrapper) and not stream.isatty():
                stream.reconfigure(encoding="utf-8", errors=stream.errors)
    parser = argparse.ArgumentParser(description="Ringo / R1 SDK 扫描和设备信息（Windows 使用蓝牙地址，macOS 使用 UUID）")
    parser.add_argument("command", choices=["scan", "info"])
    parser.add_argument("address", nargs="?", help="info 所需的完整设备地址/UUID")
    parser.add_argument("--timeout", type=float, default=5.0, help="扫描秒数")
    args = parser.parse_args()
    if args.command == "info" and not args.address:
        parser.error("info 需要完整设备地址/UUID")
    try:
        asyncio.run(run(args))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
