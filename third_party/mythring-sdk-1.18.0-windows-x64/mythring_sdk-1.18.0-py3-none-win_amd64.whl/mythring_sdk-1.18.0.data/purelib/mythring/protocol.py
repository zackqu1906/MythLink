"""Byte-exact port of SDK 1.15.1's R1DeviceInfo and RingPacketParser.

Each NUS notification is one packet; the source defines no extra transport
framing or physical IMU/audio codec. Unknown and malformed packets yield no
events. Gesture command acknowledgements are handled by :mod:`mythring.gesture`.
"""

import math
import struct

from mythring.models import Battery, DeviceInfo, GestureEvent, ImuToken, InfoComponent, is_supported_ble_name

__all__ = [
    "SERVICE_UUID", "WRITE_CHARACTERISTIC_UUID", "NOTIFY_CHARACTERISTIC_UUID",
    "GET_INFO", "GET_BATTERY", "OPEN_SWIPE", "CLOSE_SWIPE", "OPEN_IMU_TOKEN",
    "CLOSE_IMU", "parse_packet", "parse_device_info", "is_supported_ble_name",
    "is_ringo_touchpad_info", "is_ringo_audio_info",
]

SERVICE_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
WRITE_CHARACTERISTIC_UUID = "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
NOTIFY_CHARACTERISTIC_UUID = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"
GET_INFO = bytes((0x2A, 1))
GET_BATTERY = bytes((0x29, 1))
OPEN_SWIPE = bytes((0x26, 0))
CLOSE_SWIPE = bytes((0x26, 1))
OPEN_IMU_TOKEN = bytes((0x21, 0, 0xC8, 0, 0xC8, 0, 0xD0, 7, 16, 10, 1))
CLOSE_IMU = bytes((0x21, 1))

_LEGACY_GESTURE_IDS = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 12, 13)
_FINAL_GESTURE_IDS = frozenset((1, 2, 3, 4, 6, 7, 8, 9, 12, 13, 0x88, 0x89))


def is_ringo_touchpad_info(info: DeviceInfo | None) -> bool:
    """Identify bundled Ringo Raw2 builds; STATUS still verifies the live model."""
    if info is None or info.hardware_revision != 1:
        return False
    if info.firmware_version == "2.1.6-dev.touchpad.9.debug":
        return True
    return (info.firmware_text_version == "2.1.6-dev.touchpad.15.debug"
            and info.firmware_numeric_version == (2, 1, 6, 0))


def is_ringo_audio_info(info: DeviceInfo | None) -> bool:
    """Enable exact Ringo MIC releases with documented or observed ADPCM support."""
    return (info is not None and info.hardware_revision == 1
            and (info.firmware_text_version, info.firmware_numeric_version) in (
                ("1.2.133.public", (1, 2, 133, 0)),
                ("2.1.6-dev.touchpad.9.debug", (2, 1, 6, 0)),
            )
            and any(row.id == 3 and row.present for row in info.components))


def parse_device_info(packet: bytes) -> DeviceInfo | None:
    """Validate hardware/protocol identity and the optional ASCII version."""
    if len(packet) < 9 or packet[:3] != b"\x2a\x02\x01" or packet[3] not in (1, 2):
        return None
    count = packet[8]
    end = 9 + count * 5
    if len(packet) < end:
        return None
    if len({packet[9 + index * 5] for index in range(count)}) != count:
        return None
    text_version = None
    if len(packet) == end:
        version = ".".join(str(part) for part in packet[4:8])
    else:
        length = packet[end]
        if not 1 <= length <= 31 or len(packet) != end + 1 + length:
            return None
        version_bytes = packet[end + 1:]
        if any(not 1 <= byte <= 127 for byte in version_bytes):
            return None
        text_version = version_bytes.decode("ascii")
        version = text_version
    components = tuple(
        InfoComponent(*packet[offset:offset + 5]) for offset in range(9, end, 5)
    )
    return DeviceInfo(
        firmware_version=version,
        hardware_revision=packet[3],
        swipe_available=any(component.id == 8 and component.present != 0 for component in components),
        format_version=packet[2],
        firmware_numeric_version=tuple(packet[4:8]),
        components=components,
        product_id={1: "ringo", 2: "r1"}[packet[3]],
        firmware_text_version=text_version,
        firmware_version_source="info_text" if text_version is not None else "info_numeric",
    )


def parse_packet(packet: bytes) -> list[Battery | ImuToken | GestureEvent]:
    """Parse one notification, discarding unsupported or malformed packets."""
    if len(packet) < 2:
        return []
    kind = packet[:2]
    if kind == b"\x26\x06":
        return _parse_gesture(packet)
    if kind == b"\x26\x03":
        return _parse_legacy_trigger(packet)
    if kind == b"\x26\x07":
        return _parse_ringo_gesture(packet)
    if kind == b"\x29\x02":
        if len(packet) >= 5 and packet[4] <= 100:
            return [Battery(packet[4])]
    elif kind == b"\x21\x05":
        return _parse_imu_tokens(packet)
    return []


def _parse_ringo_gesture(packet: bytes) -> list[GestureEvent]:
    if len(packet) != 13 or packet[4] not in (1, 2, 3, 4, 5, 6, 7, 8, 9, 12, 13):
        return []
    confidence = struct.unpack_from("<f", packet, 9)[0]
    if not math.isfinite(confidence) or not 0 <= confidence <= 1:
        return []
    return [GestureEvent(struct.unpack_from("<H", packet, 2)[0], packet[4],
                         struct.unpack_from("<I", packet, 5)[0], confidence)]


def _parse_legacy_trigger(packet: bytes) -> list[GestureEvent]:
    # seq:u16, class:u8, seven int8 logits, trigger uptime:u32. Logits are
    # deliberately not converted into an undocumented probability.
    if len(packet) != 16 or packet[4] not in (1, 2, 3, 4, 5, 6):
        return []
    return [GestureEvent(
        sequence=struct.unpack_from("<H", packet, 2)[0],
        class_id=packet[4],
        center_uptime_ms=struct.unpack_from("<I", packet, 12)[0],
        confidence=None,
    )]


def _parse_gesture(packet: bytes) -> list[GestureEvent]:
    if len(packet) != 65:
        return []
    class_id = packet[4]
    probabilities = struct.unpack_from("<12f", packet, 5)
    if any(not math.isfinite(value) or not 0 <= value <= 1 for value in probabilities):
        return []
    mass = struct.unpack_from("<f", packet, 61)[0]
    if not math.isfinite(mass) or mass < 0:
        return []
    if all(value == 0 for value in probabilities):
        if class_id not in _FINAL_GESTURE_IDS or mass != 0:
            return []
        confidence = 0.0
    else:
        if class_id == 0 or class_id not in _LEGACY_GESTURE_IDS:
            return []
        if abs(sum(probabilities) - 1.0) > 0.0001:
            return []
        confidence = probabilities[_LEGACY_GESTURE_IDS.index(class_id)]
    return [GestureEvent(
        sequence=struct.unpack_from("<H", packet, 2)[0],
        class_id=class_id,
        center_uptime_ms=struct.unpack_from("<I", packet, 57)[0],
        confidence=confidence,
    )]


def _parse_imu_tokens(packet: bytes) -> list[ImuToken]:
    if len(packet) < 10:
        return []
    count = packet[4]
    if not 1 <= count <= 20 or len(packet) != 10 + count * 12 or packet[9] != 1:
        return []
    sequence = struct.unpack_from("<H", packet, 2)[0]
    uptime = struct.unpack_from("<I", packet, 5)[0]
    return [ImuToken(
        values=struct.unpack_from("<6e", packet, 10 + index * 12),
        sequence=sequence,
        frame_index=index,
        frame_count=count,
        packet_uptime_ms=uptime,
    ) for index in range(count)]
