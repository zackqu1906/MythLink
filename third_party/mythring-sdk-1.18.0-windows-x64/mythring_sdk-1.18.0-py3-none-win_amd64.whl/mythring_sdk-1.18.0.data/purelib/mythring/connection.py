"""Owner-unbind outcomes, connected RSSI and multi-ring lifecycle helpers.

Owner unbind resets the firmware name and requests disconnection; it is separate
from closing a local GATT. CoreBluetooth GATT events do not establish the OS-wide
BLE/ACL state, which remains UNKNOWN without a separate platform observer.
"""
from __future__ import annotations

import asyncio
import logging
import math
import struct
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable

from .errors import UnsupportedFeatureError

_LOG = logging.getLogger(__name__)
OWNER_UNBIND_COMMAND = b"\x37\x00\xa5"


class RingSystemConnectionState(str, Enum):
    UNKNOWN = "unknown"
    DISCONNECTED = "disconnected"
    CONNECTED = "connected"


class RingDisconnectOutcome(str, Enum):
    SUCCESS = "success"
    DISCONNECTED_UNCONFIRMED_UNBIND = "disconnected_unconfirmed_unbind"
    SYSTEM_STATE_UNCONFIRMED = "system_state_unconfirmed"
    DEVICE_REJECTED = "device_rejected"
    NOT_READY = "not_ready"
    SEND_FAILED = "send_failed"
    ACK_TIMEOUT = "ack_timeout"
    DISCONNECT_TIMEOUT = "disconnect_timeout"
    CONNECTION_CHANGED = "connection_changed"


@dataclass(frozen=True)
class RingDisconnectResult:
    outcome: RingDisconnectOutcome
    link_disconnected: bool = False
    system_disconnected: bool = False
    unbind_acknowledged: bool = False
    device_code: int | None = None


@dataclass
class _DisconnectOperation:
    generation: int
    started_at: float
    submitted: bool = False
    acknowledged: bool = False
    link_disconnected: bool = False
    system_disconnected: bool = False
    failure: RingDisconnectOutcome | None = None
    device_code: int | None = None

    def accept(self, packet: bytes) -> bool:
        if len(packet) != 5 or packet[:2] != b"\x37\x01":
            return False
        if self.submitted and self.failure is None:
            code = struct.unpack_from("<h", packet, 3)[0]
            if packet[2] == 1 and code == 0:
                self.acknowledged = True
            else:
                self.failure = RingDisconnectOutcome.DEVICE_REJECTED
                self.device_code = code
        return True

    def evaluate(self, now: float, timeout: float) -> RingDisconnectResult | None:
        outcome = self.failure
        if outcome is None:
            if self.submitted and self.link_disconnected and self.system_disconnected:
                outcome = (RingDisconnectOutcome.SUCCESS if self.acknowledged
                           else RingDisconnectOutcome.DISCONNECTED_UNCONFIRMED_UNBIND)
            elif now - self.started_at < timeout:
                return None
            elif self.link_disconnected:
                outcome = RingDisconnectOutcome.SYSTEM_STATE_UNCONFIRMED
            elif self.acknowledged:
                outcome = RingDisconnectOutcome.DISCONNECT_TIMEOUT
            else:
                outcome = RingDisconnectOutcome.ACK_TIMEOUT
        return RingDisconnectResult(outcome, self.link_disconnected, self.system_disconnected,
                                    self.acknowledged, self.device_code)


class OwnerDisconnectClient:
    """One destructive Owner command per connection generation, shared by all waiters.

    Cancelling ``unbind()`` only cancels that waiter. Feed real transport events
    through ``accept`` and ``connection_lost``. Never infer system ACL state from
    the local GATT; ``observe_system_state`` is for an actual OS observer only.
    """
    def __init__(self, send: Callable, *, generation: Callable[[], int], ready: Callable[[], bool],
                 on_result: Callable | None = None, timeout: float = 5.0, write_timeout: float = 2.0):
        if not all(math.isfinite(value) and value > 0 for value in (timeout, write_timeout)):
            raise ValueError("Owner-disconnect timeouts must be positive and finite")
        self._send, self._generation, self._ready = send, generation, ready
        self.on_result = on_result
        self.timeout, self.write_timeout = timeout, write_timeout
        self.system_state = RingSystemConnectionState.UNKNOWN
        self._operation: _DisconnectOperation | None = None
        self._task: asyncio.Task | None = None
        self._changed = asyncio.Event()

    @property
    def is_unbinding(self) -> bool:
        return self._task is not None and not self._task.done()

    async def unbind(self) -> RingDisconnectResult:
        generation = self._generation()
        operation = self._operation
        if self._task is not None and operation is not None:
            if not self._task.done() or (operation.generation == generation and operation.submitted):
                return await asyncio.shield(self._task)
        if not self._ready():
            result = RingDisconnectResult(RingDisconnectOutcome.NOT_READY)
            self._emit(result)
            return result
        operation = _DisconnectOperation(generation, time.monotonic())
        self._operation = operation
        self._changed.clear()
        self._task = asyncio.create_task(self._run(operation), name="mythring-owner-unbind")
        return await asyncio.shield(self._task)

    async def _run(self, operation):
        try:
            if self._generation() != operation.generation or not self._ready():
                operation.failure = RingDisconnectOutcome.CONNECTION_CHANGED
            else:
                # Mark before entering the writer: a failed/ambiguous submission must not be retried.
                operation.submitted = True
                await asyncio.wait_for(self._send(OWNER_UNBIND_COMMAND, operation.generation), self.write_timeout)
        except UnsupportedFeatureError:
            raise
        except Exception:
            if operation.failure is None and not operation.link_disconnected and not operation.acknowledged:
                operation.failure = RingDisconnectOutcome.SEND_FAILED
        while True:
            result = operation.evaluate(time.monotonic(), self.timeout)
            if result is not None:
                self._emit(result)
                return result
            self._changed.clear()
            remaining = max(0.001, self.timeout - (time.monotonic() - operation.started_at))
            try:
                await asyncio.wait_for(self._changed.wait(), min(remaining, 0.05))
            except asyncio.TimeoutError:
                pass

    def _emit(self, result):
        if self.on_result is not None:
            try:
                self.on_result(result)
            except Exception:
                _LOG.exception("Owner disconnect result callback failed")

    def accept(self, packet: bytes, generation: int) -> bool:
        if len(packet) != 5 or packet[:2] != b"\x37\x01":
            return False
        operation = self._operation
        if operation is not None and operation.generation == generation and self.is_unbinding:
            operation.accept(packet)
            self._changed.set()
        return True

    def connection_lost(self, generation: int, *, remote: bool = True) -> None:
        operation = self._operation
        if operation is None or operation.generation != generation or not self.is_unbinding:
            return
        if remote and operation.submitted:
            operation.link_disconnected = True
        elif operation.failure is None:
            operation.failure = RingDisconnectOutcome.CONNECTION_CHANGED
        self._changed.set()

    def observe_system_state(self, state: RingSystemConnectionState) -> None:
        self.system_state = RingSystemConnectionState(state)
        operation = self._operation
        if operation is not None and operation.submitted and self.is_unbinding:
            operation.system_disconnected = self.system_state == RingSystemConnectionState.DISCONNECTED
            self._changed.set()


class ConnectedRssiReader:
    """Read the live peripheral RSSI when the Bleak backend exposes that capability.

    A timed-out or cancelled waiter leaves the physical read alive until its
    callback drains; another read cannot consume the late result. On macOS this
    wraps Bleak's CoreBluetooth backend ``get_rssi`` (an optional private API).
    """
    def __init__(self):
        self._pending: tuple[int, asyncio.Task] | None = None

    async def read(self, ring: Any, timeout: float = 1.0) -> int | None:
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("RSSI timeout must be positive and finite")
        if not ring.is_connected:
            return None
        generation = ring._generation
        if self._pending is not None:
            if self._pending[0] == generation:
                return None
            self.invalidate(self._pending[0])
        client = ring._client
        backend = getattr(client, "_backend", None)
        read = getattr(backend, "get_rssi", None)
        if not callable(read):
            return None
        async def physical_read():
            try:
                return await read()
            except Exception:
                return None
        task = asyncio.create_task(physical_read(), name="mythring-rssi")
        self._pending = (generation, task)
        task.add_done_callback(self._finished)
        try:
            value = await asyncio.wait_for(asyncio.shield(task), timeout)
        except asyncio.TimeoutError:
            return None
        except asyncio.CancelledError:
            if task.cancelled() and (ring._generation != generation or not ring.is_connected):
                return None
            raise
        if (ring._generation != generation or not ring.is_connected or ring._client is not client
                or type(value) is not int or not -127 <= value <= 20):
            return None
        return value

    def _finished(self, task: asyncio.Task) -> None:
        if self._pending is not None and self._pending[1] is task:
            self._pending = None
        if not task.cancelled():
            task.exception()

    def invalidate(self, generation: int) -> None:
        if self._pending is not None and self._pending[0] == generation:
            _, task = self._pending
            self._pending = None
            task.cancel()


class RingManager:
    """Manage several Ring instances and forward events as ``callback(ring, value)``.

    Remembered devices live in this manager instance; callers own persistence.
    ``disconnect`` and ``forget`` release local GATTs without Owner unbinding.
    """
    def __init__(self, *, ring_factory=None):
        self._ring_factory = ring_factory
        self._rings: dict[str, Any] = {}
        self._listeners: dict[str, list[Callable]] = {}
        self._subscriptions: dict[tuple[str, str], Callable] = {}

    @property
    def rings(self) -> tuple:
        return tuple(self._rings.values())

    def get_ring(self, address: str):
        return self._rings.get(address.casefold())

    def remember(self, device):
        address = device.address if hasattr(device, "address") else str(device)
        key = address.casefold()
        if key in self._rings:
            return self._rings[key]
        factory = self._ring_factory
        if factory is None:
            from .client import Ring
            factory = Ring
        ring = factory(device)
        self._rings[key] = ring
        for event in self._listeners:
            self._subscribe(key, ring, event)
        return ring

    def _subscribe(self, key, ring, event):
        def forward(value):
            for callback in tuple(self._listeners.get(event, ())):
                try:
                    callback(ring, value)
                except Exception:
                    _LOG.exception("RingManager listener failed")
        self._subscriptions[(key, event)] = ring.on(event, forward)

    def on(self, event: str, callback: Callable) -> Callable:
        if event not in self._listeners:
            self._listeners[event] = []
            for key, ring in self._rings.items():
                self._subscribe(key, ring, event)
        self._listeners[event].append(callback)
        def unsubscribe():
            listeners = self._listeners.get(event, [])
            if callback in listeners:
                listeners.remove(callback)
        return unsubscribe

    async def connect(self, device):
        ring = self.remember(device)
        await ring.connect()
        return ring

    async def disconnect(self, address: str | None = None) -> None:
        selected = self.rings if address is None else (self.get_ring(address),)
        results = await asyncio.gather(*(ring.disconnect() for ring in selected if ring is not None), return_exceptions=True)
        for result in results:
            if isinstance(result, BaseException):
                raise result

    async def forget(self, address: str) -> None:
        key = address.casefold()
        ring = self._rings.get(key)
        if ring is None:
            return
        if getattr(ring, "_firmware_maintenance", False):
            raise RuntimeError("Firmware maintenance is active")
        await ring.disconnect()
        for subscription in [item for item in self._subscriptions if item[0] == key]:
            self._subscriptions.pop(subscription)()
        self._rings.pop(key, None)

    async def scan(self, timeout: float = 5.0):
        from .client import scan
        return await scan(timeout)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        await self.disconnect()
