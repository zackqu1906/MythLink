"""Resolve rings which the OS already holds connected and which may no longer advertise."""
from __future__ import annotations

import asyncio
import logging
import re
import sys

from . import _corebluetooth
from .models import is_supported_ble_name

_LOG = logging.getLogger(__name__)
_ADDRESS_PROPERTY = "System.Devices.Aep.DeviceAddress"
_MAC = re.compile(r"(?:[0-9a-f]{2}:){5}[0-9a-f]{2}", re.IGNORECASE)


async def _windows_connected(timeout: float, address: str | None = None):
    # This optional OS lookup must leave time for the normal Bleak scan fallback.
    try:
        from bleak.backends.device import BLEDevice
        from bleak.backends.winrt.util import assert_mta
        from winrt.system import unbox_string
        from winrt.windows.devices.bluetooth import BluetoothConnectionStatus, BluetoothLEDevice
        from winrt.windows.devices.enumeration import DeviceInformation, DeviceInformationKind

        async with asyncio.timeout(min(timeout, 2.0)):
            await assert_mta()
            selector = BluetoothLEDevice.get_device_selector_from_connection_status(BluetoothConnectionStatus.CONNECTED)
            endpoints = await DeviceInformation.find_all_async_with_kind_aqs_filter_and_additional_properties(
                selector, [_ADDRESS_PROPERTY], DeviceInformationKind.ASSOCIATION_ENDPOINT)
    except Exception as error:
        _LOG.warning("Windows connected-device lookup unavailable: %s", error)
        return []

    devices = []
    for endpoint in endpoints:
        if address is None and not is_supported_ble_name(endpoint.name):
            continue
        try:
            mac = unbox_string(endpoint.properties[_ADDRESS_PROPERTY]).upper()
        except (KeyError, OSError, TypeError, ValueError):
            continue
        if not _MAC.fullmatch(mac) or (address is not None and mac != address.upper()):
            continue
        # Pinned Bleak 3.0.2 WinRT takes the address from BLEDevice directly.
        devices.append(BLEDevice(mac, endpoint.name, None))
    return devices


async def system_connected_devices(service_uuid: str, *, timeout: float):
    if sys.platform == "win32":
        return await _windows_connected(timeout)
    return await _corebluetooth.system_connected_devices(service_uuid, timeout=timeout)


async def retrieve_device(address: str, *, timeout: float):
    if sys.platform == "win32":
        if not _MAC.fullmatch(address):
            return None
        devices = await _windows_connected(timeout, address)
        return next(iter(devices), None)
    return await _corebluetooth.retrieve_device(address, timeout=timeout)
