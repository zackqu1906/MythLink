"""Load the paired encrypted assets without exporting model files or keys.

The supplied key-material functions are freestanding AArch64 ELF objects. A
bounded Unicorn CPU instance executes those original objects in private mapped
memory; no Android OS, syscalls, or host-native ELF loading is involved. This
keeps the original encrypted assets usable on both Intel and Apple Silicon.
"""
from __future__ import annotations

import hashlib
from importlib.resources import files
from io import BytesIO
import struct


class ProtectedModelError(RuntimeError):
    pass


_SPECS = {
    "touchpad": ("ring_runtime.bin", "touchpad_material.a", "ring_model_key"),
    "health": ("health_runtime.bin", "health_material.a", "ring_model_key"),
    "step_rf": ("step_rf_runtime.bin", "step_rf_material.a", "ring_step_model_key"),
    "step_rf12": ("step_rf12_runtime.bin", "step_rf12_material.a", "ring_step_rf12_key"),
}
_TOUCHPAD_SHA256 = "c16d77015ad37ec09a7b3b9d86055aab910096ce4595142c91238724eed3c8ab"


def _objects(archive: bytes):
    if len(archive) > 1024 * 1024 or not archive.startswith(b"!<arch>\n"):
        raise ProtectedModelError("Invalid paired model-material archive")
    cursor = 8
    while cursor < len(archive):
        header = archive[cursor:cursor + 60]
        if len(header) != 60 or header[-2:] != b"`\n":
            raise ProtectedModelError("Truncated model-material archive")
        try:
            size = int(header[48:58])
        except ValueError as error:
            raise ProtectedModelError("Invalid archive member length") from error
        start, end = cursor + 60, cursor + 60 + size
        if size < 0 or end > len(archive):
            raise ProtectedModelError("Archive member is out of bounds")
        body = archive[start:end]
        if body.startswith(b"\x7fELF"):
            yield body
        cursor = end + size % 2


def _material_key(archive: bytes, entry: str) -> bytearray:
    from elftools.elf.elffile import ELFFile
    from elftools.elf.relocation import RelocationSection
    from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_PROT_READ, UC_PROT_WRITE, UC_PROT_EXEC
    from unicorn.arm64_const import UC_ARM64_REG_X0, UC_ARM64_REG_LR, UC_ARM64_REG_SP, UC_ARM64_REG_PC, UC_ARM64_REG_CPACR_EL1

    objects = [ELFFile(BytesIO(data)) for data in _objects(archive)]
    if not objects or len(objects) > 32:
        raise ProtectedModelError("Missing model-material objects")
    machine = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
    locations = {}
    globals_ = {}
    cursor = 0x100000
    mapped = []
    for index, obj in enumerate(objects):
        if obj.elfclass != 64 or not obj.little_endian or obj['e_machine'] != 'EM_AARCH64' or obj['e_type'] != 'ET_REL':
            raise ProtectedModelError("Expected relocatable little-endian AArch64 material")
        for section_index, section in enumerate(obj.iter_sections()):
            if not section['sh_flags'] & 2 or not section['sh_size']:
                continue
            size = (section['sh_size'] + 4095) & ~4095
            if cursor + size > 0x300000:
                raise ProtectedModelError("Model-material mapping exceeds limit")
            machine.mem_map(cursor, size, UC_PROT_READ | UC_PROT_WRITE)
            if section['sh_type'] != 'SHT_NOBITS':
                machine.mem_write(cursor, section.data())
            locations[index, section_index] = cursor
            permissions = UC_PROT_READ | (UC_PROT_EXEC if section['sh_flags'] & 4 else 0) | (UC_PROT_WRITE if section['sh_flags'] & 1 else 0)
            mapped.append((cursor, size, permissions))
            cursor += size
        symbols = obj.get_section_by_name('.symtab')
        if symbols is None:
            raise ProtectedModelError("Material object has no symbols")
        for symbol in symbols.iter_symbols():
            section_index = symbol['st_shndx']
            if symbol.name and symbol['st_info']['bind'] in ('STB_GLOBAL', 'STB_WEAK') and (index, section_index) in locations:
                if symbol.name in globals_:
                    raise ProtectedModelError("Duplicate material symbol")
                globals_[symbol.name] = locations[index, section_index] + symbol['st_value']

    for index, obj in enumerate(objects):
        for relocations in obj.iter_sections():
            if not isinstance(relocations, RelocationSection):
                continue
            target = locations.get((index, relocations['sh_info']))
            if target is None:
                continue
            symbols = obj.get_section(relocations['sh_link'])
            for relocation in relocations.iter_relocations():
                symbol = symbols.get_symbol(relocation['r_info_sym'])
                section_index = symbol['st_shndx']
                if (index, section_index) in locations:
                    address = locations[index, section_index] + symbol['st_value']
                elif section_index == 'SHN_ABS':
                    address = symbol['st_value']
                elif symbol.name in globals_:
                    address = globals_[symbol.name]
                else:
                    raise ProtectedModelError("Material has an unresolved external symbol")
                place = target + relocation['r_offset']
                value = address + relocation['r_addend']
                kind = relocation['r_info_type']
                instruction = int.from_bytes(machine.mem_read(place, 4), 'little')
                if kind == 261:  # R_AARCH64_PREL32 (unwind metadata)
                    instruction = (value - place) & 0xFFFFFFFF
                elif kind == 275:  # R_AARCH64_ADR_PREL_PG_HI21
                    delta = ((value & ~4095) - (place & ~4095)) >> 12
                    if not -(1 << 20) <= delta < (1 << 20):
                        raise ProtectedModelError("Material ADRP relocation exceeds range")
                    instruction = (instruction & ~0x60FFFFE0) | ((delta & 3) << 29) | (((delta >> 2) & 0x7FFFF) << 5)
                elif kind == 277:  # R_AARCH64_ADD_ABS_LO12_NC
                    instruction = (instruction & ~0x003FFC00) | ((value & 4095) << 10)
                elif kind in (282, 283):  # JUMP26, CALL26
                    delta = value - place
                    if delta % 4 or not -(1 << 27) <= delta < (1 << 27):
                        raise ProtectedModelError("Material branch relocation exceeds range")
                    instruction = (instruction & 0xFC000000) | ((delta >> 2) & 0x03FFFFFF)
                else:
                    raise ProtectedModelError(f"Unsupported model-material relocation {kind}")
                machine.mem_write(place, struct.pack('<I', instruction))
    if entry not in globals_:
        raise ProtectedModelError("Missing paired model-material entry point")
    for address, size, permissions in mapped:
        machine.mem_protect(address, size, permissions)
    stack, output, end = 0x400000, 0x500000, 0x600000
    machine.mem_map(stack, 0x20000, UC_PROT_READ | UC_PROT_WRITE)
    machine.mem_map(output, 4096, UC_PROT_READ | UC_PROT_WRITE)
    machine.mem_map(end, 4096, UC_PROT_READ | UC_PROT_EXEC)
    machine.reg_write(UC_ARM64_REG_SP, stack + 0x1FFF0)
    machine.reg_write(UC_ARM64_REG_X0, output)
    machine.reg_write(UC_ARM64_REG_LR, end)
    machine.reg_write(UC_ARM64_REG_CPACR_EL1, 3 << 20)
    try:
        machine.emu_start(globals_[entry], end, timeout=1_000_000, count=100_000)
        if machine.reg_read(UC_ARM64_REG_PC) != end:
            raise ProtectedModelError("Model-material execution exceeded its budget")
        return bytearray(machine.mem_read(output, 32))
    except ProtectedModelError:
        raise
    except Exception as error:
        raise ProtectedModelError("Paired model-material execution failed") from error
    finally:
        machine.mem_write(output, bytes(4096))
        machine.mem_write(stack, bytes(0x20000))


def _unlock(envelope: bytes, archive: bytes, entry: str) -> bytes:
    from nacl.bindings import crypto_aead_xchacha20poly1305_ietf_decrypt
    from nacl.exceptions import CryptoError
    if len(envelope) <= 56 or len(envelope) > 64 * 1024 * 1024 + 56 or envelope[:8] != b'RNGMDL01':
        raise ProtectedModelError("Invalid encrypted model envelope")
    if struct.unpack_from('<Q', envelope, 8)[0] != len(envelope) - 56:
        raise ProtectedModelError("Encrypted model length mismatch")
    key = _material_key(archive, entry)
    try:
        # Monocypher stores the detached tag before the ciphertext; libsodium
        # consumes a combined ciphertext with its tag appended instead.
        return crypto_aead_xchacha20poly1305_ietf_decrypt(envelope[56:] + envelope[40:56], envelope[:40], envelope[16:40], bytes(key))
    except CryptoError as error:
        raise ProtectedModelError("Encrypted model authentication failed") from error
    finally:
        key[:] = bytes(len(key))


def load_model_bytes(kind: str = 'touchpad') -> bytes:
    """Internal model-runtime loader; never writes plaintext or key material to disk."""
    try:
        envelope_name, archive_name, entry = _SPECS[kind]
    except KeyError as error:
        raise ValueError(f"Unknown model kind: {kind}") from error
    assets = files('mythring').joinpath('assets')
    result = _unlock(assets.joinpath(envelope_name).read_bytes(), assets.joinpath(archive_name).read_bytes(), entry)
    if kind == 'touchpad' and hashlib.sha256(result).hexdigest() != _TOUCHPAD_SHA256:
        raise ProtectedModelError("Touchpad model does not match the 1.15.1 contract")
    return result


__all__ = ['ProtectedModelError']
