"""Independent-wear skin-temperature decoding and personal-baseline projection."""
from __future__ import annotations

from bisect import bisect_right
from dataclasses import dataclass, field, replace
from datetime import date, datetime, time, timedelta
import hashlib
import math
from zoneinfo import ZoneInfo

from .health_models import HealthBedtime, HealthQuality, HealthTemperatureSample


@dataclass(frozen=True)
class TemperatureReading:
    time_utc_ms: int
    milli_celsius: int
    sensor_error: int
    flags: int


@dataclass(frozen=True)
class HealthTemperaturePoint:
    start_utc_ms: int
    end_utc_ms: int
    date: str
    period: str
    deviation_celsius: float | None
    valid_minutes: int
    sample_count: int
    expected_minutes: int
    baseline_nights: int
    baseline_source: str
    baseline_id: str | None
    status: str
    is_complete: bool


@dataclass(frozen=True)
class HealthTemperatureNight:
    date: str
    start_utc_ms: int
    end_utc_ms: int
    deviation_celsius: float | None
    valid_minutes: int
    sample_count: int
    baseline_nights: int
    baseline_source: str
    baseline_id: str | None
    status: str


@dataclass(frozen=True)
class HealthTemperatureResult:
    algorithm_version: str = "skin-deviation-v4-independent-wear"
    unit: str = "°C"
    baseline_window_days: int = 7
    minimum_baseline_nights: int = 1
    minimum_night_minutes: int = 30
    day_interval_minutes: int = 60
    night_interval_minutes: int = 5
    history: list[HealthTemperaturePoint] = field(default_factory=list)
    nightly: list[HealthTemperatureNight] = field(default_factory=list)


def decode_temperature(readings, wear_states, wear, non_wear=lambda timestamp: False):
    """Decode one continuous boot/context; explicit OFF dominates sensor validity."""
    states = {item.time_utc_ms: item.state for item in sorted(wear_states, key=lambda item: item.time_utc_ms)}
    optical = {item.time_utc_ms: item.state for item in sorted(wear, key=lambda item: item.time_utc_ms)}
    state_times, optical_times = sorted(states), sorted(optical)

    def floor(mapping, times, timestamp):
        index = bisect_right(times, timestamp) - 1
        return mapping[times[index]] if index >= 0 else None

    distinct = {}
    for item in readings:
        distinct.setdefault(item.time_utc_ms, item)
    output = []
    for timestamp, reading in sorted(distinct.items()):
        off = non_wear(timestamp) or (floor(states, state_times, timestamp) == 0 if states else floor(optical, optical_times, timestamp) == 2)
        quality = (HealthQuality.NON_WEAR if off else HealthQuality.INSUFFICIENT_DATA
                   if reading.flags != 0 or reading.sensor_error != 0 or not 1 <= reading.milli_celsius <= 60000 else HealthQuality.VALID)
        output.append(HealthTemperatureSample(timestamp, reading.milli_celsius / 1000 if quality == HealthQuality.VALID else None,
                                               quality, reading.sensor_error))
    return output


def merged_beds(reports):
    output = []
    for bed in sorted((bed for report in reports for bed in report.bedtimes
                       if bed.start_utc_ms > 0 and bed.end_utc_ms > bed.start_utc_ms), key=lambda bed: bed.start_utc_ms):
        if output and bed.start_utc_ms <= output[-1].end_utc_ms:
            output[-1] = replace(output[-1], end_utc_ms=max(output[-1].end_utc_ms, bed.end_utc_ms))
        else:
            output.append(bed)
    return output


@dataclass(frozen=True)
class _Night:
    date: date
    bed: HealthBedtime
    mean: float | None
    minutes: int
    count: int


@dataclass(frozen=True)
class _Base:
    mean: float | None
    nights: int
    source: str
    id: str | None


def build_temperature(reports, daily, zone: ZoneInfo | str, now: int) -> HealthTemperatureResult:
    zone = ZoneInfo(zone) if isinstance(zone, str) else zone
    policy = HealthTemperatureResult()
    dated = [report for report in reports if "TIME_UNKNOWN" not in report.warnings and "POWER_DIAGNOSTIC" not in report.warnings]
    unique = {}
    for report in dated:
        for sample in report.temperature:
            if 1 <= sample.time_utc_ms <= now:
                unique.setdefault(sample.time_utc_ms, sample)
    samples = sorted(unique.values(), key=lambda sample: sample.time_utc_ms)
    valid = [sample for sample in samples if sample.quality == HealthQuality.VALID
             and sample.celsius is not None and math.isfinite(sample.celsius)]
    sleep = [epoch for day in daily for epoch in day.sleep if epoch.quality == HealthQuality.VALID and not epoch.estimated
             and not epoch.provisional and epoch.stage in ("LIGHT", "DEEP", "REM") and epoch.duration_ms > 0]

    def local(timestamp):
        return datetime.fromtimestamp(timestamp / 1000, zone)

    def asleep(timestamp):
        return any(epoch.start_utc_ms <= timestamp < epoch.start_utc_ms + epoch.duration_ms for epoch in sleep)

    def sleep_ms(bed):
        return sum(max(0, min(bed.end_utc_ms, epoch.start_utc_ms + epoch.duration_ms) - max(bed.start_utc_ms, epoch.start_utc_ms)) for epoch in sleep)

    def minute_means(rows):
        groups = {}
        for row in rows:
            groups.setdefault(row.time_utc_ms // 60000, []).append(row.celsius)
        return [sum(values) / len(values) for values in groups.values()]

    beds = {}
    for bed in merged_beds(dated):
        end = local(bed.end_utc_ms)
        previous_noon = int(datetime.combine(end.date() - timedelta(days=1), time(12), zone).timestamp() * 1000)
        if sleep_ms(bed) > 0 and bed.end_utc_ms <= now and end.hour < 12 and bed.start_utc_ms >= previous_noon:
            previous = beds.get(end.date())
            if previous is None or (sleep_ms(bed), bed.end_utc_ms) > (sleep_ms(previous), previous.end_utc_ms):
                beds[end.date()] = bed
    nights = []
    for day, bed in sorted(beds.items()):
        rows = [sample for sample in valid if bed.start_utc_ms <= sample.time_utc_ms < bed.end_utc_ms and asleep(sample.time_utc_ms)]
        means = minute_means(rows)
        nights.append(_Night(day, bed, sum(means) / len(means) if len(means) >= policy.minimum_night_minutes else None, len(means), len(rows)))

    def baseline(day, cutoff, self_night=None):
        eligible = [night for night in nights if night.mean is not None and night.bed.end_utc_ms <= cutoff
                    and night.date >= day - timedelta(days=7) and night is not self_night]
        selected = eligible[-7:] if len(eligible) >= 7 else eligible[-1:]
        source = ("ROLLING_7_NIGHTS" if len(selected) >= 7 else "LATEST_SLEEP" if selected else
                  "INITIAL_SLEEP" if self_night is not None and self_night.mean is not None else "NONE")
        used = selected or ([self_night] if self_night is not None and self_night.mean is not None else [])
        mean = sum(night.mean for night in used) / len(used) if used else None
        fingerprint = ";".join(f"{night.date}:{night.mean}:{night.minutes}:{night.count}" for night in used)
        identifier = hashlib.sha256((str(zone) + fingerprint).encode()).digest()[:8].hex() if mean is not None else None
        count = min(len(eligible), 7)
        return _Base(mean, 1 if count == 0 and mean is not None else count, source, identifier)

    def status(mean, base, complete):
        return ("INSUFFICIENT_DATA" if mean is None else "NO_BASELINE" if base.mean is None else
                "INITIAL_BASELINE" if base.source == "INITIAL_SLEEP" else "PARTIAL" if not complete else
                "BASELINE_BUILDING" if base.source == "LATEST_SLEEP" else "READY")

    night_rows = []
    for night in nights:
        base = baseline(night.date, night.bed.start_utc_ms, night)
        deviation = night.mean - base.mean if night.mean is not None and base.mean is not None else None
        night_rows.append(HealthTemperatureNight(night.date.isoformat(), night.bed.start_utc_ms, night.bed.end_utc_ms,
                                                  deviation, night.minutes, night.count, base.nights, base.source, base.id,
                                                  status(night.mean, base, True)))
    buckets = []

    def add(start, end, day, night):
        observed_end = min(end, now)
        if observed_end <= start:
            return
        rows = [sample for sample in valid if start <= sample.time_utc_ms < observed_end
                and (night.bed.start_utc_ms <= sample.time_utc_ms < night.bed.end_utc_ms if night else
                     not any(item.bed.start_utc_ms <= sample.time_utc_ms < item.bed.end_utc_ms for item in nights))]
        expected_ms = (max(0, min(observed_end, night.bed.end_utc_ms) - max(start, night.bed.start_utc_ms)) if night else
                       observed_end - start - sum(max(0, min(observed_end, item.bed.end_utc_ms) - max(start, item.bed.start_utc_ms)) for item in nights))
        if expected_ms <= 0:
            return
        means = minute_means(rows)
        mean = sum(means) / len(means) if means else None
        base = baseline(day, night.bed.start_utc_ms if night else start, night)
        deviation = mean - base.mean if mean is not None and base.mean is not None else None
        buckets.append(HealthTemperaturePoint(start, end, day.isoformat(), "NIGHT" if night else "DAY", deviation,
                                               len(means), len(rows), math.ceil(expected_ms / 60000), base.nights, base.source,
                                               base.id, status(mean, base, end <= now), end <= now))

    for night in nights:
        timestamp = night.bed.start_utc_ms // 300000 * 300000
        while timestamp < night.bed.end_utc_ms:
            add(timestamp, timestamp + 300000, night.date, night)
            timestamp += 300000
    dates = dict.fromkeys(local(sample.time_utc_ms).date() for sample in samples)
    for day in dates:
        timestamp = int(datetime.combine(day, time(), zone).timestamp() * 1000)
        end = int(datetime.combine(day + timedelta(days=1), time(), zone).timestamp() * 1000)
        while timestamp < end:
            following = timestamp + 3600000
            add(timestamp, following, day, None)
            timestamp = following
    return replace(policy, history=sorted(buckets, key=lambda row: (row.start_utc_ms, row.period)), nightly=night_rows)


__all__ = ["TemperatureReading", "HealthTemperaturePoint", "HealthTemperatureNight", "HealthTemperatureResult",
           "decode_temperature", "build_temperature", "merged_beds"]
