"""MCUmgr SMP over BLE, with one connection for SMP and R1 NUS identity.

Framing follows Zephyr's SMP protocol and BLE transport specifications:
https://docs.zephyrproject.org/latest/services/device_mgmt/smp_transport.html
"""
from __future__ import annotations

import asyncio
import contextlib
import io
import struct
import sys
from functools import partial
from typing import Any

import cbor2

from ._discovery import retrieve_device
from .protocol import NOTIFY_CHARACTERISTIC_UUID, WRITE_CHARACTERISTIC_UUID, parse_device_info

SMP_SERVICE_UUID = "8d53dc1d-1db7-4cd3-868b-8a527460aa84"
SMP_CHARACTERISTIC_UUID = "da2e7828-fbce-4e01-ae9e-261174997c48"
_HEADER = struct.Struct(">BBHHBB")


async def _with_timeout(awaitable, timeout: float):
    """Keep cancellation observable even if the child finishes simultaneously.

    Python 3.10/3.11 ``wait_for`` can consume that cancellation when its child
    has just completed. Nested writes would then leave an SMP request waiting
    for an acknowledgement after its caller has already cancelled it.
    """
    task = asyncio.ensure_future(awaitable)
    try:
        done, _ = await asyncio.wait((task,), timeout=timeout)
        if not done:
            raise asyncio.TimeoutError
        return task.result()
    finally:
        if not task.done():
            task.cancel()
        with contextlib.suppress(BaseException):
            await task


class SmpError(RuntimeError):
    """SMP protocol or transport error."""


class SmpCommandError(SmpError):
    def __init__(self, code: int, group: int | None = None, reason: str = ""):
        self.code, self.group = code, group
        super().__init__(f"SMP command failed: group={group}, rc={code}" + (f" ({reason})" if reason else ""))


def encode_request(op: int, group: int, command: int, sequence: int, payload: dict) -> bytes:
    if op not in (0, 2) or not 0 <= group <= 65535 or not 0 <= command <= 255 or not 0 <= sequence <= 255:
        raise ValueError("Invalid SMP request header")
    data = cbor2.dumps(payload)
    if len(data) > 65535:
        raise ValueError("SMP request is too large")
    return _HEADER.pack(op, 0, len(data), group, sequence, command) + data


def decode_response(frame: bytes) -> tuple[int, int, int, int, dict]:
    if len(frame) < 8:
        raise SmpError("Truncated SMP response header")
    operation, flags, length, group, sequence, command = _HEADER.unpack_from(frame)
    if operation & 0xE0 or (operation >> 3) > 1 or operation & 7 not in (1, 3) or flags:
        raise SmpError("Invalid SMP response header")
    if len(frame) != 8 + length:
        raise SmpError("SMP response length mismatch")
    try:
        stream = io.BytesIO(frame[8:])
        payload = cbor2.CBORDecoder(stream).decode()
        if stream.tell() != length or not isinstance(payload, dict):
            raise SmpError("SMP payload must contain exactly one CBOR map")
    except (ValueError, EOFError, cbor2.CBORDecodeError) as error:
        raise SmpError("Invalid SMP CBOR payload") from error
    return operation & 7, group, command, sequence, payload


def check_response(payload: dict) -> dict:
    if "rc" in payload:
        code = payload["rc"]
        if type(code) is not int:
            raise SmpError("Invalid SMP return code")
        if code:
            raise SmpCommandError(code, reason=str(payload.get("rsn", "")))
    if "err" in payload:
        error = payload["err"]
        if (not isinstance(error, dict) or type(error.get("rc")) is not int
                or type(error.get("group")) is not int):
            raise SmpError("Invalid SMP group error")
        if error["rc"]:
            raise SmpCommandError(error["rc"], error["group"], str(payload.get("rsn", "")))
    return payload


def parse_hardware_address(packet: bytes) -> str:
    if len(packet) < 9 or packet[:3] != b"\x2d\x02\x01":
        raise SmpError("Invalid R1 hardware-address response")
    return ":".join(f"{value:02X}" for value in packet[3:9])


class SmpTransport:
    """A disposable SMP session. A timeout closes it before any later request.

    Request frames may span multiple ATT writes. Response notifications are
    reassembled before checking group, command, operation and sequence.
    """

    def __init__(self, device: Any, *, timeout: float = 10.0, connect_timeout: float = 15.0,
                 write_timeout: float = 3.0, client_factory=None):
        self.device = device
        self.timeout, self.connect_timeout, self.write_timeout = timeout, connect_timeout, write_timeout
        self._client_factory = client_factory
        self._client = None
        self._smp = self._nus_write = None
        self._lock = asyncio.Lock()
        self._nus_lock = asyncio.Lock()
        self._write_lock = asyncio.Lock()
        self._sequence = 0
        self._generation = 0
        self._pending: tuple[tuple[int, int, int, int], asyncio.Future] | None = None
        self._nus_pending: tuple[int, asyncio.Future] | None = None
        self._buffer = bytearray()
        self.disconnected = asyncio.Event()

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, *_):
        await self.close()

    async def connect(self) -> None:
        if self._client is not None:
            raise SmpError("SMP session is already open")
        factory = self._client_factory
        device = self.device
        if factory is None:
            from bleak import BleakClient
            # An OTA reboot can change handles in the Windows GATT cache.
            factory = partial(BleakClient, winrt={"use_cached_services": False})
            if sys.platform == "win32" and isinstance(device, str):
                previous_generation = self._generation
                device = await retrieve_device(device, timeout=self.connect_timeout) or device
                if self._generation != previous_generation:
                    raise SmpError("SMP session changed during device lookup")
        self._generation += 1
        generation = self._generation
        self.disconnected.clear()
        client = factory(device, timeout=self.connect_timeout,
                         disconnected_callback=lambda _client: self._lost(generation))
        self._client = client
        try:
            async def initialize():
                await client.connect()
                self._smp = client.services.get_characteristic(SMP_CHARACTERISTIC_UUID)
                self._nus_write = client.services.get_characteristic(WRITE_CHARACTERISTIC_UUID)
                nus_notify = client.services.get_characteristic(NOTIFY_CHARACTERISTIC_UUID)
                if self._smp is None or self._nus_write is None or nus_notify is None:
                    raise SmpError("R1 OTA requires both SMP and NUS characteristics")
                if "write-without-response" not in self._smp.properties:
                    raise SmpError("SMP characteristic does not support Write Without Response")
                await client.start_notify(self._smp, lambda _sender, data: self._feed(generation, bytes(data)))
                await client.start_notify(nus_notify, lambda _sender, data: self._feed_nus(generation, bytes(data)))
                self._check(generation)
            await _with_timeout(initialize(), self.connect_timeout)
        except BaseException:
            await self.close()
            raise

    def _check(self, generation: int) -> None:
        if generation != self._generation or self._client is None or not self._client.is_connected or self.disconnected.is_set():
            raise ConnectionError("SMP connection is closed or changed")

    def _lost(self, generation: int) -> None:
        if generation != self._generation:
            return
        self.disconnected.set()
        error = ConnectionError("Disconnected during SMP operation")
        for pending in (self._pending, self._nus_pending):
            if pending is not None and not pending[1].done():
                pending[1].set_exception(error)
        self._buffer.clear()

    async def close(self) -> None:
        client = self._client
        self._lost(self._generation)
        self._generation += 1
        self._client = self._smp = self._nus_write = None
        if client is not None:
            release = asyncio.create_task(_with_timeout(client.disconnect(), 3.0))
            try:
                await asyncio.shield(release)
            except asyncio.CancelledError:
                try:
                    await asyncio.shield(release)
                except Exception:
                    pass
                raise
            except Exception:
                pass

    def _feed(self, generation: int, fragment: bytes) -> None:
        if generation != self._generation or self._pending is None:
            return
        self._buffer.extend(fragment)
        try:
            while len(self._buffer) >= 8:
                size = 8 + struct.unpack_from(">H", self._buffer, 2)[0]
                if len(self._buffer) < size:
                    return
                frame = bytes(self._buffer[:size])
                del self._buffer[:size]
                op, group, command, sequence, payload = decode_response(frame)
                expected, future = self._pending
                if (op, group, command, sequence) == expected and not future.done():
                    future.set_result(payload)
        except Exception as error:
            self._buffer.clear()
            if self._pending is not None and not self._pending[1].done():
                self._pending[1].set_exception(error)

    def _feed_nus(self, generation: int, packet: bytes) -> None:
        if generation != self._generation or self._nus_pending is None:
            return
        opcode, future = self._nus_pending
        if len(packet) >= 2 and packet[:2] == bytes((opcode, 2)) and not future.done():
            future.set_result(packet)

    async def request(self, op: int, group: int, command: int, payload: dict | None = None) -> dict:
        generation = self._generation
        async with self._lock:
            self._check(generation)
            sequence = self._sequence
            self._sequence = (sequence + 1) & 255
            frame = encode_request(op, group, command, sequence, payload or {})
            future = asyncio.get_running_loop().create_future()
            self._pending = ((op + 1, group, command, sequence), future)
            try:
                async def perform():
                    async with self._write_lock:
                        self._check(generation)
                        maximum = self._smp.max_write_without_response_size
                        if maximum < 1:
                            raise SmpError("Invalid SMP ATT write size")
                        for offset in range(0, len(frame), maximum):
                            self._check(generation)
                            await _with_timeout(self._client.write_gatt_char(
                                self._smp, frame[offset:offset + maximum], response=False), self.write_timeout)
                    result = await future
                    self._check(generation)
                    return check_response(result)
                return await _with_timeout(perform(), self.timeout)
            except SmpCommandError:
                raise
            except BaseException:
                await self.close()
                raise
            finally:
                if self._pending is not None and self._pending[1] is future:
                    self._pending = None
                self._buffer.clear()
                _settle(future)

    async def nus_request(self, opcode: int) -> bytes:
        generation = self._generation
        async with self._nus_lock:
            self._check(generation)
            future = asyncio.get_running_loop().create_future()
            self._nus_pending = (opcode, future)
            try:
                async def perform():
                    async with self._write_lock:
                        self._check(generation)
                        response = "write" in self._nus_write.properties
                        await _with_timeout(self._client.write_gatt_char(
                            self._nus_write, bytes((opcode, 1)), response=response), self.write_timeout)
                    packet = await future
                    self._check(generation)
                    return packet
                return await _with_timeout(perform(), min(self.timeout, 5.0))
            except BaseException:
                await self.close()
                raise
            finally:
                if self._nus_pending is not None and self._nus_pending[1] is future:
                    self._nus_pending = None
                _settle(future)

    async def identity(self, expected_address: str):
        info = parse_device_info(await self.nus_request(0x2A))
        if info is None or info.hardware_revision != 2:
            raise SmpError("Invalid R1 INFO identity")
        actual = parse_hardware_address(await self.nus_request(0x2D))
        if actual.upper() != expected_address.upper():
            raise SmpError("Connected R1 hardware address differs from the verified OTA target")
        return info


def _settle(future: asyncio.Future) -> None:
    if not future.done():
        future.cancel()
    elif not future.cancelled():
        future.exception()
