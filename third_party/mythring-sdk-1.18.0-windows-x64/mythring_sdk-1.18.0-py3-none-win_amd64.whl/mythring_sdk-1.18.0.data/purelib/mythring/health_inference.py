"""Exact portable evaluators for the bundled RF and sleep-stage tree models."""
from __future__ import annotations

import io
import json
import math
import struct
import zipfile


class StepRfModel:
    def __init__(self, data: bytes):
        self.data = data
        if len(data) < 52:
            raise ValueError("Truncated RF asset")
        magic, version, self.feature_count, self.trees, self.nodes = struct.unpack_from("<5I", data)
        self.base = 52 + self.trees * 4
        self.source_sha256 = data[20:52].hex()
        if magic != 0x31465253 or version != 1 or (self.feature_count, self.trees) not in ((42, 50), (12, 100)) or not 0 < self.nodes <= 100000 or len(data) != self.base + self.nodes * 28:
            raise ValueError("Unsupported/incomplete RF asset")

    def probability_walk(self, features) -> float:
        if len(features) != self.feature_count or not all(math.isfinite(value) for value in features):
            raise ValueError("Invalid RF features")
        total = 0.0
        for tree in range(self.trees):
            node = struct.unpack_from("<i", self.data, 52 + tree * 4)[0]
            for _ in range(16):
                if not 0 <= node < self.nodes:
                    raise ValueError("Invalid RF tree node")
                left, right, feature, threshold, value = struct.unpack_from("<iiidd", self.data, self.base + node * 28)
                if left < 0:
                    total += value
                    break
                if not 0 <= feature < self.feature_count:
                    raise ValueError("Invalid RF feature split")
                node = left if features[feature] <= threshold else right
            else:
                raise ValueError("RF tree exceeds maximum depth")
        return total / self.trees


class HealthDayModel:
    def __init__(self):
        self._models = {}

    def predict(self, features) -> float:
        dimension = len(features)
        if dimension not in (12, 42):
            raise ValueError("Unknown step profile")
        if dimension not in self._models:
            from .protected_models import load_model_bytes
            model = StepRfModel(load_model_bytes("step_rf12" if dimension == 12 else "step_rf"))
            expected = "e0ab000ccae0996297c9eda0b9dd558226c9b1735df395592b41cdeb62b71261" if dimension == 12 else "40a10ef13afb15d7d25896ce8954fb13e6f4bb9f40653218eec122623f0ec563"
            if model.feature_count != dimension or model.source_sha256 != expected:
                raise ValueError("Unexpected RF model profile")
            self._models[dimension] = model
        return self._models[dimension].probability_walk(features)


class GapwideHead:
    def __init__(self, data: bytes):
        if not 48 <= len(data) <= 2000000:
            raise ValueError("Invalid stage classifier size")
        magic, version, dimensions, count = struct.unpack_from("<4I", data)
        if (magic, version, dimensions) != (0x47483152, 1, 1883) or not 1 <= count <= 1000:
            raise ValueError("Unsupported stage classifier")
        self.baseline = struct.unpack_from("<4d", data, 16)
        if not all(math.isfinite(value) for value in self.baseline):
            raise ValueError("Invalid classifier baseline")
        self.trees = []
        cursor = 48
        for _ in range(count):
            if cursor + 8 > len(data):
                raise ValueError("Truncated classifier")
            klass, nodes = struct.unpack_from("<ii", data, cursor)
            cursor += 8
            if not 0 <= klass < 4 or not 1 <= nodes <= 255 or cursor + nodes * 30 > len(data):
                raise ValueError("Invalid classifier tree shape")
            rows = []
            for index in range(nodes):
                col, threshold, value, left, right, missing, leaf = struct.unpack_from("<iddiiBB", data, cursor)
                cursor += 30
                if not 0 <= col < 1883 or not math.isfinite(value) or math.isnan(threshold) or missing > 1 or leaf > 1 or (not leaf and not (index < left < nodes and index < right < nodes)):
                    raise ValueError("Invalid classifier tree node")
                rows.append((col, threshold, value, left, right, missing, leaf))
            self.trees.append((klass, rows))
        if cursor != len(data):
            raise ValueError("Trailing classifier bytes")

    def predict(self, features) -> list[float]:
        if len(features) != 1883:
            raise ValueError("Expected 1883 sleep-stage features")
        scores = list(self.baseline)
        for klass, rows in self.trees:
            node = 0
            for _ in rows:
                col, threshold, value, left, right, missing, leaf = rows[node]
                if leaf:
                    scores[klass] += value
                    break
                sample = features[col]
                node = left if (bool(missing) if math.isnan(sample) else sample <= threshold) else right
        maximum = max(scores)
        exp = [math.exp(value - maximum) for value in scores]
        return [value / sum(exp) for value in exp]


class HealthModelArchive:
    NAMES = {"sleepstaging_2_6_0.pt", "gapwide.bin", "staging_manifest.json", "profile.json"}

    def __init__(self):
        from .protected_models import load_model_bytes
        with zipfile.ZipFile(io.BytesIO(load_model_bytes("health"))) as archive:
            rows = archive.infolist()
            if len(rows) != len(self.NAMES) or {row.filename for row in rows} != self.NAMES or sum(row.file_size for row in rows) > 16 * 1024 * 1024:
                raise ValueError("Unsupported health model bundle")
            self.entries = {row.filename: archive.read(row) for row in rows}
        profile = json.loads(self.entries["profile.json"])
        if profile["ppg_sample_interval_ms"] != 80 or profile["acc_sample_interval_ms"] != 640 or profile["nightly_hrv_display"]:
            raise ValueError("Unsupported health model profile")

    def __getitem__(self, name):
        return self.entries[name]
