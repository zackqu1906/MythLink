"""Port of the frozen bedtime and sleep-stage post-processing pipeline."""
from __future__ import annotations

import io
import json
import math
from dataclasses import replace

from .health_models import HealthBedtime, HealthQuality as Q, HealthSleepEpoch
from .health_inference import GapwideHead, HealthModelArchive


def bridge_boundary_gaps(raw, temperatures):
    if len(raw) != len(temperatures) * 2:
        raise ValueError("Invalid bedtime timeline")
    output, i = list(raw), 0
    while i < len(raw):
        if raw[i] != -1:
            i += 1
            continue
        first = i
        while i < len(raw) and raw[i] == -1:
            i += 1
        if i - first > 2 or first == 0 or i == len(raw) or not 0 <= raw[first-1] <= 30 or not 0 <= raw[i] <= 30:
            continue
        values = temperatures[(first-1)//2:i//2+1]
        if all(2600 <= value <= 4000 for value in values) and max(values) - min(values) <= 100:
            output[first:i] = [max(raw[first-1], raw[i])] * (i-first)
    return output


class BedtimeDetector:
    """Exact ACC/temperature research state machine bundled in SDK 1.15.1."""
    def __init__(self):
        self.c = [0, 0, 0, 0, 0, 0, 60, 0, 0, 0, 0, 5, 60, 0]
        self.classes, self.warm = [3] * 256, [False] * 256
        self.cursor = self.temperature_count = 0
        self.temperature_mean = 0.0
        self.active = False
        self.major_start = self.major_end = self.latest_end = 0
        self.history, self.history_warm, self.history_blocked = [], [], []
        self.periods, self.trace = [], []

    @staticmethod
    def _add(c, index, delta):
        c[index] = max(0, min(255, c[index] + delta))

    def _class(self, i):
        return self.classes[i & 255]

    def _hot(self, i):
        return self.warm[i & 255]

    @staticmethod
    def _bad(kind):
        return kind in (0, 3)

    def _update(self, c, incoming, incoming_hot, offset, outgoing, outgoing_hot, forward):
        d = 1 if forward else -1
        add, bad = self._add, self._bad
        available = lambda k: ((offset + k) & 65535) < 256
        if outgoing_hot:
            add(c, 13, -d)
        if bad(outgoing):
            add(c, 6, -d)
        elif outgoing == 1:
            for j in range(6):
                add(c, j, -d)
        if incoming_hot:
            add(c, 13, d)
        if incoming == 1:
            add(c, 0, d)
        for k, j in zip((0x105, 0x10f, 0x13c, 0x15a, 0x1b4), (5, 4, 3, 2, 1)):
            if available(k-1) and self._class(offset + self.cursor + k) == 1:
                add(c, j, d)
        for k, j, sign in ((0x13c, 6, 1), (0x1ea, 11, -1), (0x1b3, 12, -1)):
            if not available(k-1) or bad(self._class(offset + self.cursor + k)):
                add(c, j, sign*d)
        for k, j in zip((0x1ea, 0x1e0, 0x195, 0x13b), (10, 9, 8, 7)):
            if available(k-1) and self._class(offset + self.cursor + k) == 1:
                add(c, j, -d)
        if incoming == 1:
            for j in range(7, 11):
                add(c, j, d)
        elif bad(incoming):
            add(c, 11, d)
            add(c, 12, d)

    def _historical(self, i):
        return self.history[i] if 0 <= i < len(self.history) else 3

    def _historical_warm(self, i):
        return self.history_warm[i] if 0 <= i < len(self.history_warm) else False

    def _reverse_historical(self, c, index):
        incoming, outgoing, d = self._historical(index), self._historical(index-241), -1
        add, bad = self._add, self._bad
        if self._historical_warm(index-241):
            add(c, 13, -d)
        if bad(outgoing):
            add(c, 6, -d)
        elif outgoing == 1:
            for j in range(6):
                add(c, j, -d)
        if self._historical_warm(index):
            add(c, 13, d)
        if incoming == 1:
            add(c, 0, d)
        for lag, j in zip((236, 226, 181, 151, 61), (5, 4, 3, 2, 1)):
            if self._historical(index-lag) == 1:
                add(c, j, d)
        for lag, j, sign in ((181, 6, 1), (7, 11, -1), (62, 12, -1)):
            if bad(self._historical(index-lag)):
                add(c, j, sign*d)
        for lag, j in zip((7, 17, 92, 182), (10, 9, 8, 7)):
            if self._historical(index-lag) == 1:
                add(c, j, -d)
        if incoming == 1:
            for j in range(7, 11):
                add(c, j, d)
        elif bad(incoming):
            add(c, 11, d)
            add(c, 12, d)

    def _backtrack_full(self, now):
        c, bias, n = self.c.copy(), min(self.c[13]*2, 200), len(self.history)
        oldest = max(0, n-900)
        for offset in range(-1, oldest-n-1, -1):
            index = n+offset
            self._reverse_historical(c, index)
            if self.history_blocked[index]:
                return now+(offset+2)*60000
            if offset >= -179:
                continue
            current = self._historical(index)
            dense = bias+83800 < c[0]*1000 or bias+31300 < c[8]*1000 or bias+4300 < c[9]*1000
            stop = current == 0 if dense else current == 0 or (current != 1 and self._historical(index-1) != 1 and c[10]*1000 <= bias+3550)
            if stop:
                extension, last_bad = 1, 0
                while True:
                    chosen = extension
                    if index-extension < oldest:
                        break
                    if self.history_blocked[index-extension]:
                        return now+(offset+2-extension)*60000
                    kind = self._historical(index-extension)
                    if self._bad(kind):
                        last_bad = extension
                    chosen = last_bad
                    if self._bad(kind) or extension > 88:
                        break
                    extension += 1
                return max(now+(oldest-n+1)*60000, now+(offset+1-chosen)*60000)
        return now+(oldest-n+1)*60000

    def _backtrack(self, now):
        c, bias, candidate = self.c.copy(), min(self.c[13]*2, 200), 0
        for offset in range(-1, -255, -1):
            available = ((offset+14) & 65535) < 256
            self._update(c, self._class(offset+self.cursor+256), self._hot(offset+self.cursor+256), offset-241,
                         self._class(offset+self.cursor+15) if available else 3,
                         self._hot(offset+self.cursor+15) if available else True, False)
            if offset < -179:
                current = self._class(offset+self.cursor+256)
                dense = bias+83800 < c[0]*1000 or bias+31300 < c[8]*1000 or bias+4300 < c[9]*1000
                stop = current == 0 if dense else current == 0 or (current != 1 and self._class(offset+self.cursor+255) != 1 and c[10]*1000 <= bias+3550)
                if stop:
                    extension, last_bad = 1, 0
                    while True:
                        chosen = extension
                        if ((offset-extension+255) & 65535) > 255:
                            break
                        kind = self._class(self.cursor+256+offset-extension)
                        if self._bad(kind):
                            last_bad = extension
                        chosen = last_bad
                        if self._bad(kind) or extension > 88:
                            break
                        extension += 1
                    candidate = now+(offset+1-chosen)*60000
                    if offset+1-chosen <= -255:
                        return self._backtrack_full(now)
                    break
        return self._backtrack_full(now) if candidate == 0 or candidate > now else candidate

    def _boundary(self, first):
        last_quiet = 0
        for i in range(60):
            kind = self._class(first+i)
            if self._bad(kind):
                return i if i else last_quiet+1
            if kind == 1:
                last_quiet = i
        return last_quiet+1

    def _candidate_end(self, now, start):
        end = self.major_end
        if not self.active:
            return end
        c = self.c.copy()
        self._add(c, 0, 1)
        for old in range(-241, 0):
            offset, index = old+1, old+1+self.cursor+256
            self._update(c, 3, False, offset, self._class(index), self._hot(index), True)
            probe = now+14400000-(old+241)*60000
            if start > probe:
                continue
            following = 3 if ((offset >> 8) & 255) < 255 else self._class(index+1)
            kind = self._class(index)
            if kind != 0 and not (self.major_start+10800000 < probe and c[0] < 85 and c[2] < 32 and c[4] < 5 and following != 1 and kind != 1 and c[5] < 2):
                continue
            last_quiet, last_bad, chosen = 0, 0, -old
            for i in range(60):
                chosen = -old
                if ((offset+i+255) & 65535) > 255:
                    break
                kind = self._class(index+i)
                if self._bad(kind):
                    last_bad = chosen = i
                    break
                if kind == 1:
                    last_quiet = i
                chosen = last_bad
            if chosen == 0:
                chosen = last_quiet+1
            end = now+(old+chosen+1)*60000
            break
        return now if end == 0 or end > now else end

    def _append(self, start, end):
        if start == 0 or end <= start or (self.latest_end and (end <= self.latest_end or start > self.latest_end and self.latest_end+900000 > end)):
            return
        self.periods.append([max(start, end-54000000), end])
        self.latest_end = end

    @staticmethod
    def classify(total, previous, temperature, lower):
        if total < 0:
            return 0
        short = lambda n: (n+32768) % 65536-32768
        difference = short(temperature-lower)
        triple = difference*3
        low = max(100, min(700, short(((triple+(1 if triple > -2 else 2)) >> 1)+100)))
        high = max(1000, min(2800, short(difference*4+2400)))
        return (3 if high <= total*100 else 2) if low < total*100 or low < previous*100 else 1

    @classmethod
    def detect(cls, start, motion, temperatures):
        if start < 86400000 or len(motion) != len(temperatures)*2 or len(temperatures) > 1440:
            raise ValueError("Invalid bedtime timeline")
        if any(value < 0 or value > 65535 for value in temperatures) or any(value < -1 or value > 31 for value in motion):
            raise ValueError("Invalid bedtime motion/temperature encoding")
        if not any(value > 0 for value in temperatures):
            raise ValueError("No valid temperature for bedtime inference")
        last, values = -1, list(motion)
        for i, temperature in enumerate(temperatures):
            if temperature > 0:
                last = max(last, i*2+1)
        for i, value in enumerate(values):
            if 1 <= value <= 30:
                last = max(last, i)
            if value == 0 and not any(temperatures[j] > 0 and i*30000-300000 <= j*60000+30000 <= i*30000+330000 for j in range(max(0, i//2-6), min(len(temperatures), i//2+7))):
                values[i] = 31
        detector = cls()
        detector._run(start, bridge_boundary_gaps(values, temperatures), temperatures, last+1)
        return detector

    def _run(self, start, motion, temperatures, count):
        import numpy as np
        total, previous, now = 0, 0, 0
        for i in range(count):
            raw = motion[i]
            temperature = 0 if raw == 31 or raw < 0 else temperatures[i//2]
            now = start+i*30000
            if temperature:
                old = self.temperature_count
                self.temperature_count += 1
                self.temperature_mean = float(np.float32(np.float32(temperature+np.float32(old*self.temperature_mean))/self.temperature_count))
            lower = 3200 if self.temperature_count < 1441 else int(self.temperature_mean)-250
            upper = 3450 if self.temperature_count < 1441 else int(self.temperature_mean)+250
            if raw < 0:
                total = -1
            elif total >= 0:
                total = (total+raw+128) % 256-128
            if i & 1:
                kind = self.classify(total, previous, temperature, lower)
                warm = ((lower+upper) >> 1) < temperature
                self.history.append(kind)
                self.history_warm.append(warm)
                self.history_blocked.append(raw < 0 or raw == 31 or motion[i-1] < 0 or motion[i-1] == 31)
                self.classes[self.cursor & 255], self.warm[self.cursor & 255] = kind, warm
                self.cursor = (self.cursor+1) & 65535
                self._update(self.c, kind, upper < temperature, 0xff0f, self._class(self.cursor+15), self._hot(self.cursor+15), True)
                previous, total = total, 0
                c = self.c
                if raw >= 0 and not self.active and c[1] > 99 and c[3] > 42 and c[6] < 11 and c[4] > 10 and c[5] > 3:
                    self.active, self.major_start, self.major_end = True, self._backtrack(now), 0
                if self.active:
                    oldest = self._class(self.cursor+15)
                    keep = oldest != 0 and (now-14400000 <= self.major_start+10800000 or c[0] > 84 or c[2] > 31 or c[4] > 4 or self._class(self.cursor+16) == 1 or oldest == 1 or c[5] > 1)
                    if not keep:
                        n = self._boundary(self.cursor+16)
                        self.active, self.major_end = False, now-14400000+n*60000
                        if self.major_end > self.major_start:
                            self._append(self.major_start, self._candidate_end(now, self.major_start))
                self.trace.append([now, kind, int(self.active), self.major_start, *c])
        if (not self.periods or self.active) and self.major_start:
            self._append(self.major_start, self._candidate_end(now, self.major_start))
        merged = []
        for start, end in sorted(self.periods):
            if not merged or merged[-1][1] < start:
                merged.append([start, end])
            else:
                merged[-1][1] = max(merged[-1][1], end)
        self.periods = [[max(a, b-54000000), b] for a, b in merged]


def cover_session(start, end, epochs, non_wear):
    output, cursor = [], start
    def missing(until):
        nonlocal cursor
        while cursor < until:
            stop = min(until, (cursor//300000+1)*300000)
            output.append(HealthSleepEpoch(cursor, None, None, False, False, Q.NON_WEAR if non_wear(cursor, stop) else Q.INSUFFICIENT_DATA, stop-cursor))
            cursor = stop
    for epoch in sorted(epochs, key=lambda e: e.start_utc_ms):
        if epoch.start_utc_ms >= start and epoch.start_utc_ms+epoch.duration_ms <= end:
            missing(epoch.start_utc_ms)
            output.append(epoch)
            cursor = epoch.start_utc_ms+epoch.duration_ms
    missing(end)
    return output


def extend_edges(start, end, epochs, beds, non_wear):
    added = []
    usable = lambda e: e.stage in ("LIGHT", "DEEP", "REM", "AWAKE") and e.quality in (Q.VALID, Q.GAP, Q.PROVISIONAL)
    for bed in beds:
        a, b = max(start, bed.start_utc_ms), min(end, bed.end_utc_ms)
        inside = sorted((e for e in epochs if e.start_utc_ms < b and e.start_utc_ms+e.duration_ms > a), key=lambda e: e.start_utc_ms)
        if b <= a or not inside:
            continue
        first, last = inside[0], inside[-1]
        if usable(first) and 0 < first.start_utc_ms-a < 300000 and not non_wear(a, first.start_utc_ms+first.duration_ms):
            added.append(replace(first, start_utc_ms=a, duration_ms=first.start_utc_ms-a, probabilities=None, estimated=True, quality=Q.GAP))
        last_end = last.start_utc_ms+last.duration_ms
        if usable(last) and 0 < b-last_end < 300000 and not non_wear(last.start_utc_ms, b):
            added.append(replace(last, start_utc_ms=last_end, duration_ms=b-last_end, probabilities=None, estimated=True, quality=Q.GAP))
    return sorted(epochs+added, key=lambda e: e.start_utc_ms)


def _beats(times, ibi, start, end):
    import numpy as np
    chosen, runs, nn, differences, selected_times = 0, 0, [], [], []
    previous, last, last_value = False, 0, 0
    for i, time in enumerate(times):
        selected = start <= time < end
        good = selected and ibi[i, 2] > 0
        chosen += int(selected)
        if good:
            value = float(ibi[i, 0])
            nn.append(value)
            selected_times.append(int(time))
            if len(nn) == 1 or time-last > 5000:
                runs += 1
            if previous and time-last < 5000:
                differences.append(float(np.float32(value-last_value)))
            last, last_value = time, value
        previous = good
    age = (end-selected_times[-1])/1000 if selected_times else math.nan
    span = (selected_times[-1]-selected_times[0])/1000 if len(selected_times) > 1 else math.nan
    slope = math.nan
    if len(selected_times) >= 5 and span > 0:
        x = [(time-selected_times[0])/1000 for time in selected_times]
        y = [60000/value for value in nn]
        xm, ym = sum(x)/len(x), sum(y)/len(y)
        slope = sum((a-xm)*(b-ym) for a, b in zip(x, y))/sum((a-xm)**2 for a in x)
    return chosen, runs, nn, differences, age, span, slope


def _mean(values):
    return sum(values)/len(values) if len(values) else math.nan


def _sd(values):
    mean = _mean(values)
    return math.sqrt(sum((value-mean)**2 for value in values)/len(values)) if len(values) else math.nan


def _quantile(values, q):
    if not len(values):
        return math.nan
    values = sorted(values)
    at = q*(len(values)-1)
    lo = int(at)
    return values[lo]+(values[min(lo+1, len(values)-1)]-values[lo])*(at-lo)


def gap_features(times, ibi, start, end):
    import numpy as np
    chosen, runs, nn, differences, age, span, slope = _beats(times, ibi, start, end)
    n, duration = len(nn), (end-start)/1000
    return np.asarray([chosen, n, n/max(chosen, 1), runs, min(sum(nn)/1000/duration, 1),
        _mean(nn), _quantile(nn, .5), _sd(nn) if n > 1 else math.nan,
        _quantile(nn, .75)-_quantile(nn, .25) if n > 1 else math.nan,
        _quantile(nn, 0), _quantile(nn, 1),
        math.sqrt(_mean([v*v for v in differences])) if len(differences) >= 3 else math.nan,
        sum(abs(v) > 50 for v in differences)/len(differences) if len(differences) >= 3 else math.nan,
        len(differences), age, span, slope, duration], dtype=np.float32)


def stage_features(timestamps, features, probabilities, columns, beat_times, ibi, burst_times, bursts, starts):
    import numpy as np
    timestamps, beat_times, burst_times = (np.asarray(v, dtype=np.int64) for v in (timestamps, beat_times, burst_times))
    features, probabilities, ibi, bursts = (np.asarray(v, dtype=np.float32) for v in (features, probabilities, ibi, bursts))
    features = features.reshape(len(timestamps), -1)
    probabilities, ibi, bursts = probabilities.reshape(-1, 5), ibi.reshape(-1, 3), bursts.reshape(-1, 18)
    if len(columns) != 171 or len(probabilities) != len(timestamps) or len(ibi) != len(beat_times) or len(bursts) != len(burst_times):
        raise ValueError("Invalid sleep feature shape")
    output, core = np.full((len(starts), 1883), np.nan, np.float32), np.zeros((len(starts), 185), np.float32)
    for k, start in enumerate(starts):
        end, x = start+300000, output[k]
        indices = np.flatnonzero((timestamps+15000 >= start) & (timestamps+15000 < end))
        if len(indices) != 10 or np.any(np.diff(timestamps[indices]) != 30000):
            raise ValueError("Incomplete half-minute model timeline")
        for j, column in enumerate(columns):
            values = [float(features[i, column]) for i in indices if math.isfinite(features[i, column])]
            x[342+j] = len(values)/10
            if values:
                total = np.float32(0)
                for value in values:
                    total = np.float32(total+np.float32(value))
                mean = float(total)/len(values)
                x[j], x[171+j] = mean, math.sqrt(sum((value-mean)**2 for value in values)/len(values))
        for j in range(4):
            total = np.float32(0)
            for i in indices:
                total = np.float32(total+probabilities[i, j+1])
            x[513+j] = total/np.float32(10)
        chosen, runs, nn, differences, _, _, _ = _beats(beat_times, ibi, start, end)
        age, minutes = math.nan, set()
        for i, time in enumerate(beat_times):
            if ibi[i, 2] > 0 and time < end:
                age = (end-time)/1000
                if time >= start:
                    minutes.add((time-start)//60000)
        extra = [chosen, len(nn), len(nn)/max(1, chosen), _quantile(nn, .5),
                 _sd(nn) if len(nn) > 1 else math.nan,
                 _quantile(nn, .75)-_quantile(nn, .25) if len(nn) > 1 else math.nan,
                 math.sqrt(_mean([v*v for v in differences])) if len(differences) >= 3 else math.nan,
                 age, len(minutes)/5, len(differences)]
        x[517:527], x[527:537] = extra, np.isfinite(extra)
        core[k, :171], core[k, 171:] = x[:171], x[513:527]
        selected = [i for i, time in enumerate(burst_times) if start <= time < end]
        duration = np.float32(0)
        for i in selected:
            duration = np.float32(duration+bursts[i, 0])
        x[997], x[998] = len(selected), duration
        for j in range(18):
            values = [float(bursts[i, j]) for i in selected if math.isfinite(bursts[i, j])]
            x[979+j] = len(values)/len(selected) if selected else 0
            if values:
                x[907+j], x[925+j], x[943+j], x[961+j] = _mean(values), _sd(values), min(values), max(values)
        for j, minutes in enumerate((1, 5, 10, 15)):
            values = gap_features(beat_times, ibi, end-minutes*60000, end)
            x[1739+j*18:1757+j*18] = values
            x[1811+j*18:1829+j*18] = np.isfinite(values)
    for k, start in enumerate(starts):
        for lag, at in zip((-1, 1, -3, -2, 2, 3), (537, 722, 999, 1184, 1369, 1554)):
            other = k+lag
            if 0 <= other < len(starts) and starts[other]-start == lag*300000:
                output[k, at:at+185] = core[other]
    return output


def stage_input_quality(valid_beats, good_motion, good_temperature, non_wear):
    if non_wear:
        return Q.NON_WEAR
    if good_motion < 9 or good_temperature < 9:
        return Q.INSUFFICIENT_DATA
    return Q.VALID if valid_beats >= 12 and good_motion >= 10 and good_temperature >= 10 else Q.GAP


def decode_stages(starts, predictions, qualities, end, complete):
    blocked = [quality in (Q.NON_WEAR, Q.INSUFFICIENT_DATA) for quality in qualities]
    labels, estimated = [-2]*len(starts), [False]*len(starts)
    for i, prediction in enumerate(predictions):
        if blocked[i]:
            labels[i] = -1
        elif prediction is not None:
            if len(prediction) != 4 or any(not math.isfinite(v) or not 0 <= v <= 1 for v in prediction):
                raise ValueError("Invalid sleep stage probabilities")
            labels[i] = max(range(4), key=lambda k: prediction[k])
    for i, prediction in enumerate(predictions):
        if blocked[i] or prediction is not None:
            continue
        low, high = i-1, i+1
        while low >= 0 and not blocked[low] and predictions[low] is None:
            low -= 1
        while high < len(starts) and not blocked[high] and predictions[high] is None:
            high += 1
        left, right = low >= 0 and not blocked[low], high < len(starts) and not blocked[high]
        if left or right:
            scores = [(predictions[low][k]/(i-low) if left else 0)+(predictions[high][k]/(high-i) if right else 0) for k in range(4)]
            labels[i], estimated[i] = max(range(4), key=lambda k: scores[k]), True
    output = []
    for i, start in enumerate(starts):
        label = ("DEEP", "LIGHT", "REM", "AWAKE")[labels[i]] if labels[i] >= 0 else None
        estimate = label is not None and (estimated[i] or qualities[i] == Q.GAP)
        provisional = not complete and start+300000 > end-900000
        quality = Q.NON_WEAR if qualities[i] == Q.NON_WEAR else Q.INSUFFICIENT_DATA if label is None else Q.GAP if estimate else Q.PROVISIONAL if provisional else Q.VALID
        output.append(HealthSleepEpoch(int(start), label, None if blocked[i] else predictions[i], estimate, provisional, quality))
    return output


class HealthSleepModel:
    def __init__(self):
        self.archive = self.module = self.head = self.columns = None

    @staticmethod
    def can_run(start, end, motion_count, beat_count, temperature_count):
        return (start+299999)//300000*300000+300000 <= end and motion_count >= 2 and beat_count >= 4 and temperature_count >= 2

    def _load(self):
        if self.module is None:
            import torch
            from .health_sleep_ops import register_sleep_ops
            register_sleep_ops()
            self.archive = HealthModelArchive()
            self.head = GapwideHead(self.archive["gapwide.bin"])
            self.columns = json.loads(self.archive["staging_manifest.json"])["pooled_columns"]
            self.module = torch.jit.load(io.BytesIO(self.archive["sleepstaging_2_6_0.pt"]), map_location="cpu").eval()

    def run(self, start, end, motion, motion_times, ibi, beat_times, temperature, temperature_times,
            bursts, burst_times, periods, complete, non_wear):
        import numpy as np
        import torch
        if not self.can_run(start, end, len(motion_times), len(beat_times), len(temperature)):
            return []
        self._load()
        motion, ibi, temperature, bursts = (np.asarray(v, dtype=np.float32) for v in (motion, ibi, temperature, bursts))
        motion, ibi, bursts = motion.reshape(-1, 6), ibi.reshape(-1, 3), bursts.reshape(-1, 18)
        motion_times, beat_times, temperature_times = (np.asarray(v, dtype=np.int64) for v in (motion_times, beat_times, temperature_times))
        with torch.inference_mode():
            result = self.module(torch.from_numpy(motion), torch.from_numpy(motion_times), torch.from_numpy(ibi),
                torch.from_numpy(beat_times), torch.from_numpy(temperature), torch.from_numpy(temperature_times),
                torch.tensor([20., 24.220226, 1.], dtype=torch.float32), torch.tensor([start, end], dtype=torch.int64), False, False)
        if len(result) < 3:
            raise ValueError("Unexpected sleep model output")
        times, probabilities, features = (v.detach().cpu().numpy() for v in result[:3])
        times, probabilities = times.reshape(-1), probabilities.reshape(-1, 5)
        if not len(times) or features.size % len(times) or len(probabilities) != len(times):
            raise ValueError("Invalid sleep model row shape")
        features = features.reshape(len(times), -1)
        keep = np.isfinite(probabilities).all(axis=1)
        times, probabilities, features = times[keep], probabilities[keep], features[keep]
        if not len(times):
            return []
        if len(self.columns) != 171 or not all(0 <= column < features.shape[1] for column in self.columns):
            raise ValueError("Invalid sleep pooled columns")
        output = []
        for period in periods:
            first = max((start+299999)//300000*300000, period.start_utc_ms//300000*300000)
            until = min(end, (period.end_utc_ms+299999)//300000*300000)
            starts = [t for t in range(first, until-299999, 300000) if np.count_nonzero((times+15000 >= t) & (times+15000 < t+300000)) == 10]
            if not starts:
                continue
            inputs = stage_features(times, features, probabilities, self.columns, beat_times, ibi, burst_times, bursts, starts)
            predictions, qualities = [], []
            for i, s in enumerate(starts):
                beats = np.count_nonzero((beat_times >= s) & (beat_times < s+300000) & (ibi[:, 2] > 0))
                good_motion = np.count_nonzero((motion_times >= s) & (motion_times < s+300000) & np.isfinite(motion).all(axis=1))
                good_temperature = np.count_nonzero((temperature_times >= s) & (temperature_times < s+300000) & np.isfinite(temperature))
                quality = stage_input_quality(beats, good_motion, good_temperature, non_wear(s, s+300000))
                qualities.append(quality)
                predictions.append(self.head.predict(inputs[i]) if quality in (Q.VALID, Q.GAP) else None)
            for epoch in decode_stages(starts, predictions, qualities, end, complete):
                a, b = max(epoch.start_utc_ms, period.start_utc_ms, start), min(epoch.start_utc_ms+epoch.duration_ms, period.end_utc_ms, end)
                if b > a:
                    output.append(replace(epoch, start_utc_ms=a, duration_ms=b-a))
        return output
