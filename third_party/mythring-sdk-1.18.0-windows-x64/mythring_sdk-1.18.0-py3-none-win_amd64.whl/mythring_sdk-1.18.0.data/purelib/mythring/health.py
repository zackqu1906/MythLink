"""Async health transport, monitoring controls and firmware live-heart capture.

Downloaded recordings contain validated raw records, not Android ML reports.
Downloads never ACK or delete device history.
"""
from __future__ import annotations

import asyncio
import secrets
import struct
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Awaitable, Callable
from pathlib import Path

from .health_archive import HealthArchiveClientMixin
from .health_models import *

from .health_protocol import (
    COMMAND, MAX_FILE, HealthBlock, HealthCapabilities, HealthCompactWindow,
    HealthError, HealthFeature, HealthLiveHeart, HealthMonitoringSettings,
    HealthRecording, HealthState, HealthWindow, decode_compact, decode_delta,
    read_block, read_blocks, request_packet,
)


@dataclass(frozen=True)
class HealthDownload:
    recording: HealthRecording
    data: bytes
    blocks: tuple[HealthBlock, ...]


@dataclass(frozen=True)
class HealthWearStatus:
    state: int
    retry_level: int
    charging: bool
    monitoring: bool
    uptime_ms: int
    evidence_age_ms: int | None
    boot_id: int
    received_at_utc_ms: int

    @classmethod
    def decode(cls, data: bytes) -> HealthWearStatus:
        if len(data) != 20:
            raise ValueError("Invalid wear status length")
        state, retry, charging, monitoring, uptime, evidence, boot = struct.unpack("<BBBBIIQ", data)
        if state not in (0, 1, 2) or charging not in (0, 1) or monitoring not in (0, 1):
            raise ValueError("Invalid wear status")
        return cls(state, retry, bool(charging), bool(monitoring), uptime,
                   None if evidence == 0 else (uptime - evidence) & 0xFFFFFFFF,
                   boot, time.time_ns() // 1_000_000)


class HealthClient(HealthArchiveClientMixin):
    """One client per ring; call ``accept`` on that ring's command notifications.

    ``send`` sends a complete command frame. ``mtu`` returns the negotiated BLE
    MTU, including its three-byte ATT header. Callbacks are synchronous and run
    on the client's asyncio event loop.
    """

    def __init__(self, send: Callable[[bytes], Awaitable[None]], mtu: Callable[[], int] | None = None,
                 *, address: str = "local-device", storage_path: str | Path | None = None):
        self._send = send
        self._mtu = mtu or (lambda: 247)
        self._transaction = 0
        self._pending: dict[int, tuple[int, asyncio.Future[bytes], HealthWindow | HealthCompactWindow | None]] = {}
        self._capabilities: HealthCapabilities | None = None
        self.state = HealthState()
        self.connection_checked = False
        self._connection_live = True
        self._epoch = 0
        self._operations = asyncio.Lock()
        self._clock_reply: asyncio.Future[tuple[int, int]] | None = None
        self._heart_cancel: asyncio.Event | None = None
        self._sync_callers = 0
        self._initialize_archive(address, storage_path)

    @property
    def blocks_sensor_start(self) -> bool:
        return not self.connection_checked or self.state.recording

    @property
    def blocks_swipe_start(self) -> bool:
        return (not self.connection_checked or self._heart_cancel is not None or self.state.manual or
                (self.state.recording and not (self._capabilities and self._capabilities.automatic)))

    def disconnected(self) -> None:
        self._epoch += 1
        self._connection_live = False
        self.connection_checked = False
        self._capabilities = None
        self.state = HealthState()
        for _, future, _ in self._pending.values():
            if not future.done():
                future.set_exception(HealthError(-107, "Ring disconnected"))
        if self._clock_reply is not None and not self._clock_reply.done():
            self._clock_reply.set_exception(HealthError(-107, "Ring disconnected"))

    def connection_opened(self) -> None:
        """Mark a new transport ready before starting async health negotiation."""
        self._epoch += 1
        self._connection_live = True
        self.connection_checked = False
        self._capabilities = None
        self.state = HealthState()

    @asynccontextmanager
    async def _operation(self, require_connection=True):
        epoch = self._epoch
        scope = self._scope_generation
        async with self._operations:
            if epoch != self._epoch or (require_connection and not self._connection_live) or scope != self._scope_generation:
                raise HealthError(-107, "Device session changed while waiting for health operation")
            self._operation_scope = scope
            try:
                yield
            finally:
                self._operation_scope = None

    async def connected(self) -> None:
        """Negotiate health after ``connection_opened``; does not reset the epoch."""
        async with self._operation():
            try:
                await self.get_capabilities()
                await self.refresh_status()
            except HealthError as error:
                if error.device_code != -95:
                    raise
                self.state = HealthState()
                self.connection_checked = True

    def accept(self, packet: bytes) -> bool:
        """Consume a notification; return False if another protocol owns it."""
        if len(packet) >= 19 and packet[:2] == b"\x23\x02":
            if packet[2] == 1 and self._clock_reply is not None and not self._clock_reply.done():
                self._clock_reply.set_result(struct.unpack_from("<qq", packet, 3))
            return True
        if not packet or packet[0] != COMMAND:
            return False
        if len(packet) < 8:
            return True
        tx = struct.unpack_from("<I", packet, 4)[0]
        pending = self._pending.get(tx)
        if packet[1] == 0x93:
            if pending is not None and pending[0] == 19 and not pending[1].done():
                try:
                    window = pending[2]
                    if not isinstance(window, HealthCompactWindow):
                        raise ValueError("Missing compact health transfer")
                    data = window.consume(packet, tx)
                    if data is not None:
                        pending[1].set_result(data)
                except Exception as error:
                    pending[1].set_exception(error)
            return True
        if len(packet) < 10 or packet[2:4] != b"\x01\x00":
            return True
        error = struct.unpack_from("<h", packet, 8)[0]
        if tx == 0 and packet[1] == 0x81 and len(packet) in (26, 40) and error == 0:
            self.state = HealthState.decode(packet[10:])
            return True
        if pending is None or pending[1].done() or packet[1] != pending[0] | 0x80:
            return True
        operation, future, window = pending
        if error < 0:
            future.set_exception(HealthError(error, f"Health command {operation} failed ({error})", operation))
        else:
            try:
                payload = packet[10:]
                result = window.consume(payload) if isinstance(window, HealthWindow) else payload
                if result is not None:
                    future.set_result(result)
            except Exception as failure:
                future.set_exception(failure)
        return True

    async def _request(self, operation: int, payload: bytes = b"", *,
                       window: HealthWindow | HealthCompactWindow | None = None) -> bytes:
        if not self._connection_live:
            raise HealthError(-107, "Ring disconnected", operation)
        if self._operation_scope is not None and self._operation_scope != self._scope_generation:
            raise HealthError(-125, "Health account scope changed", operation)
        epoch = self._epoch
        scope = self._scope_generation
        self._transaction = self._transaction % 0xFFFFFFFF + 1
        tx = self._transaction
        future: asyncio.Future[bytes] = asyncio.get_running_loop().create_future()
        self._pending[tx] = (operation, future, window)
        timeout = 60 if operation in (8, 10, 20, 22) else 8

        async def perform() -> bytes:
            await self._send(request_packet(operation, tx, payload))
            return await future

        try:
            result = await asyncio.wait_for(perform(), timeout)
            if epoch != self._epoch or not self._connection_live:
                raise HealthError(-107, "Device session changed", operation)
            if scope != self._scope_generation:
                raise HealthError(-125, "Health account scope changed", operation)
            return result
        except asyncio.TimeoutError as error:
            raise HealthError(-110, f"Health command {operation} timed out; query device state before retrying", operation) from error
        finally:
            self._pending.pop(tx, None)
            if not future.done():
                future.cancel()
            elif not future.cancelled():
                future.exception()

    async def get_capabilities(self) -> HealthCapabilities:
        if self._capabilities is None:
            self._capabilities = HealthCapabilities.decode(await self._request(0))
        return self._capabilities

    async def refresh_status(self) -> HealthState:
        self.state = HealthState.decode(await self._request(1))
        self.connection_checked = True
        return self.state

    async def get_monitoring_settings(self) -> HealthMonitoringSettings | None:
        async with self._operation():
            if not (await self.get_capabilities()).monitoring_settings_supported:
                return None
            return HealthMonitoringSettings.decode(await self._request(21))

    async def set_monitoring_settings(self, settings: HealthMonitoringSettings) -> HealthMonitoringSettings:
        payload = settings.encode()
        async with self._operation():
            if not (await self.get_capabilities()).monitoring_settings_supported:
                raise HealthError(-95, "Firmware does not support health settings", 22)
            confirmed = HealthMonitoringSettings.decode(await self._request(22, payload))
            if confirmed != settings:
                raise ValueError("Ring health settings acknowledgement mismatch")
            return confirmed

    async def get_wear_status(self) -> HealthWearStatus | None:
        async with self._operation():
            if not (await self.get_capabilities()).flags & (1 << 21):
                return None
            return HealthWearStatus.decode(await self._request(17))

    async def _set_clock(self) -> tuple[int, int]:
        sent = time.time_ns() // 1_000_000
        future: asyncio.Future[tuple[int, int]] = asyncio.get_running_loop().create_future()
        self._clock_reply = future
        try:
            await self._send(struct.pack("<BBq", 0x23, 0, sent))
            utc, uptime = await asyncio.wait_for(future, 8)
            received = time.time_ns() // 1_000_000
            if not sent - 1000 <= utc <= received + 1000 or received - utc > 5000:
                raise ValueError("Invalid clock acknowledgement")
            return utc, uptime
        except asyncio.TimeoutError as error:
            raise HealthError(-110, "Clock acknowledgement timed out") from error
        finally:
            self._clock_reply = None
            if not future.done():
                future.cancel()
            elif not future.cancelled():
                future.exception()

    async def synchronize_clock(self) -> tuple[int, int]:
        """Set device UTC and return (boot ID, UTC minus uptime in ms)."""
        async with self._operation():
            if not (await self.get_capabilities()).automatic:
                raise HealthError(-95, "Automatic health firmware required")
            before = await self.refresh_status()
            utc, uptime = await self._set_clock()
            after = await self.refresh_status()
            if not after.time_known or after.boot_id != before.boot_id or after.boot_id == 0 or not 0 <= uptime <= 0xFFFFFFFF:
                raise ValueError("Clock acknowledgement missing or device rebooted")
            self.store.save_clock(after.boot_id, utc - uptime)
            return after.boot_id, utc - uptime

    async def start_recording(self) -> int:
        async with self._operation():
            await self.get_capabilities()
            if (await self.refresh_status()).recording:
                raise HealthError(-16, "Health recording already active")
            self.connection_checked = False
            await self._set_clock()
            data = await self._request(2)
            if len(data) != 4:
                raise ValueError("Invalid recording ID")
            await self.refresh_status()
            return struct.unpack("<I", data)[0]

    async def stop_recording(self) -> None:
        async with self._operation():
            await self._request(3)
            await self.refresh_status()

    async def list_recordings(self) -> list[HealthRecording]:
        async with self._operation():
            return await self._list_recordings()

    async def _list_recordings(self) -> list[HealthRecording]:
        automatic = (await self.get_capabilities()).automatic
        records, after = [], 0
        for index in range(65536 if automatic else 256):
            try:
                payload = await self._request(9 if automatic else 4, struct.pack("<I", after) if automatic else bytes((index,)))
            except HealthError as error:
                if error.device_code == -2:
                    return records
                raise
            record = HealthRecording.decode(payload)
            if automatic:
                if len(payload) != 26:
                    raise ValueError("Invalid automatic health directory entry")
                next_after = struct.unpack_from("<I", payload, 22)[0]
                if next_after <= after:
                    raise ValueError("Health directory did not advance")
                after = next_after
            if record.mode in (6, 7):
                records.append(record)
        raise ValueError("Health directory exceeds protocol limit")

    async def download_recording(self, recording: HealthRecording | int,
                                 on_progress: Callable[[int, int], None] | None = None) -> HealthDownload:
        """Download a sealed recording and verify every record; no ACK/DELETE.

        The returned bytes may be written to a local file by the caller. History
        inference, persistent resume and device reclamation are separate from
        this transport API.
        """
        self._sync_callers += 1
        try:
            async with self._operation():
                if isinstance(recording, int):
                    records = await self._list_recordings()
                    record = next((value for value in records if value.id == recording), None)
                    if record is None:
                        raise HealthError(-2, "Recording not found")
                else:
                    record = recording
                if not 0 < record.id <= 0xFFFFFFFF or record.status not in (1, 2, 3):
                    raise ValueError("Download requires a sealed recording")
                caps = await self.get_capabilities()
                maximum = min(caps.max_read_bytes, self._mtu() - 26)
                if maximum <= 0:
                    raise ValueError("BLE MTU too small for health transfer")

                def args(offset: int, total: int) -> bytes:
                    return struct.pack("<IIIH", record.id, offset, total, maximum)

                initial = await self._request(5, args(0, 0))
                if len(initial) < 13:
                    raise ValueError("Truncated health snapshot")
                record_id, start, total, status = struct.unpack_from("<IIIB", initial)
                if record_id != record.id or start != 0 or not 0 < total <= MAX_FILE or status not in (1, 2, 3):
                    raise ValueError("Invalid sealed health snapshot")
                if record.mode == 7 and (record.bytes != total or record.status != status):
                    raise ValueError("Immutable health snapshot changed")
                result = bytearray()
                window_cap, compact_cap = min(470, self._mtu() - 28), min(479, self._mtu() - 19)
                use_window = bool(caps.flags & (1 << 11)) and window_cap > 0
                use_compact = use_window and bool(caps.flags & (1 << 25)) and compact_cap > 0
                credit_limit = 32 if caps.flags & (1 << 12) else 8
                while len(result) < total:
                    offset = len(result)
                    if use_window:
                        sizes = list(dict.fromkeys((credit_limit, min(credit_limit, 8), 1)))
                        for attempt, credits in enumerate(sizes):
                            try:
                                if use_compact:
                                    payload = struct.pack("<IIIHBB", record.id, offset, total, compact_cap, credits, status)
                                    reply = await self._request(19, payload, window=HealthCompactWindow(record.id, offset, total, status, compact_cap, credits))
                                else:
                                    payload = struct.pack("<IIIHB", record.id, offset, total, window_cap, credits)
                                    reply = await self._request(11, payload, window=HealthWindow(record.id, offset, total, window_cap, credits))
                                credit_limit = credits
                                break
                            except HealthError as error:
                                if error.device_code != -110 or error.operation not in (11, 19) or attempt == len(sizes) - 1:
                                    raise
                    else:
                        reply = initial if offset == 0 else await self._request(5, args(offset, total))
                    if len(reply) <= 13 or struct.unpack_from("<IIIB", reply) != (record.id, offset, total, status) or offset + len(reply) - 13 > total:
                        raise ValueError("Health transfer snapshot changed")
                    result.extend(reply[13:])
                    if on_progress is not None:
                        on_progress(len(result), total)
                data = bytes(result)
                blocks = tuple(read_blocks(data, require_end=status == 1))
                return HealthDownload(HealthRecording(record.id, status, total, record.start_utc_ms, record.duration_ms, record.mode), data, blocks)
        finally:
            self._sync_callers -= 1

    def cancel_live_heart(self) -> bool:
        """Request cancellation; only the returned terminal frame proves LED off."""
        if self._heart_cancel is None:
            return False
        self._heart_cancel.set()
        return True

    async def measure_live_heart(self, on_value: Callable[[HealthLiveHeart], None] | None = None) -> HealthLiveHeart:
        if self._sync_callers or self._operations.locked():
            raise HealthError(-16, "Health synchronization or another operation is in progress")
        async with self._operation():
            if not (await self.get_capabilities()).live_heart_supported:
                raise HealthError(-95, "Live heart firmware required")
            epoch = self._epoch
            token = secrets.randbelow(0x7FFFFFFE) + 1
            terminal = False
            self._heart_cancel = cancellation = asyncio.Event()

            async def request(action: int) -> HealthLiveHeart:
                return HealthLiveHeart.decode(await self._request(16, struct.pack("<BI", action, token)), token)

            async def measure() -> HealthLiveHeart:
                nonlocal terminal
                cancel_sent = False
                value = await request(1)
                while True:
                    if epoch != self._epoch or not self._connection_live:
                        raise HealthError(-107, "Device session changed")
                    if value.state >= 3 and not value.light:
                        self._heart_cancel = None
                        terminal = True
                    if on_value is not None:
                        on_value(value)
                    if terminal:
                        return value
                    if cancel_sent:
                        await asyncio.sleep(0.1)
                    else:
                        try:
                            await asyncio.wait_for(cancellation.wait(), 0.5)
                        except asyncio.TimeoutError:
                            pass
                    action = 2 if not cancel_sent and cancellation.is_set() else 0
                    cancel_sent = cancel_sent or action == 2
                    value = await request(action)

            async def stop() -> None:
                stopped = await request(2)
                while stopped.state < 3 or stopped.light:
                    await asyncio.sleep(0.1)
                    stopped = await request(0)

            try:
                return await asyncio.wait_for(measure(), 26)
            except asyncio.TimeoutError as error:
                raise HealthError(-110, "Live heart measurement timed out", 16) from error
            finally:
                self._heart_cancel = None
                if not terminal and self._connection_live and epoch == self._epoch:
                    # Cancellation cleanup is bounded and stays under the operation lock.
                    cleanup = asyncio.create_task(asyncio.wait_for(stop(), 2))
                    try:
                        await asyncio.shield(cleanup)
                    except asyncio.CancelledError:
                        try:
                            await cleanup
                        except (Exception, asyncio.CancelledError):
                            pass
                        raise
                    except Exception:
                        pass


__all__ = [
    "HealthClient", "HealthError", "HealthBlock", "HealthCapabilities", "HealthState",
    "HealthRecording", "HealthDownload", "HealthWearStatus", "HealthFeature",
    "HealthMonitoringSettings", "HealthLiveHeart", "HealthWindow", "HealthCompactWindow",
    "request_packet", "read_block", "read_blocks", "decode_delta", "decode_compact",
    "HealthMetric", "HealthReport", "HealthValue", "HealthRri", "HealthActivity",
    "HealthBedtime", "HealthSleepEpoch", "HealthWearEvent", "HealthWearStateEvent",
    "HealthTemperatureSample", "HealthSyncProgress", "HealthTiming", "HealthCoverage",
    "HealthLossRange", "HealthDailySummary", "HealthQuality", "HealthSource",
]
