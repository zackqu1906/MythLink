import json
import re
import struct
from dataclasses import dataclass
from importlib.resources import as_file, files
from pathlib import Path, PurePosixPath
from tempfile import TemporaryDirectory
from zipfile import BadZipFile, ZipFile

from ring_python_sdk_r1._protocol import RingError, normalize_firmware_version
from smpclient.mcuboot import IMAGE_F, IMAGE_TLV, ImageInfo, MCUBootImageError

MAX_FIRMWARE_BYTES = 64 * 1024 * 1024
MAX_METADATA_BYTES = 64 * 1024
_BUNDLED_FIRMWARE_NAME = "RG101_1.00.021-20261119-100202.zip"
SIGNATURES = {IMAGE_TLV.RSA2048_PSS, IMAGE_TLV.RSA3072_PSS, IMAGE_TLV.ECDSA_SIG, IMAGE_TLV.ED25519}
DIGESTS = {IMAGE_TLV.SHA256: 32, IMAGE_TLV.SHA384: 48, IMAGE_TLV.SHA512: 64}


@dataclass(frozen=True)
class FirmwareImage:
    path: Path
    data: bytes
    image_version: str
    runtime_version: str | None
    digest: bytes

    @property
    def version(self) -> str:
        return self.runtime_version or self.image_version


def image_version(value: str) -> tuple[int, int, int, int]:
    match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:[.+](\d+))?", value, re.ASCII)
    if match is None:
        raise RingError("invalid_image_state", f"Invalid MCUboot version {value}")
    parts = match.groups(default="0")
    return int(parts[0]), int(parts[1]), int(parts[2]), int(parts[3])


def _runtime_version(data: bytes) -> str | None:
    metadata = json.loads(data)
    if not isinstance(metadata, dict):
        raise ValueError("Invalid build-info.json")
    name, info, display, variant = (
        metadata.get(key) or ""
        for key in ("firmwareName", "infoVersion", "displayVersion", "variant")
    )
    if any(not isinstance(value, str) for value in (name, info, display, variant)):
        raise ValueError("Invalid version metadata")
    if name.strip() or info.endswith(".zip"):
        return normalize_firmware_version(name.strip() or info)
    if display.strip() and variant in ("debug", "release", "preview"):
        return f"{display}.{variant}"
    return info.strip() or None


def _read_package(path: Path) -> tuple[bytes, str | None]:
    if not path.is_file() or not 1 <= path.stat().st_size <= MAX_FIRMWARE_BYTES:
        raise ValueError("Select a local signed BIN or ZIP no larger than 64 MiB")
    if path.suffix.lower() == ".bin":
        with path.open("rb") as stream:
            return stream.read(MAX_FIRMWARE_BYTES + 1), None
    if path.suffix.lower() != ".zip":
        raise ValueError("Select a signed BIN or ZIP")
    with ZipFile(path) as archive:
        files = [item for item in archive.infolist() if not item.is_dir()]
        images = [
            item
            for item in files
            if PurePosixPath(item.filename).name.lower().endswith(".signed.bin")
        ]
        metadata = [
            item for item in files if PurePosixPath(item.filename).name.lower() == "build-info.json"
        ]
        if len(images) != 1 or len(metadata) > 1:
            raise ValueError("ZIP must contain one *.signed.bin and at most one build-info.json")
        if not 1 <= images[0].file_size <= MAX_FIRMWARE_BYTES:
            raise ValueError("Signed image exceeds the firmware size limit")
        if metadata and metadata[0].file_size > MAX_METADATA_BYTES:
            raise ValueError("Firmware metadata exceeds 64 KiB")
        version = _runtime_version(archive.read(metadata[0])) if metadata else None
        return archive.read(images[0]), version


def load_firmware(path: Path) -> FirmwareImage:
    path = path.expanduser().absolute()
    try:
        data, runtime_version = _read_package(path)
        if not 32 <= len(data) <= MAX_FIRMWARE_BYTES:
            raise ValueError("Invalid MCUboot file size")
        _, _, header_size, protected_size, payload_size = struct.unpack_from("<IIHHI", data)
        if (
            header_size < 32
            or payload_size == 0
            or header_size + payload_size + protected_size + 4 > len(data)
        ):
            raise ValueError("Truncated MCUboot image or TLV")
        with TemporaryDirectory(prefix="r1-image-") as directory:
            binary = Path(directory) / "firmware.bin"
            binary.write_bytes(data)
            parsed = ImageInfo.load_file(str(binary))
        header = parsed.header
        if header.load_addr != 0 or int(header.flags) & (0x100 | IMAGE_F.NON_BOOTABLE):
            raise ValueError("Incompatible R1 flash layout or non-bootable image")
        tlvs = {row.header.type: row.value for row in parsed.tlvs}
        hashes = [(kind, tlvs[kind]) for kind in DIGESTS if kind in tlvs]
        if len(hashes) != 1 or len(hashes[0][1]) != DIGESTS[hashes[0][0]]:
            raise ValueError("Image is missing a valid MCUboot hash TLV")
        if not any(tlvs.get(kind) for kind in SIGNATURES):
            raise ValueError("Image is missing a signature TLV")
        version = header.ver
        return FirmwareImage(
            path,
            data,
            f"{version.major}.{version.minor}.{version.revision}+{version.build_num}",
            runtime_version,
            hashes[0][1],
        )
    except (
        ValueError,
        OSError,
        RuntimeError,
        BadZipFile,
        MCUBootImageError,
        struct.error,
    ) as error:
        raise RingError("invalid_firmware", str(error)) from error


def load_bundled_firmware() -> FirmwareImage:
    """Load the signed R1 firmware package included with the SDK."""
    resource = files("ring_python_sdk_r1").joinpath("assets", _BUNDLED_FIRMWARE_NAME)
    try:
        with as_file(resource) as path:
            return load_firmware(path)
    except OSError as error:
        raise RingError("invalid_firmware", "The bundled R1 firmware package is missing") from error
