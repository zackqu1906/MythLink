import asyncio
import sys
from collections.abc import Callable

from bleak import BleakClient
from bleak.exc import BleakError
from ring_python_sdk_r1._protocol import (
    CCC,
    NUS_NOTIFY,
    NUS_REQUEST,
    RingError,
)


class Gatt:
    def __init__(self, device, disconnected: Callable, notify: Callable):
        self.client = BleakClient(device, disconnected_callback=lambda _: disconnected(self))
        self.notify = notify
        self.att = asyncio.Lock()
        self.disconnected = asyncio.Event()
        self.active = True
        self._reply = None
        self._write_with_response = True

    async def open(self):
        async with asyncio.timeout(30):
            await self.client.connect()
        request = self.client.services.get_characteristic(NUS_REQUEST)
        if request is None or self.client.services.get_characteristic(NUS_NOTIFY) is None:
            raise RingError("unsupported_device", "R1 business characteristics unavailable")
        self._write_with_response = "write" in request.properties
        if not self._write_with_response and "write-without-response" not in request.properties:
            raise RingError(
                "unsupported_device", "R1 business command characteristic is not writable"
            )

    async def subscribe(self):
        async with asyncio.timeout(20):
            await self.client.start_notify(NUS_NOTIFY, self._receive)

    def invalidate(self):
        self.active = False
        self.disconnected.set()
        if self._reply and not self._reply[1].done():
            self._reply[1].set_exception(RingError("disconnected"))

    async def close(self):
        self.invalidate()
        if self.client.is_connected:
            async with asyncio.timeout(10):
                await self.client.disconnect()

    def check(self):
        if not self.active or not self.client.is_connected:
            raise RingError("disconnected")

    def require_mtu(self, minimum: int):
        # Unsupported MTU queries (including BlueZ's default value) do not establish the MTU.
        if sys.platform in ("win32", "darwin") and self.client.mtu_size < minimum:
            raise RingError("mtu_too_small", f"Requires ATT MTU ≥ {minimum}")

    async def encrypted_ccc(self, timeout: float = 15) -> bool:
        characteristic = self.client.services.get_characteristic(NUS_NOTIFY)
        descriptor = characteristic.get_descriptor(CCC)
        if descriptor is None:
            raise RingError("unsupported_device", "R1 notification descriptor unavailable")
        try:
            async with asyncio.timeout(timeout):
                await self.client.read_gatt_descriptor(descriptor.handle, use_cached=False)
            return True
        except (BleakError, TimeoutError):
            self.check()
            return False

    async def pair(self):
        try:
            async with asyncio.timeout(45):
                if sys.platform != "darwin":
                    await self.client.pair()
                if await self.encrypted_ccc(timeout=40):
                    return
        except (BleakError, TimeoutError) as error:
            raise RingError("pairing_required", "System pairing could not complete") from error
        raise RingError("pairing_required", "The protected R1 descriptor could not be read")

    def _receive(self, _, value: bytearray):
        if not self.active:
            return
        data = bytes(value)
        if self._reply:
            accept, reply = self._reply
            if not reply.done() and accept(data):
                reply.set_result(data)
                return
        self.notify(self, data)

    async def _write(self, command: bytes):
        async with asyncio.timeout(5):
            await self.client.write_gatt_char(
                NUS_REQUEST, command, response=self._write_with_response
            )

    async def send(self, command: bytes):
        async with self.att:
            self.check()
            await self._write(command)
            self.check()

    async def request(
        self,
        command: bytes,
        prefix: bytes,
        *,
        timeout: float = 3,
        retry: float | None = None,
        accept: Callable[[bytes], bool] | None = None,
        final: bool = False,
    ) -> bytes:
        async with self.att:
            self.check()
            loop = asyncio.get_running_loop()
            reply = loop.create_future()
            self._reply = (lambda p: p.startswith(prefix) and (accept is None or accept(p)), reply)
            deadline = loop.time() + timeout
            try:
                while True:
                    try:
                        await self._write(command)
                    except (BleakError, TimeoutError, RingError):
                        if not final or not reply.done() or reply.exception() is not None:
                            raise
                    if retry is None:
                        async with asyncio.timeout(timeout):
                            result = await reply
                        break
                    completed, _ = await asyncio.wait(
                        (reply,), timeout=min(retry, deadline - loop.time())
                    )
                    if completed:
                        result = reply.result()
                        break
                    if loop.time() >= deadline:
                        raise TimeoutError
                if not final:
                    self.check()
                return result
            except TimeoutError as error:
                raise RingError("timeout", f"No response for {command[:2].hex(' ')}") from error
            finally:
                self._reply = None
                if reply.done() and not reply.cancelled():
                    reply.exception()
                else:
                    reply.cancel()
