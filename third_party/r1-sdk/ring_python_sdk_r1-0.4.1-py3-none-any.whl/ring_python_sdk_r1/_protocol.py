import math
import re
import struct
from dataclasses import dataclass
from enum import IntEnum, StrEnum

NUS_REQUEST = "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
NUS_NOTIFY = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"
BIND_REQUEST = "763f0002-7a81-4f13-9f72-6d52494e4700"
BIND_RESPONSE = "763f0003-7a81-4f13-9f72-6d52494e4700"
DIS_SERVICE = "0000180a-0000-1000-8000-00805f9b34fb"
CCC = "00002902-0000-1000-8000-00805f9b34fb"
R1_PNP_ID = bytes.fromhex("02 39 3a 31 52")
INFO = b"\x2a\x01"
BATTERY = b"\x29\x01"
SERIAL = b"\x34\x01"
GESTURE_STATE = b"\x26\x0a"
GESTURE_TWO_FINGER_TAP = 0x0E


class RingError(Exception):
    def __init__(self, reason: str, message: str = "", *, device_code: int | None = None):
        self.reason = reason
        self.device_code = device_code
        detail = f" (device code {device_code})" if device_code is not None else ""
        super().__init__(f"{reason}{detail}" + (f": {message}" if message else ""))


class ConnectionState(StrEnum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    AUTHENTICATING = "authenticating"
    PAIRING = "pairing"
    INITIALIZING = "initializing"
    READY = "ready"
    RECONNECTING = "reconnecting"


class GestureMode(IntEnum):
    NORMAL = 0
    OFF = 1
    LOW_POWER = 7


class WearingHand(IntEnum):
    RIGHT = 0
    LEFT = 1


class SwipeDirection(IntEnum):
    FORWARD = 0
    REVERSED = 1


@dataclass(frozen=True)
class DeviceInfo:
    firmware_version: str
    gesture_available: bool
    serial_number: str | None = None
    hardware_revision: int = 2


@dataclass(frozen=True)
class BatteryStatus:
    percent: int
    charging_state: int | None


@dataclass(frozen=True)
class GestureStatus:
    mode: GestureMode
    running: bool


@dataclass(frozen=True)
class GestureEvent:
    sequence: int
    class_id: int
    center_uptime_ms: int
    confidence: float


@dataclass(frozen=True)
class CircleMotion:
    sequence: int
    class_id: int
    active: bool
    speed_rad_per_second: float
    sample_uptime_ms: int


def matches_advertisement(name: str, pnp_id: bytes | None) -> bool:
    if pnp_id is not None:
        return pnp_id == R1_PNP_ID
    return bool(re.fullmatch(r"(?:RR_|R1)[A-Z0-9-]{4}", name, re.I | re.ASCII)) or (
        6 < len(name) and name.endswith("的Ringo") and len(name.encode("utf-8")) <= 29
    )


def normalize_firmware_version(version: str) -> str:
    match = re.fullmatch(r"RG\d+_(\d+\.\d+\.\d+-\d{8}-\d{6})(?:_ota)?\.zip", version)
    return match[1] if match else version


def parse_info(data: bytes) -> DeviceInfo:
    if len(data) < 9 or data[:4] != b"\x2a\x02\x01\x02":
        raise RingError("unsupported_device", "Expected a complete R1 INFO reply")
    end = 9 + 5 * data[8]
    if len(data) < end or len(set(data[9:end:5])) != data[8]:
        raise RingError("invalid_response", "Invalid INFO component table")
    version = ".".join(str(v) for v in data[4:8])
    if len(data) > end:
        label = data[end + 1 :]
        if (
            len(label) != data[end]
            or not 1 <= len(label) <= 64
            or not all(1 <= v <= 127 for v in label)
        ):
            raise RingError("invalid_response", "Invalid INFO version")
        version = normalize_firmware_version(label.decode("ascii"))
    return DeviceInfo(version, any(data[i] == 8 and data[i + 1] for i in range(9, end, 5)))


def parse_serial(data: bytes) -> str:
    if (
        len(data) != 126
        or data[:3] != b"\x34\x02\x01"
        or data[4] != 2
        or data[9] > 31
        or data[42] > 16
        or data[59] not in (0, 65)
        or (data[59] == 65 and data[60] != 4)
    ):
        raise RingError("invalid_response", "Invalid serial number reply")
    if not data[3] & 1 and data[9] == 0:
        return ""
    serial = data[10 : 10 + data[9]]
    if not data[3] & 1 or not re.fullmatch(rb"[A-Z0-9-]{4,31}", serial):
        raise RingError("invalid_response", "Invalid serial number")
    return serial.decode("ascii")


def parse_battery(data: bytes) -> BatteryStatus | None:
    if len(data) < 5 or data[4] > 100:
        return None
    charging = (data[5] & 0x7F) if len(data) > 5 else None
    return BatteryStatus(data[4], charging if charging in (0, 1, 2) else None)


def parse_gesture_status(data: bytes) -> GestureStatus | None:
    if len(data) != 4 or data[2] > 2 or data[3] > 1:
        return None
    return GestureStatus(
        (GestureMode.OFF, GestureMode.NORMAL, GestureMode.LOW_POWER)[data[2]], bool(data[3])
    )


FINAL_IDS = frozenset((1, 2, 3, 4, 6, 7, 8, 9, 12, 13, GESTURE_TWO_FINGER_TAP, 0x88, 0x89))
LEGACY_IDS = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 12, 13)


def parse_gesture(data: bytes) -> GestureEvent | None:
    if len(data) != 65:
        return None
    sequence, class_id, *fields = struct.unpack_from("<HB12f4xIf", data, 2)
    probabilities, uptime, mass = fields[:12], fields[12], fields[13]
    if not all(0 <= value <= 1 for value in probabilities) or not math.isfinite(mass) or mass < 0:
        return None
    if not any(probabilities):
        if class_id not in FINAL_IDS or mass:
            return None
        confidence = 0.0
    else:
        if class_id not in LEGACY_IDS[1:] or abs(sum(probabilities) - 1) > 0.0001:
            return None
        confidence = probabilities[LEGACY_IDS.index(class_id)]
    return GestureEvent(sequence, class_id, uptime, confidence)


def parse_circle(data: bytes) -> CircleMotion | None:
    if len(data) != 14:
        return None
    sequence, class_id, active, speed, uptime = struct.unpack_from("<HBBfI", data, 2)
    if class_id not in (12, 13) or active > 1 or not math.isfinite(speed):
        return None
    if (
        (not active and data[6:10] != bytes(4))
        or (class_id == 12 and speed < 0)
        or (class_id == 13 and speed > 0)
    ):
        return None
    return CircleMotion(sequence, class_id, bool(active), speed, uptime)
