import hashlib
import json
import os
import tempfile
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from ring_python_sdk_r1._protocol import RingError


class Storage:
    def __init__(self, directory: Path | None):
        base = os.environ.get("LOCALAPPDATA") if os.name == "nt" else None
        self.directory = directory or (
            Path(base) / "MythLink" / "R1" if base else Path.home() / ".ring-r1"
        )

    def _load(self, name: str) -> dict:
        try:
            contents = json.loads((self.directory / name).read_text(encoding="utf-8"))
            if not isinstance(contents, dict):
                raise ValueError("expected an object")
            return contents
        except FileNotFoundError:
            return {}
        except (OSError, ValueError) as error:
            raise RingError("storage_error", f"Unable to read {name}") from error

    def _save(self, name: str, contents: dict):
        temporary = None
        try:
            self.directory.mkdir(mode=0o700, exist_ok=True, parents=True)
            with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8", dir=self.directory, delete=False
            ) as stream:
                temporary = Path(stream.name)
                json.dump(contents, stream)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.directory / name)
        except OSError as error:
            raise RingError("storage_error", f"Unable to save {name}") from error
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)

    def _remove(self, name: str):
        try:
            (self.directory / name).unlink(missing_ok=True)
        except OSError as error:
            raise RingError("storage_error", f"Unable to remove {name}") from error

    @staticmethod
    def _record_name(address: str) -> str:
        return hashlib.sha256(address.casefold().encode()).hexdigest() + ".json"

    def target(self) -> tuple[str, bool] | None:
        contents = self._load("target.json")
        if not contents:
            return None
        address = contents.get("address")
        recover = contents.get("recover")
        if not isinstance(address, str) or not address or type(recover) is not bool:
            raise RingError("storage_error", "Invalid saved R1 target")
        return address, recover

    def remember(self, address: str, recover: bool):
        self._save("target.json", {"address": address, "recover": recover})

    def key(self, address: str, identity: bytes | None = None, *, create=False):
        name = self._record_name(address)
        record = self._load(name)
        if identity is not None and record.get("identity") not in (None, identity.hex()):
            raise RingError(
                "authentication_failed", "The saved key belongs to another ring identity"
            )
        created = "key" not in record
        if not created:
            try:
                key = serialization.load_pem_private_key(
                    record["key"].encode("ascii"), password=None
                )
                if not isinstance(key, ec.EllipticCurvePrivateKey) or not isinstance(
                    key.curve, ec.SECP256R1
                ):
                    raise ValueError("Invalid private key curve")
            except (AttributeError, ValueError, TypeError) as error:
                raise RingError("storage_error", "Invalid R1 private key") from error
        elif create:
            key = ec.generate_private_key(ec.SECP256R1())
            record["key"] = key.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8,
                serialization.NoEncryption(),
            ).decode("ascii")
        else:
            return None
        if identity is not None and record.get("identity") is None:
            record["identity"] = identity.hex()
            self._save(name, record)
        elif created:
            self._save(name, record)
        return key

    def unbind_pending(self, address: str) -> bool:
        return self._load(self._record_name(address)).get("unbind_pending") is True

    def begin_unbind(self, address: str):
        name = self._record_name(address)
        self._save(name, {**self._load(name), "unbind_pending": True})

    def cancel_unbind(self, address: str):
        name = self._record_name(address)
        record = self._load(name)
        record.pop("unbind_pending", None)
        self._save(name, record)

    def forget(self, address: str):
        target = self.target()
        if target and target[0].casefold() == address.casefold():
            self._remove("target.json")
        self._remove(self._record_name(address))
