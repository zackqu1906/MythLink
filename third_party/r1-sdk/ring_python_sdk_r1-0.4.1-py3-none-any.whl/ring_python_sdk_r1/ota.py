import asyncio
from collections.abc import Callable
from contextlib import asynccontextmanager, suppress
from dataclasses import dataclass
from enum import StrEnum

from bleak.exc import BleakError
from ring_python_sdk_r1._firmware import (
    FirmwareImage,
    image_version,
    load_bundled_firmware,
    load_firmware,
)
from ring_python_sdk_r1._gatt import Gatt
from ring_python_sdk_r1._protocol import INFO, DeviceInfo, RingError, parse_info
from ring_python_sdk_r1.ring import RETRYABLE, Ring, RingDevice
from smp.header import Header
from smpclient import SMPClient, success
from smpclient.requests.image_management import ImageStatesRead, ImageStatesWrite
from smpclient.requests.os_management import MCUMgrParametersRead, ResetWrite
from smpclient.transport import SMP_CHARACTERISTIC_UUID, SMPTransport

__all__ = [
    "FirmwareImage",
    "Phase",
    "Progress",
    "flash_firmware",
    "load_bundled_firmware",
    "load_firmware",
    "verify_installed",
]

SMP_UUID = str(SMP_CHARACTERISTIC_UUID)
HW_ADDRESS_READ = b"\x2d\x01"


class Phase(StrEnum):
    CHECKING = "checking"
    UPLOADING = "uploading"
    TESTING = "testing"
    RESETTING = "resetting"
    VERIFYING = "verifying"


@dataclass(frozen=True)
class Progress:
    phase: Phase
    sent: int = 0
    total: int = 0


class _SmpOverRing(SMPTransport):
    """SMP requests on the authenticated business GATT, one request at a time."""

    def __init__(self, gatt: Gatt):
        self.gatt = gatt
        self.characteristic = None
        self._pending = None
        self._buffer = bytearray()

    async def connect(self, address: str, timeout_s: float):
        async with self.gatt.att, asyncio.timeout(timeout_s):
            self.gatt.check()
            characteristic = self.gatt.client.services.get_characteristic(SMP_UUID)
            if characteristic is None:
                raise RingError("ota_unavailable", "R1 SMP characteristic unavailable")
            if not {"notify", "write-without-response"}.issubset(characteristic.properties):
                raise RingError("ota_unavailable", "Unexpected SMP characteristic properties")
            await self.gatt.client.start_notify(characteristic, self._notified)
            self.characteristic = characteristic

    async def disconnect(self):
        if self.characteristic is not None and self.gatt.active:
            async with self.gatt.att, asyncio.timeout(5):
                await self.gatt.client.stop_notify(self.characteristic)
        self.characteristic = None

    @property
    def mtu(self):
        return self.characteristic.max_write_without_response_size

    def initialize(self, smp_server_transport_buffer_size: int):
        if smp_server_transport_buffer_size >= 20:
            super().initialize(min(2048, smp_server_transport_buffer_size))

    def _notified(self, _, data: bytearray):
        if self._pending is None:
            return
        request, reply = self._pending
        if reply.done():
            return
        self._buffer.extend(data)
        if len(self._buffer) < Header.SIZE:
            return
        try:
            response = Header.loads(self._buffer[: Header.SIZE])
            if (response.sequence, response.group_id, response.command_id, response.op) != (
                request.sequence,
                request.group_id,
                request.command_id,
                request.op + 1,
            ):
                raise RingError("invalid_smp_reply", "SMP response does not match the request")
            expected = Header.SIZE + response.length
            if expected > 4096 or len(self._buffer) > expected:
                raise RingError("invalid_smp_reply", "Invalid SMP notification length")
            if len(self._buffer) == expected:
                reply.set_result(bytes(self._buffer))
        except Exception as error:
            reply.set_exception(error)

    async def send(self, data: bytes):
        mtu = min(120, self.mtu)
        if mtu < 20 or len(data) > self.max_unencoded_size:
            raise RingError("ota_mtu", "SMP request exceeds the ring or BLE buffer")
        for offset in range(0, len(data), mtu):
            self.gatt.check()
            await self.gatt.client.write_gatt_char(
                self.characteristic, data[offset : offset + mtu], response=False
            )

    async def receive(self) -> bytes:
        _, reply = self._pending
        lost = asyncio.create_task(self.gatt.disconnected.wait())
        try:
            await asyncio.wait((reply, lost), return_when=asyncio.FIRST_COMPLETED)
            if reply.done():
                return reply.result()
            raise RingError("disconnected", "Ring disconnected during SMP request")
        finally:
            lost.cancel()

    async def send_and_receive(self, data: bytes) -> bytes:
        async with self.gatt.att:
            self.gatt.check()
            request = Header.loads(data[: Header.SIZE])
            reply = asyncio.get_running_loop().create_future()
            self._pending = (request, reply)
            self._buffer.clear()
            try:
                await self.send(data)
                return await self.receive()
            finally:
                self._pending = None
                if reply.done() and not reply.cancelled():
                    reply.exception()
                else:
                    reply.cancel()


def _target_gatt(ring: Ring, target: RingDevice) -> Gatt:
    gatt = ring._ready_gatt()
    if (
        ring.address is None
        or ring.address.casefold() != target.address.casefold()
        or ring.info is None
        or ring.info.hardware_revision != 2
    ):
        raise RingError("ota_target", "Connect the selected R1 before using firmware actions")
    return gatt


@asynccontextmanager
async def _smp(gatt: Gatt, target: RingDevice):
    transport = _SmpOverRing(gatt)
    client = SMPClient(transport, target.address, timeout_s=10)
    try:
        await transport.connect(target.address, 5)
        parameters = await client.request(MCUMgrParametersRead(), timeout_s=5)
        if success(parameters):
            transport.initialize(parameters.buf_size)
        yield client
    finally:
        with suppress(BleakError, OSError, TimeoutError):
            await transport.disconnect()


async def _ok(client, command, description: str):
    response = await client.request(command)
    if not success(response):
        raise RingError("smp_rejected", f"{description}: {response}")
    return response


def _primary(images):
    active = [item for item in images if item.active]
    if (
        len(active) != 1
        or active[0].slot != 0
        or active[0].image not in (None, 0)
        or not active[0].bootable
    ):
        raise RingError(
            "invalid_image_state", "Expected one bootable active image in primary slot 0"
        )
    return active[0]


def _candidate(images, firmware):
    return next(
        (
            image
            for image in images
            if image.slot == 1
            and image.image in (None, 0)
            and image.bootable
            and image.hash == firmware.digest
            and image_version(image.version) == image_version(firmware.image_version)
        ),
        None,
    )


def _verify(info: DeviceInfo, images, firmware: FirmwareImage) -> DeviceInfo:
    active = _primary(images)
    if active.hash != firmware.digest or image_version(active.version) != image_version(
        firmware.image_version
    ):
        raise RingError("firmware_not_active", f"Current firmware: {info.firmware_version}")
    if firmware.runtime_version is not None and info.firmware_version != firmware.runtime_version:
        raise RingError(
            "firmware_version_mismatch",
            f"INFO reports {info.firmware_version}; expected {firmware.runtime_version}",
        )
    if not active.confirmed or any(item.pending for item in images):
        raise RingError("firmware_confirmation_pending", "Waiting for the ring to confirm its boot")
    return info


async def _read_info(gatt: Gatt) -> DeviceInfo:
    return parse_info(await gatt.request(INFO, b"\x2a\x02", timeout=5))


async def _hardware_address(gatt: Gatt, *, required: bool) -> bytes | None:
    try:
        packet = await gatt.request(HW_ADDRESS_READ, b"\x2d\x02", timeout=3)
        if len(packet) >= 9 and packet[2] == 1 and any(packet[3:9]):
            return packet[3:9]
    except RingError as error:
        if error.reason != "timeout":
            raise
    if required:
        raise RingError("ota_target", "Could not read the hardware address for verification")
    return None


async def verify_installed(
    ring: Ring, target: RingDevice, firmware: FirmwareImage, *, hardware=None
) -> DeviceInfo:
    gatt = _target_gatt(ring, target)
    async with _smp(gatt, target) as client:
        images = (await _ok(client, ImageStatesRead(), "Read image state")).images
    info = await _read_info(gatt)
    if hardware is not None and await _hardware_address(gatt, required=True) != hardware:
        raise RingError("ota_target", "The ring hardware address changed after reboot")
    return _verify(info, images, firmware)


async def flash_firmware(
    ring: Ring,
    target: RingDevice,
    firmware: FirmwareImage,
    progress: Callable[[Progress], None],
    *,
    verify_timeout=120,
) -> DeviceInfo:
    gatt = _target_gatt(ring, target)
    await ring._stop_attempts()
    progress(Progress(Phase.CHECKING))
    await ring.touchpad.stop()
    if ring.info.gesture_available:
        await gatt.send(b"\x26\x01")
    info = await _read_info(gatt)
    hardware = await _hardware_address(gatt, required=False)
    mutating = False
    try:
        async with _smp(gatt, target) as client:
            images = (await _ok(client, ImageStatesRead(), "Read image state")).images
            active = _primary(images)
            if active.hash == firmware.digest:
                return _verify(info, images, firmware)
            candidate = _candidate(images, firmware)
            if not active.confirmed or any(
                item.pending and item is not candidate for item in images
            ):
                raise RingError(
                    "ota_pending", "Verify the existing image state before starting another upgrade"
                )

            mutating = True
            if candidate is None:
                total = len(firmware.data)
                progress(Progress(Phase.UPLOADING, 0, total))
                sent = -1
                # MCUboot image number 0, with Zephyr selecting the inactive slot.
                async for offset in client.upload(firmware.data, slot=0, upgrade=False):
                    if not sent < offset <= total:
                        raise RingError("ota_upload", "Invalid or stalled upload offset")
                    sent = offset
                    progress(Progress(Phase.UPLOADING, sent, total))
                images = (await _ok(client, ImageStatesRead(), "Read candidate image")).images
                candidate = _candidate(images, firmware)
                if candidate is None:
                    raise RingError(
                        "ota_upload", "Slot 1 did not report the selected image hash and version"
                    )

            if not candidate.pending:
                progress(Progress(Phase.TESTING))
                await _ok(
                    client, ImageStatesWrite(hash=firmware.digest, confirm=False), "Mark test boot"
                )
            progress(Progress(Phase.RESETTING))
            try:
                await _ok(client, ResetWrite(), "Reset ring")
            except (BleakError, TimeoutError, RingError) as error:
                # A reset can terminate the link before its acknowledgement arrives.
                if isinstance(error, RingError) and error.reason != "disconnected":
                    raise
    finally:
        if mutating:
            await ring.close()

    progress(Progress(Phase.VERIFYING))
    return await _wait_for_boot(ring, target, firmware, hardware, verify_timeout)


async def _wait_for_boot(ring, target, firmware, hardware, timeout):
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout
    last = None
    await asyncio.sleep(min(2, timeout / 3))
    transient = RETRYABLE | {"firmware_not_active", "firmware_confirmation_pending"}
    while loop.time() < deadline:
        try:
            async with asyncio.timeout(min(deadline - loop.time(), 35)):
                if not ring.connected:
                    await ring._connect(target.address, explicit=False, recover=False)
                return await verify_installed(ring, target, firmware, hardware=hardware)
        except RingError as error:
            last = error
            if error.reason not in transient:
                break
        except (BleakError, OSError, TimeoutError) as error:
            last = error
            await ring.close()
        await asyncio.sleep(max(0, min(3, deadline - loop.time())))
    raise RingError(
        "ota_unconfirmed",
        f"Run read-only verification before retrying; {last or 'ring unavailable'}",
    ) from last
