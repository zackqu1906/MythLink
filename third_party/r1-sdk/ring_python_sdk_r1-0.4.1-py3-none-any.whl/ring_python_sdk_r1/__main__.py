import argparse
import asyncio
from pathlib import Path

from ring_python_sdk_r1 import GestureMode, Ring, RingError, scan


async def run(args):
    if args.command == "scan":
        for device in await scan(args.timeout):
            signal = f"{device.rssi:4d} dBm" if device.rssi is not None else "       —"
            print(f"{device.address}\t{signal}\t{device.name}")
        return
    ring = Ring(
        storage_dir=args.storage_dir,
        on_state=lambda state: print(state),
        on_gesture=print,
        on_circle=print,
        on_touchpad=print,
        on_touchpad_status=print,
    )
    try:
        if args.address:
            info = await ring.connect(args.address)
        else:
            info = await ring.resume()
            if info is None:
                raise RingError(
                    "device_required", "Run ring-r1 scan and supply the selected address"
                )
        print(info)
        print(await ring.read_battery())
        if not args.listen:
            return
        await ring.set_gesture_mode(GestureMode.NORMAL)
        if args.touchpad or args.model is not None:
            await ring.touchpad.start(args.model)
        await asyncio.Event().wait()
    finally:
        await ring.close()


def main():
    parser = argparse.ArgumentParser(description="MythLink R1 SDK")
    parser.add_argument("--storage-dir", type=Path)
    commands = parser.add_subparsers(dest="command", required=True)
    scanner = commands.add_parser("scan")
    scanner.add_argument("--timeout", type=float, default=6)
    connection = commands.add_parser("connect")
    connection.add_argument("address", nargs="?")
    connection.add_argument("--listen", action="store_true")
    connection.add_argument("--touchpad", action="store_true", help="Start the bundled touchpad")
    connection.add_argument("--model", type=Path, help="Override the bundled touchpad ONNX")
    args = parser.parse_args()
    if args.command == "connect" and (args.touchpad or args.model is not None):
        args.listen = True
    try:
        asyncio.run(run(args))
    except KeyboardInterrupt:
        pass
    except (RingError, ValueError) as error:
        parser.exit(1, f"{error}\n")


if __name__ == "__main__":
    main()
