import hashlib
from pathlib import Path

from ring_python_sdk_r1._protected_model import ProtectedModelError, load_protected_model
from ring_python_sdk_r1._protocol import RingError
from ring_python_sdk_r1._raw2 import MODEL_SHA256

WIDTHS = (256, 256, 256, 256, 64, 64, 64)


class TouchpadModel:
    def __init__(self, path: Path | None = None):
        try:
            source = load_protected_model() if path is None else path.read_bytes()
            if hashlib.sha256(source).hexdigest() != MODEL_SHA256:
                raise RingError(
                    "touchpad_model_mismatch",
                    "Expected the R1 Linear8 CPU ONNX paired with frontend 0x2d810699",
                )
            import numpy as np
            import onnxruntime as ort
        except ImportError as error:
            raise RingError(
                "touchpad_runtime_unavailable", "Install ring-python-sdk-r1[touchpad]"
            ) from error
        except OSError as error:
            location = "the bundled R1 touchpad model" if path is None else str(path)
            raise RingError("touchpad_model_unavailable", f"Cannot read {location}") from error
        except ProtectedModelError as error:
            raise RingError("touchpad_model_mismatch", str(error)) from error
        self.np = np
        options = ort.SessionOptions()
        options.intra_op_num_threads = options.inter_op_num_threads = 1
        # Preserve the Linear8 QAT graph's quantization on desktop CPU runtimes.
        options.add_session_config_entry("session.disable_quant_qdq", "1")
        self.session = ort.InferenceSession(
            source, sess_options=options, providers=["CPUExecutionProvider"]
        )
        inputs = {"features": 8, **{f"h{i}": width for i, width in enumerate(WIDTHS)}}
        outputs = {
            "xy": 4,
            "touch": 2,
            "finger": 2,
            **{f"next_h{i}": width for i, width in enumerate(WIDTHS)},
        }
        self.names = list(outputs)
        for nodes, expected in (
            (self.session.get_inputs(), inputs),
            (self.session.get_outputs(), outputs),
        ):
            actual = {node.name: (node.type, node.shape) for node in nodes}
            if actual != {name: ("tensor(float)", [1, width]) for name, width in expected.items()}:
                raise RingError("touchpad_model_mismatch", "Invalid recurrent ONNX tensor contract")
        self.reset()
        self.step((0.0,) * 8)
        self.reset()

    def reset(self):
        self.states = {
            f"h{i}": self.np.zeros((1, width), dtype=self.np.float32)
            for i, width in enumerate(WIDTHS)
        }

    def step(self, features: tuple[float, ...]) -> tuple[float, ...]:
        features = self.np.asarray(features, dtype=self.np.float32).reshape(1, 8)
        outputs = self.session.run(self.names, {"features": features, **self.states})
        if not all(self.np.isfinite(output).all() for output in outputs):
            raise RingError(
                "touchpad_inference_failed", "The model returned non-finite output or state"
            )
        xy, touch, finger = (output[0] for output in outputs[:3])
        self.states = {f"h{i}": output for i, output in enumerate(outputs[3:])}
        return tuple(
            float(value)
            for value in (xy[0], xy[1], touch[0], finger[0], xy[2], xy[3], touch[1], finger[1])
        )
