import asyncio
import hashlib
import struct
from contextlib import suppress
from dataclasses import dataclass

from bleak.exc import BleakError
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, utils
from ring_python_sdk_r1._gatt import Gatt
from ring_python_sdk_r1._protocol import BIND_REQUEST, BIND_RESPONSE, RingError
from ring_python_sdk_r1._storage import Storage

CAPS, CHALLENGE, PROVE, STATUS, SELF = 0, 1, 2, 3, 12
V3_ERRORS = {
    1: "invalid_response",
    2: "unsupported_firmware",
    3: "migration_required",
    4: "storage_error",
    5: "manager_exists",
    6: "manager_absent",
    7: "authentication_failed",
    8: "busy",
    9: "stale_operation",
    10: "stale_operation",
    12: "operation_timeout",
    13: "slot_not_empty",
    14: "pairing_required",
    15: "storage_error",
    16: "pairing_required",
}
V1_ERRORS = {
    -2: "need_rebind",
    -1: "pairing_not_allowed",
    -28: "binding_full",
    -16: "busy",
    -13: "authentication_failed",
    -112: "identity_in_use",
    -133: "migration_required",
    -22: "invalid_response",
    -128: "device_unavailable",
    -95: "unsupported_firmware",
    -134: "unsupported_firmware",
}


def failure(code: int, version: int) -> RingError:
    errors = V3_ERRORS if version == 3 else V1_ERRORS
    return RingError(errors.get(code, "invalid_response"), device_code=code)


def public_key(key):
    return key.public_key().public_bytes(
        serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint
    )


def sign(key, message: bytes) -> bytes:
    r, s = utils.decode_dss_signature(key.sign(message, ec.ECDSA(hashes.SHA256())))
    return r.to_bytes(32, "big") + s.to_bytes(32, "big")


def check_flags(value: bytes, size: int) -> bytes:
    if len(value) != size or any(flag > 1 for flag in value):
        raise RingError("invalid_response", "Invalid binding flags")
    return value


@dataclass(frozen=True)
class ManagedStatus:
    ready: bool
    manager: bool
    manager_exists: bool
    cleanup_code: int
    result: int


class Binding:
    def __init__(self, gatt: Gatt, storage: Storage, address: str):
        self.gatt = gatt
        self.storage = storage
        self.address = address
        self.version = 0
        self.identity = b""
        self.session = bytes(8)
        self.sequence = 0
        self.request_id = 0
        self.warning = None
        self._self_ack = None

    async def discover(self, *, indicate=True):
        client = self.gatt.client
        present = tuple(
            client.services.get_characteristic(uuid) is not None
            for uuid in (BIND_REQUEST, BIND_RESPONSE)
        )
        if not any(present):
            return
        if not all(present):
            raise RingError("unsupported_firmware", "Incomplete binding service")
        self.version = 3
        try:
            caps = await self.request(CAPS)
        except RingError as error:
            if error.reason != "unsupported_firmware":
                raise
            self.version = 1
            return
        if len(caps) != 11 or caps[0] > 2 or caps[1] > 1 or caps[2:4] != b"\x01\x03":
            raise RingError("invalid_response", "Invalid managed binding capabilities")
        if caps[0] == 0:
            self.version = 1
        else:
            self.identity = caps[4:]
            if indicate:
                async with asyncio.timeout(5):
                    await client.start_notify(BIND_RESPONSE, self._indicated, force_indicate=True)

    def _indicated(self, _, payload: bytearray):
        data = bytes(payload)
        if self._self_ack is not None:
            prefix, reply = self._self_ack
            if not reply.done() and data == prefix + b"\0\0":
                reply.set_result(data)

    async def request(self, operation: int, payload: bytes = b"") -> bytes:
        gatt = self.gatt
        async with gatt.att:
            gatt.check()
            if self.version == 3:
                self.sequence += 1
                request = bytes((3, operation)) + self.session + struct.pack("<I", self.sequence)
            else:
                self.request_id = self.request_id % 65535 + 1
                request = struct.pack("<BBH", 1, operation, self.request_id)
            prefix = bytes((self.version, operation | 128)) + request[2:]
            final_reply = None
            if self.version == 3 and operation == SELF:
                final_reply = asyncio.get_running_loop().create_future()
                self._self_ack = (prefix, final_reply)

            async def exchange():
                frame = request + payload
                # 18 bytes fits the minimum ATT MTU after the two-byte fragment header.
                for offset in range(0, len(frame), 18):
                    async with asyncio.timeout(5):
                        await gatt.client.write_gatt_char(
                            BIND_REQUEST,
                            bytes((offset, len(frame))) + frame[offset : offset + 18],
                            response=True,
                        )
                while True:
                    gatt.check()
                    async with asyncio.timeout(5):
                        data = bytes(
                            await gatt.client.read_gatt_char(BIND_RESPONSE, use_cached=False)
                        )
                    parsed = self._parse_reply(data, prefix, operation)
                    if parsed is not None:
                        return parsed
                    await asyncio.sleep(0.1)

            try:
                async with asyncio.timeout(15 if self.version == 3 else 5):
                    if final_reply is None:
                        return await exchange()
                    task = asyncio.create_task(exchange())
                    try:
                        await asyncio.wait((task, final_reply), return_when=asyncio.FIRST_COMPLETED)
                        return b"" if final_reply.done() else task.result()
                    finally:
                        task.cancel()
                        with suppress(asyncio.CancelledError, TimeoutError, BleakError, RingError):
                            await task
            except TimeoutError as error:
                raise RingError("timeout", f"No reply to binding operation {operation}") from error
            finally:
                self._self_ack = None
                if final_reply is not None:
                    final_reply.cancel()

    def _parse_reply(self, data: bytes, prefix: bytes, operation: int) -> bytes | None:
        if not data:
            return None
        if self.version == 3:
            if (
                self.sequence == 1
                and operation == CAPS
                and len(data) == 6
                and data[:4] == b"\x01\x80\0\0"
            ):
                code = struct.unpack_from("<h", data, 4)[0]
                raise failure(code, 1)
            if not 16 <= len(data) <= 64 or data[0] != 3:
                raise RingError("invalid_response", "Invalid v3 binding reply")
            if data[10:14] != prefix[10:14] or (self.sequence > 1 and data[2:10] != self.session):
                return None
            if data[1] != prefix[1]:
                raise RingError("invalid_response", "Incorrect v3 binding operation")
            code = struct.unpack_from("<H", data, 14)[0]
            if code:
                raise failure(code, 3)
            if self.sequence == 1:
                self.session = data[2:10]
                if not any(self.session):
                    raise RingError("invalid_response", "Empty v3 binding session")
            return data[16:]
        if not 6 <= len(data) <= 48 or data[0] != 1:
            raise RingError("invalid_response", "Invalid legacy binding reply")
        if data[2:4] != prefix[2:4]:
            return None
        if data[1] != prefix[1]:
            raise RingError("invalid_response", "Incorrect legacy binding operation")
        code = struct.unpack_from("<h", data, 4)[0]
        if code:
            raise failure(code, 1)
        return data[6:]

    async def managed_status(self) -> ManagedStatus:
        value = await self.request(STATUS)
        if len(value) != 21:
            raise RingError("invalid_response", "Invalid managed binding status")
        ready, manager, exists = map(bool, check_flags(value[:3], 3))
        return ManagedStatus(ready, manager, exists, value[3], value[4])

    async def admit(self, *, explicit: bool, pairing):
        if self.storage.unbind_pending(self.address):
            raise RingError("unbind_pending", "Confirm the previous unbind before connecting")
        if self.version == 3:
            await self._managed_admit(explicit, pairing)
        elif self.version == 1:
            await self._legacy_admit(explicit, pairing)
        elif explicit:
            await pairing()
        elif not await self.gatt.encrypted_ccc(timeout=5):
            raise RingError("pairing_required")

    async def _managed_admit(self, explicit, pairing):
        state = await self.managed_status()
        if not state.manager_exists and not explicit:
            raise RingError("manager_absent")
        if state.ready and state.manager:
            self.warning = failure(state.cleanup_code, 3) if state.cleanup_code else None
            return

        if state.manager_exists and not state.ready:
            key = self.storage.key(self.address, self.identity)
            # A short protected read can restore the existing system bond. Saved
            # credentials are used only if firmware did not restore the manager.
            if await self.gatt.encrypted_ccc(timeout=5):
                for _ in range(5):
                    state = await self.managed_status()
                    if state.ready and state.manager:
                        self.warning = (
                            failure(state.cleanup_code, 3) if state.cleanup_code else None
                        )
                        return
                    if state.result not in (0, 14, 16):
                        raise failure(state.result, 3)
                    await asyncio.sleep(0.1)
        else:
            key = self.storage.key(self.address, self.identity, create=not state.manager_exists)
        if not explicit:
            if state.ready:
                self.warning = RingError("manager_key_missing")
                return
            raise RingError("pairing_required")
        if key is None:
            if state.ready:
                self.warning = RingError("manager_key_missing")
                return
            raise RingError(
                "manager_key_missing", "The ring is already managed by another credential"
            )

        claim = not state.manager_exists
        purpose = b"\x01" if claim else b"\x02"
        pub = public_key(key)
        try:
            challenge = await self.request(CHALLENGE, purpose + pub)
        except RingError as error:
            if not claim and error.device_code == 7:
                if state.ready:
                    self.warning = RingError("manager_key_missing", device_code=7)
                    return
                raise RingError("manager_key_missing", device_code=7) from error
            raise
        if len(challenge) != 39 or challenge[:7] != self.identity:
            raise RingError("invalid_response", "Invalid ring challenge identity")
        proof = sign(
            key, b"R1-MANAGER-V3" + purpose + self.identity + self.session + pub + challenge[7:]
        )
        if claim:
            await pairing()
        result = await self.request(PROVE, proof)
        if len(result) != 2 or result[0] > 1:
            raise RingError("invalid_response", "Invalid managed proof reply")
        if not claim and not state.ready:
            try:
                await pairing()
            except RingError as error:
                if error.reason != "pairing_required":
                    raise
                state = await self.managed_status()
                if not state.ready:
                    if state.result == 16:
                        raise failure(state.result, 3) from error
                    raise
        try:
            async with asyncio.timeout(30):
                while True:
                    state = await self.managed_status()
                    if state.ready and state.manager:
                        self.warning = (
                            failure(state.cleanup_code, 3) if state.cleanup_code else None
                        )
                        return
                    if state.result not in (0, 14):
                        raise failure(state.result, 3)
                    await asyncio.sleep(0.1)
        except TimeoutError as error:
            raise RingError(
                "pairing_required", "The ring did not confirm encrypted manager access"
            ) from error

    async def _legacy_query(self, key) -> bytes:
        key_id = hashlib.sha256(public_key(key)).digest() if key else bytes(32)
        return check_flags(await self.request(CAPS, key_id), 3)

    async def _legacy_prove(self, purpose: int, key):
        pub = public_key(key)
        tag = bytes((purpose,))
        challenge = await self.request(CHALLENGE, tag + pub)
        if len(challenge) != 39 or challenge[0] > 1:
            raise RingError("invalid_response", "Invalid legacy binding challenge")
        self.storage.key(self.address, challenge[:7])
        proof = sign(key, b"R1-CLIENT-AUTH-V1" + tag + challenge[:7] + pub + challenge[7:])
        check_flags(await self.request(PROVE, proof), 1)

    async def _legacy_admit(self, explicit, pairing):
        state = check_flags(await self.request(STATUS), 3)
        if state[0]:
            return
        if (
            await self.gatt.encrypted_ccc(timeout=5)
            and check_flags(await self.request(STATUS), 3)[0]
        ):
            return
        key = self.storage.key(self.address)
        record = await self._legacy_query(key)
        if not record[1] and (key is None or not record[0]):
            raise RingError("local_binding_missing", "An existing ring binding blocks pairing")
        if not explicit:
            raise RingError("pairing_required")
        if key is not None and record[0]:
            try:
                await self._legacy_prove(2, key)
            except RingError as error:
                if error.device_code != -133:
                    raise
                await self._legacy_prove(3, key)
        await pairing()
        try:
            async with asyncio.timeout(30):
                while not check_flags(await self.request(STATUS), 3)[0]:
                    await asyncio.sleep(0.1)
        except TimeoutError as error:
            raise RingError("pairing_required") from error

    async def register_legacy_recovery(self, explicit: bool):
        if self.version != 1 or not explicit:
            return
        try:
            key = self.storage.key(self.address, create=True)
            if not (await self._legacy_query(key))[0]:
                await self._legacy_prove(1, key)
                async with asyncio.timeout(10):
                    while not check_flags(await self.request(STATUS), 3)[2]:
                        await asyncio.sleep(0.1)
        except (RingError, TimeoutError, BleakError) as error:
            self.gatt.check()
            self.warning = error

    async def self_unbind(self):
        if self.version == 3:
            if not (await self.managed_status()).manager:
                raise RingError("manager_key_missing", "This connection has no manager permission")
            self.storage.begin_unbind(self.address)
            if await self.request(SELF):
                raise RingError("invalid_response", "Unexpected self-unbind payload")
        else:
            self.storage.begin_unbind(self.address)
            packet = await self.gatt.request(b"\x37\x00\xa5", b"\x37\x01", timeout=5, final=True)
            if len(packet) != 5 or packet[2] != 1:
                raise RingError("invalid_response", "Invalid self-unbind acknowledgement")
            code = struct.unpack_from("<h", packet, 3)[0]
            if code:
                raise failure(code, 1)

    async def unbind_absent(self) -> bool | None:
        if self.version == 3:
            expected = self.storage.key(self.address, self.identity)
            # An empty manager slot conclusively confirms self-unbind.
            if expected is not None or self.storage.unbind_pending(self.address):
                return not (await self.managed_status()).manager_exists
        if self.version == 1:
            key = self.storage.key(self.address)
            if key:
                return not (await self._legacy_query(key))[0]
        return None
