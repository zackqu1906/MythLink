"""Desktop single-device SDK for the MythLink R1 ring."""

from ring_python_sdk_r1._protocol import (
    GESTURE_TWO_FINGER_TAP,
    BatteryStatus,
    CircleMotion,
    ConnectionState,
    DeviceInfo,
    GestureEvent,
    GestureMode,
    GestureStatus,
    RingError,
    SwipeDirection,
    WearingHand,
)
from ring_python_sdk_r1._raw2 import (
    Click,
    ContactRange,
    ContactUpdate,
    EventMeta,
    Motion,
    TouchpadEvent,
    TouchpadStage,
    TouchpadStatus,
)
from ring_python_sdk_r1.mouse import SystemMouse
from ring_python_sdk_r1.ring import Ring, RingDevice, scan

__all__ = [
    "GESTURE_TWO_FINGER_TAP",
    "BatteryStatus",
    "CircleMotion",
    "Click",
    "ConnectionState",
    "ContactRange",
    "ContactUpdate",
    "DeviceInfo",
    "EventMeta",
    "GestureEvent",
    "GestureMode",
    "GestureStatus",
    "Motion",
    "Ring",
    "RingDevice",
    "RingError",
    "SwipeDirection",
    "SystemMouse",
    "TouchpadEvent",
    "TouchpadStage",
    "TouchpadStatus",
    "WearingHand",
    "scan",
]
