import struct
from dataclasses import dataclass
from enum import StrEnum

from ring_python_sdk_r1._protocol import RingError

MODEL_ID = 0x2D810699
MODEL_SHA256 = "ce8115e0a4f85f0176464e1f6d4c7a0ca21211c2dcb2f1bbf1faa7e8f41253db"
SCALES = (1 / 32, 1 / 32, 1 / 32, 1 / 32, 1 / 64, 1 / 32, 1 / 32, 1 / 32)
MASK = 0xFFFFFFFF
START = b"\x3c\x00\x02\x01\x00\x00"
STOP = b"\x3c\x01"
STATUS = b"\x3c\x03"
STATUS_REPLY = b"\x3c\x11"


class TouchpadStage(StrEnum):
    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    SUSPENDING = "suspending"
    SLEEPING = "sleeping"
    FAILED = "failed"


@dataclass(frozen=True)
class TouchpadStatus:
    stage: TouchpadStage = TouchpadStage.STOPPED
    session_id: int | None = None
    generation: int = 0
    error: RingError | None = None


@dataclass(frozen=True)
class EventMeta:
    session_id: int
    generation: int
    sequence: int
    source_time_ns: int


@dataclass(frozen=True)
class ContactRange:
    start_frame: int
    start_time_ns: int
    end_frame_exclusive: int | None = None
    end_time_ns: int | None = None


@dataclass(frozen=True)
class Motion:
    meta: EventMeta
    frame_id: int
    dx: float
    dy: float
    mode: str
    episode_id: int | None


@dataclass(frozen=True)
class ContactUpdate:
    meta: EventMeta
    episode_id: int
    phase: str
    mode: str
    range: ContactRange


@dataclass(frozen=True)
class Click:
    meta: EventMeta
    click_id: int
    button: str
    count: int
    is_preview: bool


TouchpadEvent = Motion | ContactUpdate | Click


@dataclass(frozen=True)
class StreamStatus:
    state: int
    result: int
    session: int
    epoch: int
    deadline: int

    @property
    def stopped(self) -> bool:
        return self.result == 0 and self.state in (0, 2)

    @property
    def running(self) -> bool:
        return self.result == 0 and self.state == 1 and self.deadline == 0


def parse_status(data: bytes) -> StreamStatus:
    if len(data) != 64 or data[:3] != b"\x3c\x11\x02" or data[3] > 2:
        raise RingError("invalid_response", "Invalid Raw2 status")
    frontend_id = struct.unpack_from("<I", data, 44)[0]
    if frontend_id != MODEL_ID:
        raise RingError(
            "touchpad_model_mismatch",
            f"Expected frontend 0x{MODEL_ID:08x}, received 0x{frontend_id:08x}",
        )
    if struct.unpack_from("<HH4B", data, 48) != (200, 100, 8, 255, 1, 1):
        raise RingError(
            "touchpad_model_mismatch", "Incompatible Raw2 rates, quantization or coordinates"
        )
    return StreamStatus(
        data[3], *struct.unpack_from("<iII", data, 4), struct.unpack_from("<I", data, 60)[0]
    )


@dataclass(frozen=True)
class Token:
    session: int
    epoch: int
    sequence: int
    uptime: int
    reset: bool
    features: tuple[float, ...]


def _token(data: bytes) -> Token:
    if len(data) != 28 or data[:3] != b"\x3c\x02\x02" or data[3] & ~1:
        raise RingError("invalid_response", "Invalid Raw2 feature token")
    values = struct.unpack_from("8b", data, 20)
    if -128 in values:
        raise RingError("invalid_response", "Reserved Raw2 feature value -128")
    return Token(
        *struct.unpack_from("<4I", data, 4),
        bool(data[3]),
        tuple(v * s for v, s in zip(values, SCALES)),
    )


def parse_tokens(data: bytes) -> tuple[Token, ...]:
    if data[:2] == b"\x3c\x02":
        return (_token(data),)
    if (
        len(data) < 4
        or data[:3] != b"\x3c\x13\x02"
        or not 2 <= data[3] <= 15
        or len(data) != 4 + 28 * data[3]
    ):
        raise RingError("invalid_response", "Invalid Raw2 feature batch")
    batch = tuple(_token(data[i : i + 28]) for i in range(4, len(data), 28))
    if any(t.session != batch[0].session for t in batch):
        raise RingError("invalid_response", "Raw2 batch crosses sessions")
    return batch


class Tracker:
    def __init__(self, status: StreamStatus):
        self.session = status.session
        self.epoch = status.epoch
        self.sequence: int | None = None
        self.uptime = 0

    def accept(self, tokens: tuple[Token, ...], skipped: int) -> list[bool]:
        # Validate the entire batch before publishing or advancing recurrent state.
        sequence, epoch, uptime = self.sequence, self.epoch, self.uptime
        resets = []
        for index, token in enumerate(tokens):
            local_gap = skipped if index == 0 else 0
            expected = ((sequence + 1 if sequence is not None else 0) + local_gap) & MASK
            if token.session != self.session or token.sequence != expected:
                raise RingError(
                    "touchpad_sequence",
                    f"Expected Raw2 sequence {expected}, received {token.sequence}",
                )
            epoch_delta = (token.epoch - epoch) & MASK
            if local_gap:
                valid = epoch_delta <= MASK // 2 and (
                    epoch_delta or sequence is None or not token.reset
                )
            elif sequence is None:
                valid = epoch_delta == 0 and token.reset
            else:
                valid = epoch_delta == int(token.reset)
            if not valid:
                raise RingError("touchpad_sequence", "Invalid Raw2 epoch/reset flags")
            dt = (token.uptime - uptime) & MASK
            resets.append(bool(local_gap or sequence is None or epoch_delta or dt > 3000))
            sequence, epoch, uptime = token.sequence, token.epoch, token.uptime
        self.sequence, self.epoch, self.uptime = sequence, epoch, uptime
        return resets
