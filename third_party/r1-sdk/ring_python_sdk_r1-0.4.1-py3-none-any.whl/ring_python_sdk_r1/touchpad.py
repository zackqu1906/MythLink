import asyncio
import logging
import time
from collections import deque
from contextlib import suppress
from pathlib import Path

from bleak.exc import BleakError
from ring_python_sdk_r1._interaction import Engine
from ring_python_sdk_r1._model import TouchpadModel
from ring_python_sdk_r1._protocol import RingError
from ring_python_sdk_r1._raw2 import (
    MASK,
    START,
    STATUS,
    STATUS_REPLY,
    STOP,
    Click,
    ContactUpdate,
    EventMeta,
    Motion,
    TouchpadEvent,
    TouchpadStage,
    TouchpadStatus,
    Tracker,
    parse_status,
    parse_tokens,
)

__all__ = [
    "Click",
    "ContactUpdate",
    "Motion",
    "Touchpad",
    "TouchpadEvent",
    "TouchpadStage",
    "TouchpadStatus",
]

log = logging.getLogger(__name__)


class Touchpad:
    """Raw2 CPU inference and ordered motion, contact and click events."""

    def __init__(self, ready_gatt, event, on_status):
        self._ready_gatt = ready_gatt
        self._event_callback = event
        self._status_callback = on_status
        self._lock = asyncio.Lock()
        self._queued = asyncio.Event()
        self._queue = deque(maxlen=32)
        self._dropped = 0
        self._fault = None
        self._gatt = None
        self._model = None
        self._startup = None
        self._worker = None
        self._inference = None
        self._engine = Engine(self._emit_event)
        self._stream_may_run = False
        self._accept_features = False
        self._session = None
        self._generation = self._sequence = 0
        self.status = TouchpadStatus()

    def _publish(self, stage, error=None):
        state = TouchpadStatus(stage, self._session, self._generation, error)
        if state != self.status:
            self.status = state
            self._status_callback(state)

    def _clear_events(self):
        self._generation += 1
        self._sequence = 0
        self._engine.clear()

    def _cease_inputs(self):
        self._accept_features = False
        self._queue.clear()
        self._queued.clear()
        self._dropped = 0
        self._fault = None
        self._clear_events()

    async def start(self, model_path: str | Path | None = None):
        """Load the bundled R1 CPU model or a matching override and await the first frame."""
        async with self._lock:
            if self.status.stage in (TouchpadStage.RUNNING, TouchpadStage.SLEEPING):
                raise RingError("busy", "Stop the current touchpad before starting with a model")
            if self._gatt is not None:
                await self._finish(TouchpadStage.STOPPED)
            gatt = self._ready_gatt()
            gatt.require_mtu(67)
            self._gatt = gatt
            path = Path(model_path).expanduser() if model_path is not None else None
            await self._launch(path)

    async def sleep(self):
        """Stop the feature stream and keep the loaded CPU model."""
        async with self._lock:
            if self.status.stage == TouchpadStage.SLEEPING:
                return
            if self.status.stage != TouchpadStage.RUNNING:
                raise RingError("not_ready", "Touchpad is not running")
            await self._finish(TouchpadStage.SLEEPING)

    async def wake(self):
        """Start a new feature stream on the same link with the loaded model."""
        async with self._lock:
            if self.status.stage == TouchpadStage.RUNNING:
                return
            if self.status.stage != TouchpadStage.SLEEPING or self._gatt is not self._ready_gatt():
                raise RingError("not_ready", "Touchpad has no suspended model on this link")
            await self._launch(None)

    async def stop(self):
        """Stop streaming and release the model."""
        if self._startup is not None:
            self._startup.cancel()
        async with self._lock:
            if self._gatt is not None:
                await self._finish(TouchpadStage.STOPPED)

    def disconnected(self):
        if self._gatt is None:
            return
        self._gatt = self._model = self._session = None
        self._stream_may_run = False
        self._cease_inputs()
        for task in (self._startup, self._worker):
            if task and not task.done():
                task.cancel()
        self._publish(TouchpadStage.STOPPED)

    async def _launch(self, path: Path | None):
        self._startup = asyncio.create_task(self._start(path))
        try:
            await self._startup
        finally:
            self._startup = None

    async def _start(self, path: Path | None):
        gatt = self._gatt
        self._cease_inputs()
        self._session = None
        self._publish(TouchpadStage.STARTING)
        try:
            async with asyncio.timeout(25):
                if self._model is None:
                    self._model = await asyncio.to_thread(TouchpadModel, path)
                    parse_status(await gatt.request(STATUS, STATUS_REPLY))
                    await self._command_stop(gatt)
                self._stream_may_run = self._accept_features = True
                data = await gatt.request(
                    START, STATUS_REPLY, accept=lambda p: _ack(p, starting=True)
                )
                status = parse_status(data)
                if not status.running:
                    raise RingError(
                        "device_error", "Ring did not start Raw2", device_code=status.result
                    )
                self._session = status.session
                first = asyncio.get_running_loop().create_future()
                self._worker = asyncio.create_task(
                    self._consume(gatt, self._model, Tracker(status), first)
                )
                await first
        except asyncio.CancelledError:
            if gatt is self._gatt:
                with suppress(RingError):
                    await self._finish(TouchpadStage.STOPPED)
            raise
        except Exception as error:
            fault = (
                error
                if isinstance(error, RingError)
                else RingError(
                    "touchpad_start_failed",
                    str(error) or "No first Raw2 frame before the startup deadline",
                )
            )
            if gatt is self._gatt:
                with suppress(RingError):
                    await self._finish(TouchpadStage.FAILED, fault)
            if fault is error:
                raise
            raise fault from error

    async def _command_stop(self, gatt):
        reply = parse_status(
            await gatt.request(STOP, STATUS_REPLY, accept=lambda p: _ack(p, starting=False))
        )
        if not reply.stopped:
            raise RingError(
                "stop_unconfirmed", "Ring did not acknowledge Raw2 STOP", device_code=reply.result
            )
        self._stream_may_run = False

    async def _finish(self, stage, fault=None):
        gatt = self._gatt
        self._cease_inputs()
        if stage == TouchpadStage.SLEEPING:
            self._publish(TouchpadStage.SUSPENDING)
        if self._worker is not None:
            self._worker.cancel()
            await asyncio.gather(self._worker, return_exceptions=True)
            self._worker = None
        if gatt is not self._gatt:
            return
        try:
            if self._stream_may_run and gatt and gatt.active:
                await self._command_stop(gatt)
            if stage == TouchpadStage.SLEEPING and self._inference is not None:
                async with asyncio.timeout(3):
                    await asyncio.shield(self._inference)
        except (RingError, BleakError, TimeoutError, OSError) as error:
            failure = fault or RingError("stop_unconfirmed", str(error))
            self._model = None
            self._publish(TouchpadStage.FAILED, failure)
            raise failure from error
        if stage != TouchpadStage.SLEEPING:
            self._model = self._inference = self._session = self._gatt = None
        self._publish(stage, fault)

    def receive(self, gatt, data):
        if not self._accept_features or gatt is not self._gatt:
            return
        try:
            if data[:2] == STATUS_REPLY:
                if self._session is None:
                    return
                status = parse_status(data)
                if not status.running or status.session != self._session:
                    raise RingError(
                        "touchpad_stream_failed", "Ring stopped or changed its Raw2 stream"
                    )
                return
            tokens = parse_tokens(data)
            if len(self._queue) >= self._queue.maxlen:
                dropped, _ = self._queue.popleft()
                if self._dropped == 0:
                    log.warning(
                        "R1 touchpad input queue full. Dropping old tokens and resetting inference."
                    )
                self._dropped += len(dropped)
            self._queue.append((tokens, time.perf_counter_ns()))
        except RingError as error:
            self._fault = error
        self._queued.set()

    async def _consume(self, gatt, model, tracker, first):
        ordinal = 0
        last_input = time.perf_counter()
        try:
            while gatt is self._gatt and self._accept_features:
                if self._fault is not None:
                    raise self._fault
                if not self._queue:
                    self._engine.round()
                    now = time.perf_counter_ns()
                    until_click = (self._engine.next_wake(now) - now) / 1e9
                    self._queued.clear()
                    try:
                        async with asyncio.timeout(max(0, min(0.1, until_click))):
                            await self._queued.wait()
                    except TimeoutError:
                        if ordinal and time.perf_counter() - last_input > 3:
                            last_input = time.perf_counter()
                            state = parse_status(await gatt.request(STATUS, STATUS_REPLY))
                            if not state.running or state.session != tracker.session:
                                raise RingError("touchpad_stream_failed", "Raw2 input stopped")
                            log.warning(
                                "R1 Raw2 stream is active but no feature packets arrived for three seconds"
                            )
                    continue
                batch, arrival = self._queue.popleft()
                if tracker.sequence is None and batch[0].session != tracker.session:
                    continue
                resets = tracker.accept(batch, self._dropped)
                self._dropped = 0
                last_input = time.perf_counter()
                for token, reset in zip(batch, resets):
                    if reset and ordinal:
                        self._clear_events()
                        ordinal = 0
                        self._publish(TouchpadStage.STARTING)
                    values = await self._infer(model, token.features, reset)
                    if gatt is not self._gatt or not self._accept_features:
                        return
                    self._publish(TouchpadStage.RUNNING)
                    age_ms = (batch[-1].uptime - token.uptime) & MASK
                    source = max(0, arrival - min(age_ms, 3000) * 1_000_000)
                    self._engine.publish(2 * ordinal + 1, source, values, time.perf_counter_ns())
                    ordinal += 1
                    self._engine.round()
                    if not first.done():
                        first.set_result(None)
        except Exception as error:
            fault = (
                error
                if isinstance(error, RingError)
                else RingError(
                    "touchpad_stream_failed", str(error) or "Raw2 inference deadline exceeded"
                )
            )
            if not first.done():
                first.set_exception(fault)
            elif gatt is self._gatt:
                self._cease_inputs()
                self._model = None
                self._publish(TouchpadStage.FAILED, fault)
                if self._stream_may_run and gatt.active:
                    with suppress(RingError, BleakError, TimeoutError, OSError):
                        await self._command_stop(gatt)

    async def _infer(self, model, features, reset):
        def run():
            if reset:
                model.reset()
            return model.step(features)

        task = self._inference = asyncio.create_task(asyncio.to_thread(run))
        task.add_done_callback(lambda done: done.exception() if not done.cancelled() else None)
        async with asyncio.timeout(3):
            return await asyncio.shield(task)

    def _emit_event(self, kind, now, **event):
        if self.status.stage != TouchpadStage.RUNNING or not self._accept_features:
            return
        self._sequence += 1
        source = event.get("source", now)
        if kind == "click":
            source = event["contacts"][-1].up
        elif kind == "preview":
            source = event["contact"].up
        assert self._session is not None
        meta = EventMeta(self._session, self._generation, self._sequence, source)
        if kind == "motion":
            value = Motion(
                meta, event["frame"], event["dx"], event["dy"], event["mode"], event["id"]
            )
        elif kind == "contact":
            value = ContactUpdate(meta, event["id"], event["phase"], event["mode"], event["range"])
        else:
            value = Click(
                meta,
                event["id"],
                event.get("button", "LEFT"),
                len(event.get("contacts", ())) or 1,
                kind == "preview",
            )
        self._event_callback(value)


def _ack(data: bytes, *, starting: bool) -> bool:
    # Reject a late successful acknowledgement from the opposite command.
    return len(data) != 64 or any(data[4:8]) or ((data[3] == 1) == starting)
