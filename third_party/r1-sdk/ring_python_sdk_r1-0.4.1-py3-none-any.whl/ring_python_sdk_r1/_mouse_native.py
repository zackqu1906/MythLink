import ctypes as C
import sys

from ring_python_sdk_r1._protocol import RingError


class _CGPoint(C.Structure):
    _fields_ = [("x", C.c_double), ("y", C.c_double)]


class _CGSize(C.Structure):
    _fields_ = [("width", C.c_double), ("height", C.c_double)]


class _CGRect(C.Structure):
    _fields_ = [("origin", _CGPoint), ("size", _CGSize)]


class _MacMouse:
    """CoreGraphics cursor backend, adapted from the Ring SDK validator."""

    def __init__(self):
        frameworks = "/System/Library/Frameworks"
        self.cg = C.CDLL(f"{frameworks}/CoreGraphics.framework/CoreGraphics")
        self.ax = C.CDLL(f"{frameworks}/ApplicationServices.framework/ApplicationServices")
        self.cf = C.CDLL(f"{frameworks}/CoreFoundation.framework/CoreFoundation")
        self.ax.AXIsProcessTrusted.argtypes = []
        self.ax.AXIsProcessTrusted.restype = C.c_ubyte
        self.cg.CGEventCreate.argtypes = [C.c_void_p]
        self.cg.CGEventCreate.restype = C.c_void_p
        self.cg.CGEventGetLocation.argtypes = [C.c_void_p]
        self.cg.CGEventGetLocation.restype = _CGPoint
        self.cg.CGGetActiveDisplayList.argtypes = [
            C.c_uint32,
            C.POINTER(C.c_uint32),
            C.POINTER(C.c_uint32),
        ]
        self.cg.CGGetActiveDisplayList.restype = C.c_int32
        self.cg.CGDisplayBounds.argtypes = [C.c_uint32]
        self.cg.CGDisplayBounds.restype = _CGRect
        self.cg.CGEventCreateMouseEvent.argtypes = [C.c_void_p, C.c_uint32, _CGPoint, C.c_uint32]
        self.cg.CGEventCreateMouseEvent.restype = C.c_void_p
        # Use the fixed-argument API for the Apple Silicon calling convention.
        self.cg.CGEventCreateScrollWheelEvent2.argtypes = [
            C.c_void_p,
            C.c_uint32,
            C.c_uint32,
            C.c_int32,
            C.c_int32,
            C.c_int32,
        ]
        self.cg.CGEventCreateScrollWheelEvent2.restype = C.c_void_p
        self.cg.CGEventSetIntegerValueField.argtypes = [C.c_void_p, C.c_uint32, C.c_int64]
        self.cg.CGEventSetIntegerValueField.restype = None
        self.cg.CGEventPost.argtypes = [C.c_uint32, C.c_void_p]
        self.cg.CGEventPost.restype = None
        self.cf.CFRelease.argtypes = [C.c_void_p]
        self.cf.CFRelease.restype = None

    def probe(self):
        if not self.ax.AXIsProcessTrusted():
            raise RingError(
                "mouse_permission_required",
                "Allow the host app or terminal in macOS Privacy & Security → Accessibility",
            )

    @staticmethod
    def _require_event(event):
        if not event:
            raise RingError("mouse_output_failed", "CoreGraphics could not create a mouse event")
        return event

    def position(self) -> tuple[float, float]:
        event = self._require_event(self.cg.CGEventCreate(None))
        try:
            point = self.cg.CGEventGetLocation(event)
            return point.x, point.y
        finally:
            self.cf.CFRelease(event)

    def _constrain(self, x: float, y: float) -> tuple[float, float]:
        count = C.c_uint32()
        if self.cg.CGGetActiveDisplayList(0, None, C.byref(count)) == 0 and count.value:
            displays = (C.c_uint32 * count.value)()
            if self.cg.CGGetActiveDisplayList(len(displays), displays, C.byref(count)) == 0:
                # Clamp to an active display, including displays at negative origins.
                candidates = []
                for display in displays[: count.value]:
                    bounds = self.cg.CGDisplayBounds(display)
                    left, top = bounds.origin.x, bounds.origin.y
                    width, height = bounds.size.width, bounds.size.height
                    if width > 0 and height > 0:
                        candidates.append(
                            (
                                min(max(x, left), left + width - 1),
                                min(max(y, top), top + height - 1),
                            )
                        )
                if candidates:
                    return min(candidates, key=lambda p: (p[0] - x) ** 2 + (p[1] - y) ** 2)
        raise RingError("mouse_output_failed", "macOS did not report an active display")

    def _post(self, event, click_state=0):
        event = self._require_event(event)
        try:
            if click_state:
                self.cg.CGEventSetIntegerValueField(event, 1, click_state)  # Mouse click state.
            self.cg.CGEventPost(0, event)  # kCGHIDEventTap.
        finally:
            self.cf.CFRelease(event)

    def move(self, x: float, y: float) -> tuple[float, float]:
        self.probe()
        position = self._constrain(x, y)
        self._post(self.cg.CGEventCreateMouseEvent(None, 5, _CGPoint(*position), 0))
        return position

    def scroll(self, dx: int, dy: int):
        self.probe()
        # Axis 1 is vertical, axis 2 horizontal, in Quartz pixel units.
        self._post(self.cg.CGEventCreateScrollWheelEvent2(None, 0, 2, dy, dx, 0))

    def click(self, button: str, count: int, position: tuple[float, float]):
        self.probe()
        down, up, button_id = (1, 2, 0) if button == "LEFT" else (3, 4, 1)
        point = _CGPoint(*position)
        for index in range(1, count + 1):
            pressed = self._require_event(
                self.cg.CGEventCreateMouseEvent(None, down, point, button_id)
            )
            try:
                released = self._require_event(
                    self.cg.CGEventCreateMouseEvent(None, up, point, button_id)
                )
            except RingError:
                self.cf.CFRelease(pressed)
                raise
            try:
                self._post(pressed, index)
            finally:
                self._post(released, index)


class _WinPoint(C.Structure):
    _fields_ = [("x", C.c_int32), ("y", C.c_int32)]


class _WinMouseInput(C.Structure):
    _fields_ = [
        ("dx", C.c_int32),
        ("dy", C.c_int32),
        ("mouse_data", C.c_uint32),
        ("flags", C.c_uint32),
        ("time", C.c_uint32),
        ("extra_info", C.c_size_t),
    ]


class _WinInput(C.Structure):
    # MOUSEINPUT is the largest member of the Windows INPUT union.
    _fields_ = [("kind", C.c_uint32), ("mouse", _WinMouseInput)]


class _WindowsMouse:
    def __init__(self):
        self.user32 = C.WinDLL("user32")
        self.user32.GetCursorPos.argtypes = [C.POINTER(_WinPoint)]
        self.user32.GetCursorPos.restype = C.c_int32
        self.user32.SetCursorPos.argtypes = [C.c_int32, C.c_int32]
        self.user32.SetCursorPos.restype = C.c_int32
        self.user32.SendInput.argtypes = [C.c_uint32, C.POINTER(_WinInput), C.c_int32]
        self.user32.SendInput.restype = C.c_uint32

    def probe(self):
        self.position()

    def position(self) -> tuple[float, float]:
        point = _WinPoint()
        if not self.user32.GetCursorPos(C.byref(point)):
            raise RingError("mouse_output_failed", "Windows could not read the desktop cursor")
        return float(point.x), float(point.y)

    def move(self, x: float, y: float) -> tuple[float, float]:
        if not self.user32.SetCursorPos(round(x), round(y)):
            raise RingError("mouse_output_failed", "Windows could not move the desktop cursor")
        return self.position()

    def _send(self, events: list[tuple[int, int]]) -> int:
        inputs = (_WinInput * len(events))(
            *(_WinInput(0, _WinMouseInput(0, 0, data, flags, 0, 0)) for flags, data in events)
        )
        return self.user32.SendInput(len(inputs), inputs, C.sizeof(_WinInput))

    def scroll(self, dx: int, dy: int):
        # Three delta units per logical pixel give a 120-unit wheel step per 40 pixels.
        events = [(flag, value * 3) for flag, value in ((0x0800, dy), (0x1000, -dx)) if value]
        if self._send(events) != len(events):
            raise RingError("mouse_output_failed", "Windows could not post the scroll event")

    def click(self, button: str, count: int, position: tuple[float, float]):
        down, up = (0x0002, 0x0004) if button == "LEFT" else (0x0008, 0x0010)
        events = [(down, 0), (up, 0)] * count
        sent = self._send(events)
        if sent != len(events):
            if sent % 2:
                self._send([(up, 0)])
            raise RingError("mouse_output_failed", "Windows could not post the mouse click")


def open_mouse() -> _MacMouse | _WindowsMouse:
    try:
        if sys.platform == "darwin":
            backend = _MacMouse()
        elif sys.platform == "win32":
            backend = _WindowsMouse()
        else:
            raise RingError("mouse_unavailable", "System mouse output supports macOS and Windows")
        backend.probe()
        return backend
    except (OSError, AttributeError) as error:
        raise RingError("mouse_unavailable", "Could not initialize desktop mouse output") from error
