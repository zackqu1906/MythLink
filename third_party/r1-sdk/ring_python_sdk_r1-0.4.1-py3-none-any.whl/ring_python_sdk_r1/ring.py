import asyncio
import logging
import struct
import sys
from collections.abc import Callable
from contextlib import suppress
from dataclasses import dataclass, field, replace
from pathlib import Path

from bleak import BleakClient, BleakScanner
from bleak.backends.device import BLEDevice
from bleak.exc import BleakError
from ring_python_sdk_r1._binding import Binding
from ring_python_sdk_r1._gatt import Gatt
from ring_python_sdk_r1._protocol import (
    BATTERY,
    DIS_SERVICE,
    GESTURE_STATE,
    INFO,
    SERIAL,
    BatteryStatus,
    CircleMotion,
    ConnectionState,
    DeviceInfo,
    GestureEvent,
    GestureMode,
    GestureStatus,
    RingError,
    SwipeDirection,
    WearingHand,
    matches_advertisement,
    parse_battery,
    parse_circle,
    parse_gesture,
    parse_gesture_status,
    parse_info,
    parse_serial,
)
from ring_python_sdk_r1._storage import Storage
from ring_python_sdk_r1.touchpad import Touchpad, TouchpadEvent, TouchpadStatus

__all__ = ["Ring", "RingDevice", "scan"]

log = logging.getLogger(__name__)
RETRYABLE = {"busy", "device_unavailable", "disconnected", "timeout", "bluetooth_error"}


@dataclass(frozen=True)
class RingDevice:
    address: str
    name: str
    rssi: int | None
    _device: BLEDevice = field(repr=False, compare=False)


async def scan(timeout: float = 6.0) -> list[RingDevice]:
    """Find R1 candidates on the local Bluetooth adapter."""
    if timeout <= 0:
        raise ValueError("Scan timeout must be positive")
    found: dict[str, RingDevice] = {}
    product_ids: dict[str, bytes] = {}

    def observe(device, advertisement):
        address = device.address.casefold()
        name = advertisement.local_name or device.name or ""
        if DIS_SERVICE in advertisement.service_data:
            product_ids[address] = bytes(advertisement.service_data[DIS_SERVICE])
        if matches_advertisement(name, product_ids.get(address)):
            previous = found.get(address)
            # CoreBluetooth can report 127 when RSSI is unavailable.
            rssi = (
                advertisement.rssi
                if advertisement.rssi != 127
                else (previous.rssi if previous else None)
            )
            found[address] = RingDevice(device.address, name or "R1", rssi, device)
        elif address in product_ids:
            found.pop(address, None)

    try:
        async with BleakScanner(detection_callback=observe):
            await asyncio.sleep(timeout)
    except (BleakError, OSError) as error:
        raise RingError("bluetooth_error", str(error)) from error
    return sorted(
        found.values(),
        key=lambda item: (-item.rssi if item.rssi is not None else float("inf"), item.address),
    )


def _emit(callback, value):
    if callback is not None:
        try:
            callback(value)
        except Exception:
            log.exception("R1 event callback failed")


async def _cancel(task: asyncio.Task | None):
    if task and not task.done():
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)


class Ring:
    """One R1 connection owned by this instance and its asyncio event loop."""

    def __init__(
        self,
        *,
        storage_dir: str | Path | None = None,
        on_state: Callable[[ConnectionState], None] | None = None,
        on_gesture: Callable[[GestureEvent], None] | None = None,
        on_circle: Callable[[CircleMotion], None] | None = None,
        on_battery: Callable[[BatteryStatus], None] | None = None,
        on_gesture_status: Callable[[GestureStatus], None] | None = None,
        on_touchpad: Callable[[TouchpadEvent], None] | None = None,
        on_touchpad_status: Callable[[TouchpadStatus], None] | None = None,
    ):
        self.on_state = on_state
        self.on_gesture = on_gesture
        self.on_circle = on_circle
        self.on_battery = on_battery
        self.on_gesture_status = on_gesture_status
        self.on_touchpad = on_touchpad
        self.on_touchpad_status = on_touchpad_status
        self.state = ConnectionState.DISCONNECTED
        self.info: DeviceInfo | None = None
        self.battery: BatteryStatus | None = None
        self.gesture_status: GestureStatus | None = None
        self.last_error: RingError | None = None
        self.binding_warning: Exception | None = None
        self._storage = Storage(Path(storage_dir) if storage_dir is not None else None)
        self._lock = asyncio.Lock()
        self._gatt: Gatt | None = None
        self._binding: Binding | None = None
        self._target: str | None = None
        self._recover = False
        self._attempt: asyncio.Task | None = None
        self._recovery: asyncio.Task | None = None
        self._refresh: asyncio.Task | None = None
        self.touchpad = Touchpad(
            self._ready_gatt,
            lambda event: _emit(self.on_touchpad, event),
            lambda status: _emit(self.on_touchpad_status, status),
        )

    @property
    def connected(self) -> bool:
        return self.state == ConnectionState.READY and self._gatt is not None and self._gatt.active

    @property
    def address(self) -> str | None:
        return self._target

    @property
    def remembered_address(self) -> str | None:
        """Return the saved address used to restore the current host binding."""
        remembered = self._storage.target()
        return remembered[0] if remembered else None

    def _set_state(self, state: ConnectionState):
        if state != self.state:
            self.state = state
            _emit(self.on_state, state)

    def _ready_gatt(self) -> Gatt:
        if not self.connected or self._gatt is None:
            raise RingError("disconnected", "R1 business connection is unavailable")
        self._gatt.check()
        return self._gatt

    async def connect(
        self, device: RingDevice | str | None = None, *, auto_reconnect=True
    ) -> DeviceInfo:
        """Connect explicitly and, if permitted by the ring, establish its first binding."""
        return await self._connect(device, explicit=True, recover=auto_reconnect)

    async def resume(self) -> DeviceInfo | None:
        """Resume a saved connection whose automatic recovery has not been paused."""
        remembered = self._storage.target()
        if not remembered or not remembered[1]:
            return None
        return await self._connect(remembered[0], explicit=False, recover=True)

    async def _connect(self, device, *, explicit, recover) -> DeviceInfo:
        if self._lock.locked():
            raise RingError("busy", "A connection or binding operation is already running")
        async with self._lock:
            if device is None:
                remembered = self._storage.target()
                device = self._target or (remembered[0] if remembered else None)
            address = device.address if isinstance(device, RingDevice) else device
            if not isinstance(address, str) or not address.strip():
                raise RingError("device_required", "Select an R1 from scan() first")
            if self.connected:
                if self._target is None or self._target.casefold() != address.casefold():
                    raise RingError("busy", "Disconnect the current R1 before selecting another")
                self._storage.remember(address, recover)
                self._recover = recover
                assert self.info is not None
                return self.info
            self._recover = False
            await _cancel(self._recovery)
            self._target = address
            target = device._device if isinstance(device, RingDevice) else address
            self._attempt = asyncio.create_task(self._open(target, address, explicit=explicit))
            try:
                info = await self._attempt
                if self._gatt is None:
                    raise RingError("disconnected")
                self._gatt.check()
                self._storage.remember(address, recover)
                self._recover = recover
                self._ready()
                return info
            except RingError as error:
                if not explicit and error.reason in RETRYABLE:
                    self._recover = recover
                    self._schedule_recovery()
                raise
            finally:
                self._attempt = None
                if not self.connected:
                    await self._close()

    async def _open(self, target, address, *, explicit) -> DeviceInfo:
        self.last_error = None
        self._set_state(ConnectionState.CONNECTING)
        gatt = self._gatt = Gatt(target, self._lost, self._notification)
        try:
            async with asyncio.timeout(150):
                await gatt.open()
                self._set_state(ConnectionState.AUTHENTICATING)
                binding = Binding(gatt, self._storage, address)
                await binding.discover()

                async def pair():
                    self._set_state(ConnectionState.PAIRING)
                    try:
                        await gatt.pair()
                    finally:
                        self._set_state(ConnectionState.AUTHENTICATING)

                await binding.admit(explicit=explicit, pairing=pair)
                self._set_state(ConnectionState.INITIALIZING)
                await gatt.subscribe()
                info = parse_info(await gatt.request(INFO, b"\x2a\x02", timeout=65, retry=5))
                await self._initialize_peer(gatt, legacy=binding.version == 0)
                await binding.register_legacy_recovery(explicit)
                gatt.check()
                self._binding = binding
                self.binding_warning = binding.warning
                self.info = info
                return info
        except (BleakError, TimeoutError, OSError) as error:
            self.last_error = RingError(
                "timeout" if isinstance(error, TimeoutError) else "bluetooth_error",
                str(error) or "Connection deadline exceeded",
            )
            raise self.last_error from error
        except RingError as error:
            self.last_error = error
            raise

    @staticmethod
    async def _initialize_peer(gatt, *, legacy):
        async def peer(operation: int, size: int, extra: bytes = b"") -> bytes:
            prefix = bytes((0x3B, operation | 0x80))
            reply = await gatt.request(bytes((0x3B, operation, 1)) + extra, prefix)
            if len(reply) < 5 or reply[2] != 1:
                raise RingError("invalid_response", "Invalid peer acknowledgement")
            code = struct.unpack_from("<h", reply, 3)[0]
            if code:
                reason = {-16: "busy", -95: "unsupported_firmware", -134: "unsupported_firmware"}
                raise RingError(reason.get(code, "device_error"), device_code=code)
            if len(reply) != size:
                raise RingError("invalid_response", "Invalid peer acknowledgement length")
            return reply

        try:
            capabilities = await peer(0, 11)
            mask = capabilities[9] & 0x0C
            if (await peer(2, 6, bytes((mask,))))[5] != mask:
                raise RingError("invalid_response", "Ring did not apply event subscriptions")
            device_type = {"win32": 4, "darwin": 5}.get(sys.platform, 0)
            await peer(1, 5, bytes((device_type,)))
        except RingError as error:
            if not legacy or error.reason not in ("timeout", "unsupported_firmware"):
                raise

    def _ready(self):
        if self._gatt is None:
            raise RingError("disconnected")
        self._gatt.check()
        self._set_state(ConnectionState.READY)
        self._refresh = asyncio.create_task(self._refresh_details(self._gatt))

    async def _refresh_details(self, gatt):
        for query in (self.read_battery, self.read_gesture_status, self.read_serial_number):
            if gatt is not self._gatt:
                return
            try:
                await query()
            except RingError as error:
                log.debug("Optional R1 read %s failed: %s", query.__name__, error.reason)

    def _reset(self):
        self.info = self.battery = self.gesture_status = None
        self._binding = None
        self.binding_warning = None
        if self._refresh is not None:
            self._refresh.cancel()
        self.touchpad.disconnected()

    async def _close(self):
        gatt, self._gatt = self._gatt, None
        self._reset()
        self._set_state(ConnectionState.DISCONNECTED)
        if gatt is not None:
            with suppress(BleakError, TimeoutError, OSError):
                await gatt.close()

    def _lost(self, gatt):
        gatt.invalidate()
        if gatt is not self._gatt or self.state != ConnectionState.READY:
            return
        self._gatt = None
        self._reset()
        self.last_error = RingError("disconnected", "R1 link ended")
        self._set_state(ConnectionState.DISCONNECTED)
        self._schedule_recovery()

    def _schedule_recovery(self):
        if self._recover and self._target and (self._recovery is None or self._recovery.done()):
            self._recovery = asyncio.create_task(self._reconnect(self._target))

    async def _reconnect(self, address):
        for delay in (2, 4, 8, 15, 30):
            if not self._recover:
                return
            self._set_state(ConnectionState.RECONNECTING)
            await asyncio.sleep(delay)
            try:
                await self._open(address, address, explicit=False)
                self._ready()
                return
            except RingError as error:
                self.last_error = error
                if error.reason not in RETRYABLE:
                    return
            finally:
                if not self.connected:
                    await self._close()

    async def _stop_attempts(self):
        self._recover = False
        await _cancel(self._attempt)
        await _cancel(self._recovery)

    async def disconnect(self):
        """Pause recovery and disconnect, retaining the selected target and pairing."""
        await self._disconnect(pause_recovery=True)

    async def close(self):
        """Release BLE resources at process exit and retain the recovery preference."""
        await self._disconnect(pause_recovery=False)

    async def _disconnect(self, *, pause_recovery: bool):
        await self._stop_attempts()
        async with self._lock:
            try:
                await self.touchpad.stop()
            finally:
                await self._close()
                if pause_recovery:
                    target = self._storage.target()
                    if target and target[1]:
                        self._storage.remember(target[0], False)

    async def _unpair(self, address: str, client: BleakClient | None = None) -> bool:
        if sys.platform == "darwin":
            return False
        try:
            async with asyncio.timeout(15):
                await (client or BleakClient(address)).unpair()
            return True
        except (BleakError, TimeoutError, OSError, NotImplementedError) as error:
            log.debug("R1 system pairing removal incomplete: %s", type(error).__name__)
            return False

    def _unbind_address(self, expected: str | None) -> str:
        address = self._target if self.connected else (self.remembered_address or self._target)
        if not address:
            raise RingError("device_required", "No R1 selected for unbind")
        if expected is not None and expected.casefold() != address.casefold():
            raise RingError("binding_target_mismatch", "The selected R1 binding has changed")
        return address

    async def unbind(self, address: str | None = None) -> bool:
        """Remove the current or saved host binding, optionally checking the expected address."""
        if address is not None:
            self._unbind_address(address)
        await self._stop_attempts()
        async with self._lock:
            address = self._unbind_address(address)
            if self._storage.unbind_pending(address):
                raise RingError("unbind_pending", "Confirm the previous unbind first")
            self._storage.remember(address, False)
            try:
                if not self.connected:
                    self._target = address
                    await self._open(address, address, explicit=False)
                gatt, binding = self._gatt, self._binding
                assert gatt is not None and binding is not None
                try:
                    await self.touchpad.stop()
                except RingError as error:
                    log.debug("R1 touchpad unconfirmed before unbind: %s", error.reason)
                await binding.self_unbind()
                self._storage.forget(address)
                self._target = None
            except (BleakError, TimeoutError, OSError) as error:
                raise RingError("unbind_unconfirmed") from error
            except RingError as error:
                if error.device_code is not None and self._storage.unbind_pending(address):
                    self._storage.cancel_unbind(address)
                elif self._storage.unbind_pending(address):
                    raise RingError("unbind_unconfirmed") from error
                raise
            finally:
                await self._close()
            return await self._unpair(address, gatt.client)

    async def confirm_unbind(self, address: str | None = None) -> bool:
        """Check an interrupted unbind with a read-only binding query."""
        await self._stop_attempts()
        async with self._lock:
            target = self._storage.target()
            address = address or self._target or (target[0] if target else None)
            if not address or not self._storage.unbind_pending(address):
                return False
            if self._gatt is not None:
                raise RingError("busy", "Disconnect before confirming unbind")
            gatt = Gatt(address, self._lost, self._notification)
            try:
                await gatt.open()
                binding = Binding(gatt, self._storage, address)
                await binding.discover(indicate=False)
                absent = await binding.unbind_absent()
                if absent is False:
                    self._storage.cancel_unbind(address)
                if not absent:
                    return False
                self._storage.forget(address)
                self._target = None
            except (BleakError, TimeoutError, OSError) as error:
                raise RingError("unbind_unconfirmed") from error
            finally:
                with suppress(BleakError, TimeoutError, OSError):
                    await gatt.close()
            await self._unpair(address, gatt.client)
            return True

    async def forget_binding(self, address: str | None = None) -> bool:
        """Remove local recovery data and try to remove the OS bond."""
        await self.disconnect()
        async with self._lock:
            target = self._storage.target()
            address = address or self._target or (target[0] if target else None)
            if not address:
                return False
            self._storage.forget(address)
            if self._target and address.casefold() == self._target.casefold():
                self._target = None
            return await self._unpair(address)

    async def _request(self, command: bytes, reply: bytes) -> bytes:
        try:
            return await self._ready_gatt().request(command, reply)
        except (BleakError, OSError) as error:
            raise RingError("bluetooth_error", str(error)) from error

    async def read_battery(self) -> BatteryStatus:
        data = await self._request(BATTERY, b"\x29\x02")
        battery = parse_battery(data)
        if battery is None:
            raise RingError("invalid_response", "Invalid battery status")
        self.battery = battery
        _emit(self.on_battery, battery)
        return battery

    async def read_serial_number(self) -> str:
        self._ready_gatt().require_mtu(129)
        serial = parse_serial(await self._request(SERIAL, b"\x34\x02"))
        if self.info is not None:
            self.info = replace(self.info, serial_number=serial)
        return serial

    async def read_gesture_status(self) -> GestureStatus:
        status = parse_gesture_status(await self._request(GESTURE_STATE, b"\x26\x0b"))
        if status is None:
            raise RingError("invalid_response", "Invalid gesture status")
        self.gesture_status = status
        _emit(self.on_gesture_status, status)
        return status

    async def set_gesture_mode(self, mode: GestureMode) -> GestureMode:
        mode = GestureMode(mode)
        if mode != GestureMode.OFF:
            self._ready_gatt().require_mtu(68)
            if self.info and not self.info.gesture_available:
                raise RingError("unsupported_firmware", "Gesture recognition is unavailable")
        await self._gesture_command(bytes((0x26, mode)), 0x08, 5)
        return mode

    async def read_wearing_hand(self) -> WearingHand:
        return await self._gesture_setting(0x38, WearingHand)

    async def set_wearing_hand(self, hand: WearingHand) -> WearingHand:
        return await self._gesture_setting(0x38, WearingHand, WearingHand(hand))

    async def read_swipe_direction(self) -> SwipeDirection:
        return await self._gesture_setting(0x39, SwipeDirection)

    async def set_swipe_direction(self, direction: SwipeDirection) -> SwipeDirection:
        return await self._gesture_setting(0x39, SwipeDirection, SwipeDirection(direction))

    async def _gesture_setting(self, command, enum, value=None):
        packet = bytes((command, 0)) if value is None else bytes((command, 1, value))
        result = await self._gesture_command(packet, 0x80, 6)
        try:
            return enum(result[5])
        except ValueError as error:
            raise RingError("invalid_response", "Invalid gesture setting value") from error

    async def _gesture_command(self, packet, response, size) -> bytes:
        reply = await self._request(packet, bytes((packet[0], response, packet[1])))
        if len(reply) != size:
            raise RingError("invalid_response", "Invalid gesture acknowledgement")
        code = struct.unpack_from("<h", reply, 3)[0]
        if code:
            raise RingError("device_error", device_code=code)
        return reply

    def _notification(self, gatt, data: bytes):
        if gatt is not self._gatt or not self.connected:
            return
        match data[:2]:
            case b"\x26\x06":
                if event := parse_gesture(data):
                    _emit(self.on_gesture, event)
            case b"\x26\x0c":
                if event := parse_circle(data):
                    _emit(self.on_circle, event)
            case b"\x26\x0b":
                if status := parse_gesture_status(data):
                    self.gesture_status = status
                    _emit(self.on_gesture_status, status)
            case b"\x29\x02":
                if battery := parse_battery(data):
                    self.battery = battery
                    _emit(self.on_battery, battery)
            case b"\x3c\x02" | b"\x3c\x13" | b"\x3c\x11":
                self.touchpad.receive(gatt, data)
