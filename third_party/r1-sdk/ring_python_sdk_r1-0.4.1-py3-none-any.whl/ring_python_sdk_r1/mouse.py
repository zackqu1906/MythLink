"""Opt-in system mouse mapping for one R1 touchpad stream."""

import math

from ring_python_sdk_r1._mouse_native import open_mouse
from ring_python_sdk_r1._protocol import RingError
from ring_python_sdk_r1._raw2 import (
    Click,
    ContactUpdate,
    Motion,
    TouchpadEvent,
    TouchpadStage,
    TouchpadStatus,
)

__all__ = ["SystemMouse"]


class SystemMouse:
    """Connect these callbacks to the same Ring and enable after touchpad startup."""

    def __init__(self):
        self._backend = None
        self._status: TouchpadStatus | None = None
        self._sequence = 0
        self._clear_motion()

    @property
    def enabled(self) -> bool:
        return self._status is not None

    def enable(self, status: TouchpadStatus):
        """Enable output for a running touchpad on the current desktop."""
        if status.stage != TouchpadStage.RUNNING or status.session_id is None:
            raise RingError("not_ready", "Start the R1 touchpad before enabling mouse output")
        self.disable()
        self._backend = open_mouse()
        self._status = status

    def disable(self):
        """Stop forwarding system input."""
        self._status = self._backend = None
        self._sequence = 0
        self._clear_motion()

    def _clear_motion(self):
        self._contact = None
        self._position = None
        self._fraction_x = self._fraction_y = 0.0

    def on_touchpad_status(self, status: TouchpadStatus):
        previous = self._status
        if previous is None:
            return
        if status.session_id != previous.session_id or status.stage not in (
            TouchpadStage.STARTING,
            TouchpadStage.RUNNING,
        ):
            self.disable()
        elif status.generation >= previous.generation:
            if status.generation != previous.generation:
                self._clear_motion()
                self._sequence = 0
            self._status = status

    def on_touchpad(self, event: TouchpadEvent):
        status, backend = self._status, self._backend
        meta = event.meta
        if (
            status is None
            or backend is None
            or status.stage != TouchpadStage.RUNNING
            or (meta.session_id, meta.generation) != (status.session_id, status.generation)
            or meta.sequence <= self._sequence
        ):
            return
        self._sequence = meta.sequence
        try:
            if isinstance(event, Motion):
                self._move_or_scroll(event, backend)
            elif isinstance(event, Click) and not event.is_preview:
                if event.button not in ("LEFT", "RIGHT") or event.count not in (1, 2):
                    raise RingError("mouse_output_failed", "Invalid R1 mouse click")
                backend.click(event.button, event.count, self._position or backend.position())
            elif isinstance(event, ContactUpdate) and event.phase in ("BEGIN", "END", "CANCEL"):
                self._clear_motion()
        except RingError:
            self.disable()
            raise
        except (OSError, ValueError, OverflowError) as error:
            self.disable()
            raise RingError("mouse_output_failed", str(error)) from error

    def _move_or_scroll(self, event: Motion, backend):
        if event.mode not in ("SINGLE", "TWO_FINGER"):
            return
        contact = event.mode, event.episode_id
        if contact != self._contact:
            self._clear_motion()
            self._contact = contact
        x, y = event.dx + self._fraction_x, event.dy + self._fraction_y
        if not all(math.isfinite(value) and abs(value) < 2**29 for value in (x, y)):
            raise RingError("mouse_output_failed", "Invalid R1 mouse movement")
        dx, dy = math.trunc(x), math.trunc(y)
        self._fraction_x, self._fraction_y = x - dx, y - dy
        if not (dx or dy):
            return
        if event.mode == "TWO_FINGER":
            backend.scroll(dx, dy)
        else:
            # A posted cursor event may still be queued when the next frame arrives.
            left, top = self._position or backend.position()
            self._position = backend.move(left + dx, top + dy)
